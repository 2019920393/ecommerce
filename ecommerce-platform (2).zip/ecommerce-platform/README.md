# 云原生微服务电商平台

## 📋 项目简介

这是一个基于Spring Boot 3.x + Spring Cloud 2023.x构建的云原生微服务电商平台，采用微服务架构，实现订单管理和支付处理等核心业务功能。

## 🏗️ 项目结构

```
ecommerce-platform/
├── common/                    # 公共模块
│   ├── src/
│   │   └── main/
│   │       └── java/
│   │           └── com/ecommerce/common/
│   │               ├── constant/      # 常量定义
│   │               ├── enums/         # 枚举类
│   │               ├── exception/     # 异常类
│   │               ├── result/        # 统一响应结果
│   │               └── utils/         # 工具类
│   └── pom.xml
│
├── order-service/             # 订单服务
│   ├── src/
│   │   └── main/
│   │       ├── java/
│   │       │   └── com/ecommerce/order/
│   │       │       ├── controller/    # 控制层
│   │       │       ├── service/       # 业务层
│   │       │       ├── repository/    # 数据访问层
│   │       │       ├── domain/        # 领域模型
│   │       │       ├── dto/           # 数据传输对象
│   │       │       ├── client/        # Feign客户端
│   │       │       └── config/        # 配置类
│   │       └── resources/
│   │           ├── application.yml    # 配置文件
│   │           └── mapper/            # MyBatis映射文件
│   └── pom.xml
│
├── payment-service/           # 支付服务
│   ├── src/
│   │   └── main/
│   │       ├── java/
│   │       │   └── com/ecommerce/payment/
│   │       │       ├── controller/    # 控制层
│   │       │       ├── service/       # 业务层
│   │       │       ├── repository/    # 数据访问层
│   │       │       ├── domain/        # 领域模型
│   │       │       ├── dto/           # 数据传输对象
│   │       │       ├── handler/       # 回调处理器
│   │       │       └── config/        # 配置类
│   │       └── resources/
│   │           ├── application.yml    # 配置文件
│   │           └── mapper/            # MyBatis映射文件
│   └── pom.xml
│
├── inventory-service/         # 库存服务
│   ├── src/
│   │   └── main/
│   │       ├── java/
│   │       │   └── com/ecommerce/inventory/
│   │       │       ├── controller/    # 控制层
│   │       │       ├── service/       # 业务层
│   │       │       ├── repository/    # 数据访问层
│   │       │       ├── domain/        # 领域模型
│   │       │       └── config/        # 配置类
│   │       └── resources/
│   │           ├── application.yml    # 配置文件
│   │           └── mapper/            # MyBatis映射文件
│   └── pom.xml
│
└── pom.xml                    # 父POM文件
```

## 🛠️ 技术栈

### 核心框架
- **Java**: 17
- **Spring Boot**: 3.2.0
- **Spring Cloud**: 2023.0.0
- **Spring Cloud Alibaba**: 2022.0.0.0

### 数据库
- **MySQL**: 8.0+
- **MyBatis-Plus**: 3.5.5
- **Druid**: 1.2.20

### 微服务组件
- **Nacos**: 服务注册与发现、配置中心
- **OpenFeign**: 服务间调用
- **RabbitMQ**: 消息队列
- **Seata**: 分布式事务

### 工具库
- **Lombok**: 简化代码
- **Hutool**: 工具类库
- **FastJSON2**: JSON处理

## 🚀 快速开始

### 1. 环境要求

- JDK 17+
- Maven 3.8+
- MySQL 8.0+
- Nacos 2.x (可选，用于服务注册)
- RabbitMQ 3.x (可选，用于消息队列)

### 2. 数据库初始化

```bash
# 执行数据库初始化脚本
cd ../sql
mysql -u root -p < order_db_init.sql
mysql -u root -p < payment_db_init.sql
```

### 3. 修改配置

修改各服务的 `application.yml` 配置文件：
- 数据库连接信息
- Nacos地址（如果使用）
- RabbitMQ地址（如果使用）

### 4. 编译项目

```bash
# 在项目根目录执行
mvn clean install
```

### 5. 启动服务

```bash
# 启动订单服务
cd order-service
mvn spring-boot:run

# 启动支付服务
cd payment-service
mvn spring-boot:run

# 启动库存服务
cd inventory-service
mvn spring-boot:run
```

## 📡 服务端口

| 服务 | 端口 | 说明 |
|------|------|------|
| order-service | 8083 | 订单服务 |
| payment-service | 8084 | 支付服务 |
| inventory-service | 8085 | 库存服务 |

## 📚 API文档

启动服务后，访问以下地址查看API文档：
- 订单服务: http://localhost:8083/swagger-ui.html
- 支付服务: http://localhost:8084/swagger-ui.html
- 库存服务: http://localhost:8085/swagger-ui.html

## 🔧 开发指南

### 代码规范
- 遵循阿里巴巴Java开发手册
- 使用Lombok简化代码
- 统一异常处理
- 统一响应格式

### 分层架构
```
Controller层 (表示层)
    ↓
Service层 (业务层)
    ↓
Repository层 (数据访问层)
    ↓
Database (数据库)
```

### 命名规范
- 实体类: `Order`, `Payment`
- DTO: `CreateOrderRequest`, `OrderDTO`
- Service: `OrderService`, `PaymentService`
- Controller: `OrderController`, `PaymentController`
- Repository: `OrderRepository`, `PaymentRepository`

## 🧪 测试

```bash
# 运行单元测试
mvn test

# 运行集成测试
mvn verify
```

## 📦 打包部署

```bash
# 打包所有服务
mvn clean package

# 打包后的jar文件位于各服务的target目录
# order-service/target/order-service.jar
# payment-service/target/payment-service.jar
# inventory-service/target/inventory-service.jar
```

## 🐳 Docker部署

```bash
# 构建Docker镜像
docker build -t ecommerce/order-service:1.0.0 ./order-service
docker build -t ecommerce/payment-service:1.0.0 ./payment-service
docker build -t ecommerce/inventory-service:1.0.0 ./inventory-service

# 运行容器
docker run -d -p 8083:8083 ecommerce/order-service:1.0.0
docker run -d -p 8084:8084 ecommerce/payment-service:1.0.0
docker run -d -p 8085:8085 ecommerce/inventory-service:1.0.0
```

## 📖 相关文档

- [数据库设计文档](../14.数据持久化设计文档.md)
- [体系结构设计文档](../13.体系结构的设计.md)
- [接口设计文档](../15.接口设计文档.md)
- [构件设计文档](../16.构件设计文档.md)

## 🤝 贡献指南

1. Fork本项目
2. 创建特性分支 (`git checkout -b feature/AmazingFeature`)
3. 提交更改 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 开启Pull Request

## 📝 更新日志

### v1.0.0 (2025-11-20)
- ✅ 初始化项目结构
- ✅ 创建Maven多模块项目
- ✅ 配置父POM依赖管理
- ✅ 创建订单服务、支付服务、库存服务模块
- ✅ 创建公共模块

## 📄 许可证

本项目仅用于学习和研究目的。

## 👥 团队

- 开发团队：云原生微服务电商平台开发组
- 项目周期：2025-11-18 至今

---

**注意**: 本项目处于开发阶段，部分功能尚未完成。