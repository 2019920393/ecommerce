package com.ecommerce.product.service;

import com.ecommerce.common.exception.BusinessException;
import com.ecommerce.product.domain.entity.Product;
import com.ecommerce.product.dto.ProductRspVO;
import com.ecommerce.product.mapper.CategoryMapper;
import com.ecommerce.product.mapper.ProductMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * ProductService 单元测试
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("ProductService 单元测试")
class ProductServiceTest {

    @Mock
    private ProductMapper productMapper;

    @Mock
    private CategoryMapper categoryMapper;

    @InjectMocks
    private ProductService productService;

    private Product mockProduct;

    @BeforeEach
    void setUp() {
        mockProduct = new Product();
        mockProduct.setProductId(1L);
        mockProduct.setProductName("iPhone 15 Pro");
        mockProduct.setCategoryId(5L);
        mockProduct.setPrice(new BigDecimal("7999.00"));
        mockProduct.setOriginalPrice(new BigDecimal("8999.00"));
        mockProduct.setDescription("Apple iPhone 15 Pro 256GB");
        mockProduct.setMainImage("https://example.com/iphone.jpg");
        mockProduct.setStock(100);
        mockProduct.setSales(50);
        mockProduct.setStatus("ON_SALE");
    }

    @Nested
    @DisplayName("商品查询测试")
    class QueryProductTests {

        @Test
        @DisplayName("根据ID查询商品")
        void testGetProductById_Success() {
            when(productMapper.selectById(1L)).thenReturn(mockProduct);

            ProductRspVO result = productService.getProductById(1L);

            assertNotNull(result, "商品信息不应为空");
            assertEquals(1L, result.getProductId(), "商品ID应匹配");
            assertEquals("iPhone 15 Pro", result.getProductName(), "商品名称应匹配");
        }

        @Test
        @DisplayName("查询不存在的商品")
        void testGetProductById_NotFound() {
            when(productMapper.selectById(999L)).thenReturn(null);

            assertThrows(BusinessException.class, () -> {
                productService.getProductById(999L);
            }, "商品不存在时应抛出异常");
        }

        @Test
        @DisplayName("分页查询商品列表")
        void testGetProductList_Success() {
            Page<Product> mockPage = new Page<>(1, 10);
            mockPage.setRecords(Arrays.asList(mockProduct));
            mockPage.setTotal(1);

            when(productMapper.selectPage(any(Page.class), any())).thenReturn(mockPage);

            Page<ProductRspVO> result = productService.getProductList(null, null, 1, 10);

            assertNotNull(result, "查询结果不应为空");
            assertEquals(1, result.getTotal(), "总数应为1");
            assertEquals(1, result.getRecords().size(), "记录数应为1");
        }
    }

    @Nested
    @DisplayName("库存检查测试")
    class CheckStockTests {

        @Test
        @DisplayName("库存充足")
        void testCheckStock_Sufficient() {
            when(productMapper.selectById(1L)).thenReturn(mockProduct);

            boolean result = productService.checkStock(1L, 50);

            assertTrue(result, "库存充足时应返回true");
        }

        @Test
        @DisplayName("库存不足")
        void testCheckStock_Insufficient() {
            when(productMapper.selectById(1L)).thenReturn(mockProduct);

            boolean result = productService.checkStock(1L, 200);

            assertFalse(result, "库存不足时应返回false");
        }
    }

    @Nested
    @DisplayName("批量查询商品测试")
    class BatchQueryTests {

        @Test
        @DisplayName("批量查询商品信息")
        void testGetProductsByIds() {
            Product product2 = new Product();
            product2.setProductId(2L);
            product2.setProductName("华为 Mate 60");
            product2.setPrice(new BigDecimal("6999.00"));
            product2.setStock(50);
            product2.setSales(10);
            product2.setStatus("ON_SALE");

            when(productMapper.selectBatchIds(anyList()))
                    .thenReturn(Arrays.asList(mockProduct, product2));

            List<ProductRspVO> result = productService.getProductsByIds(Arrays.asList(1L, 2L));

            assertNotNull(result, "查询结果不应为空");
            assertEquals(2, result.size(), "应返回2个商品");
        }
    }

    @Nested
    @DisplayName("商品状态更新测试")
    class UpdateStatusTests {

        @Test
        @DisplayName("上架商品")
        void testUpdateProductStatus_OnSale() {
            mockProduct.setStatus("OFF_SALE");
            when(productMapper.selectById(1L)).thenReturn(mockProduct);
            when(productMapper.updateById(any(Product.class))).thenReturn(1);

            assertDoesNotThrow(() -> {
                productService.updateProductStatus(1L, "ON_SALE");
            });

            verify(productMapper, times(1)).updateById(any(Product.class));
        }

        @Test
        @DisplayName("下架商品")
        void testUpdateProductStatus_OffSale() {
            when(productMapper.selectById(1L)).thenReturn(mockProduct);
            when(productMapper.updateById(any(Product.class))).thenReturn(1);

            assertDoesNotThrow(() -> {
                productService.updateProductStatus(1L, "OFF_SALE");
            });

            verify(productMapper, times(1)).updateById(any(Product.class));
        }
    }

    @Nested
    @DisplayName("库存扣减测试")
    class DeductStockTests {

        @Test
        @DisplayName("扣减库存成功")
        void testDeductStock_Success() {
            when(productMapper.selectById(1L)).thenReturn(mockProduct);
            when(productMapper.updateById(any(Product.class))).thenReturn(1);

            boolean result = productService.deductStock(1L, 10);

            assertTrue(result, "扣减库存应成功");
            verify(productMapper, times(1)).updateById(any(Product.class));
        }

        @Test
        @DisplayName("库存不足扣减失败")
        void testDeductStock_Insufficient() {
            when(productMapper.selectById(1L)).thenReturn(mockProduct);

            boolean result = productService.deductStock(1L, 200);

            assertFalse(result, "库存不足时扣减应失败");
        }
    }
}
