package com.ecommerce.product;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

/**
 * 商品服务启动类
 * 提供商品管理、分类管理、购物车功能
 */
@SpringBootApplication(scanBasePackages = {"com.ecommerce.product", "com.ecommerce.common"})
@MapperScan("com.ecommerce.product.mapper")
@EnableDiscoveryClient
public class ProductServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProductServiceApplication.class, args);
    }
}
