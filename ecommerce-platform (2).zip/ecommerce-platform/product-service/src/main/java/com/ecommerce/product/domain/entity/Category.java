package com.ecommerce.product.domain.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 商品分类实体类
 * 支持两级分类（一级分类、二级分类）
 */
@Data
@TableName("categories")
public class Category {

    /**
     * 分类ID，主键
     */
    @TableId(value = "category_id", type = IdType.AUTO)
    private Long categoryId;

    /**
     * 分类名称
     */
    @TableField("category_name")
    private String categoryName;

    /**
     * 父分类ID，0表示一级分类
     */
    @TableField("parent_id")
    private Long parentId;

    /**
     * 分类层级：1-一级分类，2-二级分类
     */
    @TableField("level")
    private Integer level;

    /**
     * 排序值，越小越靠前
     */
    @TableField("sort_order")
    private Integer sortOrder;

    /**
     * 分类图标URL
     */
    @TableField("icon")
    private String icon;

    /**
     * 状态：1-启用，0-禁用
     */
    @TableField("status")
    private Integer status;

    /**
     * 创建时间
     */
    @TableField(value = "create_time", fill = FieldFill.INSERT)
    private LocalDateTime createTime;

    /**
     * 更新时间
     */
    @TableField(value = "update_time", fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;

    /**
     * 子分类列表（非数据库字段）
     */
    @TableField(exist = false)
    private List<Category> children;
}
