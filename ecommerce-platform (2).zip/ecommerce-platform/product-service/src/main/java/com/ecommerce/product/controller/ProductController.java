package com.ecommerce.product.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ecommerce.common.result.Result;
import com.ecommerce.product.dto.CreateProductRequest;
import com.ecommerce.product.dto.ProductRspVO;
import com.ecommerce.product.service.ProductService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * 商品控制器
 */
@Slf4j
@RestController
@RequestMapping("/api/v1/products")
@RequiredArgsConstructor
@Tag(name = "商品管理", description = "商品的增删改查接口")
public class ProductController {

    private final ProductService productService;
    
    @Value("${upload.path:uploads}")
    private String uploadPath;
    
    @Value("${upload.url-prefix:/uploads}")
    private String urlPrefix;

    @PostMapping
    @Operation(summary = "创建商品", description = "管理员创建新商品")
    public Result<ProductRspVO> createProduct(@Valid @RequestBody CreateProductRequest request) {
        ProductRspVO product = productService.createProduct(request);
        return Result.success(product);
    }

    @GetMapping("/{productId}")
    @Operation(summary = "查询商品详情", description = "根据商品ID查询商品详情")
    public Result<ProductRspVO> getProduct(
            @Parameter(name = "productId", description = "商品ID", required = true)
            @PathVariable("productId") Long productId) {
        ProductRspVO product = productService.getProductById(productId);
        return Result.success(product);
    }

    @GetMapping
    @Operation(summary = "查询商品列表", description = "分页查询商品列表，支持分类筛选和关键词搜索")
    public Result<Page<ProductRspVO>> getProductList(
            @Parameter(name = "categoryId", description = "分类ID")
            @RequestParam(value = "categoryId", required = false) Long categoryId,
            @Parameter(name = "keyword", description = "搜索关键词")
            @RequestParam(value = "keyword", required = false) String keyword,
            @Parameter(name = "pageNum", description = "页码，默认1")
            @RequestParam(value = "pageNum", defaultValue = "1") int pageNum,
            @Parameter(name = "pageSize", description = "每页数量，默认10")
            @RequestParam(value = "pageSize", defaultValue = "10") int pageSize) {
        Page<ProductRspVO> page = productService.getProductList(categoryId, keyword, pageNum, pageSize);
        return Result.success(page);
    }

    @GetMapping("/search")
    @Operation(summary = "搜索商品", description = "根据关键词搜索商品")
    public Result<Page<ProductRspVO>> searchProducts(
            @Parameter(name = "keyword", description = "搜索关键词", required = true)
            @RequestParam("keyword") String keyword,
            @Parameter(name = "pageNum", description = "页码，默认1")
            @RequestParam(value = "pageNum", defaultValue = "1") int pageNum,
            @Parameter(name = "pageSize", description = "每页数量，默认10")
            @RequestParam(value = "pageSize", defaultValue = "10") int pageSize) {
        Page<ProductRspVO> page = productService.getProductList(null, keyword, pageNum, pageSize);
        return Result.success(page);
    }

    @PutMapping("/{productId}/status")
    @Operation(summary = "更新商品状态", description = "上架或下架商品")
    public Result<Void> updateProductStatus(
            @Parameter(name = "productId", description = "商品ID", required = true)
            @PathVariable("productId") Long productId,
            @Parameter(name = "status", description = "状态：ON_SALE-上架，OFF_SALE-下架", required = true)
            @RequestParam("status") String status) {
        productService.updateProductStatus(productId, status);
        return Result.success();
    }

    @PostMapping("/batch")
    @Operation(summary = "批量查询商品", description = "根据商品ID列表批量查询商品信息")
    public Result<List<ProductRspVO>> getProductsByIds(@RequestBody List<Long> productIds) {
        List<ProductRspVO> products = productService.getProductsByIds(productIds);
        return Result.success(products);
    }

    @GetMapping("/{productId}/stock/check")
    @Operation(summary = "检查库存", description = "检查商品库存是否充足")
    public Result<Map<String, Object>> checkStock(
            @Parameter(name = "productId", description = "商品ID", required = true)
            @PathVariable("productId") Long productId,
            @Parameter(name = "quantity", description = "需要的数量", required = true)
            @RequestParam("quantity") Integer quantity) {
        boolean sufficient = productService.checkStock(productId, quantity);
        return Result.success(Map.of("sufficient", sufficient));
    }
    
    @PostMapping("/upload")
    @Operation(summary = "上传商品图片", description = "上传商品主图或详情图片")
    public Result<Map<String, String>> uploadImage(
            @Parameter(description = "图片文件", required = true)
            @RequestParam("file") MultipartFile file) {
        if (file.isEmpty()) {
            return Result.error("文件不能为空");
        }
        
        // 验证文件类型
        String contentType = file.getContentType();
        if (contentType == null || !contentType.startsWith("image/")) {
            return Result.error("只能上传图片文件");
        }
        
        try {
            // 创建上传目录(使用绝对路径)
            Path uploadDir = Paths.get(System.getProperty("user.dir"), uploadPath);
            if (!Files.exists(uploadDir)) {
                Files.createDirectories(uploadDir);
            }
            
            // 生成唯一文件名
            String originalFilename = file.getOriginalFilename();
            String extension = originalFilename != null && originalFilename.contains(".") 
                ? originalFilename.substring(originalFilename.lastIndexOf(".")) 
                : ".jpg";
            String newFilename = UUID.randomUUID().toString() + extension;
            
            // 保存文件
            Path filePath = uploadDir.resolve(newFilename);
            file.transferTo(filePath.toFile());
            
            // 返回访问URL
            String url = urlPrefix + "/" + newFilename;
            log.info("文件上传成功: {}", url);
            
            return Result.success(Map.of("url", url, "filename", newFilename));
        } catch (IOException e) {
            log.error("文件上传失败", e);
            return Result.error("文件上传失败: " + e.getMessage());
        }
    }
}
