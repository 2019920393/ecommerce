package com.ecommerce.product.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.ecommerce.common.exception.BusinessException;
import com.ecommerce.product.domain.entity.Category;
import com.ecommerce.product.dto.CategoryRspVO;
import com.ecommerce.product.dto.CreateCategoryRequest;
import com.ecommerce.product.mapper.CategoryMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 分类服务
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class CategoryService {

    private final CategoryMapper categoryMapper;

    /**
     * 创建分类
     */
    @Transactional
    public CategoryRspVO createCategory(CreateCategoryRequest request) {
        log.info("创建分类: categoryName={}, parentId={}", request.getCategoryName(), request.getParentId());

        // 检查分类名是否重复
        LambdaQueryWrapper<Category> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Category::getCategoryName, request.getCategoryName())
               .eq(Category::getParentId, request.getParentId());
        if (categoryMapper.selectCount(wrapper) > 0) {
            throw new BusinessException(400, "同级分类下已存在相同名称");
        }

        // 确定分类层级
        int level = 1;
        if (request.getParentId() != null && request.getParentId() > 0) {
            Category parent = categoryMapper.selectById(request.getParentId());
            if (parent == null) {
                throw new BusinessException(404, "父分类不存在");
            }
            if (parent.getLevel() >= 2) {
                throw new BusinessException(400, "最多支持两级分类");
            }
            level = parent.getLevel() + 1;
        }

        Category category = new Category();
        category.setCategoryName(request.getCategoryName());
        category.setParentId(request.getParentId() != null ? request.getParentId() : 0L);
        category.setLevel(level);
        category.setSortOrder(request.getSortOrder() != null ? request.getSortOrder() : 0);
        category.setIcon(request.getIcon());
        category.setStatus(1);

        categoryMapper.insert(category);
        log.info("分类创建成功: categoryId={}", category.getCategoryId());

        return convertToRspVO(category);
    }

    /**
     * 查询分类树
     */
    public List<CategoryRspVO> getCategoryTree() {
        log.info("查询分类树");

        // 查询所有启用的分类
        LambdaQueryWrapper<Category> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Category::getStatus, 1)
               .orderByAsc(Category::getSortOrder)
               .orderByAsc(Category::getCategoryId);
        List<Category> allCategories = categoryMapper.selectList(wrapper);

        // 构建树形结构
        return buildTree(allCategories);
    }

    /**
     * 查询所有一级分类
     */
    public List<CategoryRspVO> getTopCategories() {
        LambdaQueryWrapper<Category> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Category::getParentId, 0)
               .eq(Category::getStatus, 1)
               .orderByAsc(Category::getSortOrder);
        List<Category> categories = categoryMapper.selectList(wrapper);
        return categories.stream().map(this::convertToRspVO).collect(Collectors.toList());
    }

    /**
     * 查询子分类
     */
    public List<CategoryRspVO> getSubCategories(Long parentId) {
        LambdaQueryWrapper<Category> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Category::getParentId, parentId)
               .eq(Category::getStatus, 1)
               .orderByAsc(Category::getSortOrder);
        List<Category> categories = categoryMapper.selectList(wrapper);
        return categories.stream().map(this::convertToRspVO).collect(Collectors.toList());
    }

    /**
     * 查询分类详情
     */
    public CategoryRspVO getCategoryById(Long categoryId) {
        Category category = categoryMapper.selectById(categoryId);
        if (category == null) {
            throw new BusinessException(404, "分类不存在");
        }
        return convertToRspVO(category);
    }

    /**
     * 更新分类状态
     */
    @Transactional
    public void updateCategoryStatus(Long categoryId, Integer status) {
        Category category = categoryMapper.selectById(categoryId);
        if (category == null) {
            throw new BusinessException(404, "分类不存在");
        }
        category.setStatus(status);
        categoryMapper.updateById(category);
        log.info("分类状态更新: categoryId={}, status={}", categoryId, status);
    }

    /**
     * 更新分类
     */
    @Transactional
    public CategoryRspVO updateCategory(Long categoryId, CreateCategoryRequest request) {
        log.info("更新分类: categoryId={}, categoryName={}", categoryId, request.getCategoryName());
        
        Category category = categoryMapper.selectById(categoryId);
        if (category == null) {
            throw new BusinessException(404, "分类不存在");
        }
        
        // 更新字段
        if (request.getCategoryName() != null) {
            category.setCategoryName(request.getCategoryName());
        }
        if (request.getSortOrder() != null) {
            category.setSortOrder(request.getSortOrder());
        }
        if (request.getIcon() != null) {
            category.setIcon(request.getIcon());
        }
        if (request.getStatus() != null) {
            category.setStatus(request.getStatus());
        }
        
        categoryMapper.updateById(category);
        log.info("分类更新成功: categoryId={}", categoryId);
        
        return convertToRspVO(category);
    }

    /**
     * 构建分类树
     */
    private List<CategoryRspVO> buildTree(List<Category> allCategories) {
        // 按parentId分组
        Map<Long, List<Category>> groupByParent = allCategories.stream()
                .collect(Collectors.groupingBy(Category::getParentId));

        // 获取一级分类
        List<Category> topCategories = groupByParent.getOrDefault(0L, new ArrayList<>());

        // 递归构建树
        return topCategories.stream().map(category -> {
            CategoryRspVO vo = convertToRspVO(category);
            vo.setChildren(getChildren(category.getCategoryId(), groupByParent));
            return vo;
        }).collect(Collectors.toList());
    }

    /**
     * 递归获取子分类
     */
    private List<CategoryRspVO> getChildren(Long parentId, Map<Long, List<Category>> groupByParent) {
        List<Category> children = groupByParent.getOrDefault(parentId, new ArrayList<>());
        return children.stream().map(category -> {
            CategoryRspVO vo = convertToRspVO(category);
            vo.setChildren(getChildren(category.getCategoryId(), groupByParent));
            return vo;
        }).collect(Collectors.toList());
    }

    private CategoryRspVO convertToRspVO(Category category) {
        return CategoryRspVO.builder()
                .categoryId(category.getCategoryId())
                .categoryName(category.getCategoryName())
                .parentId(category.getParentId())
                .level(category.getLevel())
                .sortOrder(category.getSortOrder())
                .icon(category.getIcon())
                .status(category.getStatus())
                .build();
    }
}
