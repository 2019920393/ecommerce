package com.ecommerce.product.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.ecommerce.common.exception.BusinessException;
import com.ecommerce.common.exception.CartItemNotFoundException;
import com.ecommerce.product.domain.entity.CartItem;
import com.ecommerce.product.domain.entity.Product;
import com.ecommerce.product.dto.AddCartItemRequest;
import com.ecommerce.product.dto.CartItemRspVO;
import com.ecommerce.product.mapper.CartItemMapper;
import com.ecommerce.product.mapper.ProductMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 购物车服务
 * 对应文档：6.2.1类的属性和操作定义.md - ShoppingCart操作
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class CartService {

    private final CartItemMapper cartItemMapper;
    private final ProductMapper productMapper;

    /**
     * 添加商品到购物车
     */
    @Transactional
    public CartItemRspVO addItem(AddCartItemRequest request) {
        // 检查商品是否存在
        Product product = productMapper.selectById(request.getProductId());
        if (product == null) {
            throw new BusinessException(404, "商品不存在");
        }
        if (!product.isAvailable()) {
            throw new BusinessException(400, "商品已下架或库存不足");
        }

        // 检查购物车中是否已有该商品
        LambdaQueryWrapper<CartItem> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(CartItem::getUserId, request.getUserId())
               .eq(CartItem::getProductId, request.getProductId());
        CartItem existingItem = cartItemMapper.selectOne(wrapper);

        if (existingItem != null) {
            // 已存在，增加数量
            existingItem.setQuantity(existingItem.getQuantity() + request.getQuantity());
            existingItem.setPrice(product.getPrice());
            cartItemMapper.updateById(existingItem);
            log.info("更新购物车商品数量，用户ID：{}，商品ID：{}，数量：{}", 
                    request.getUserId(), request.getProductId(), existingItem.getQuantity());
            return convertToRspVO(existingItem, product);
        } else {
            // 不存在，新增
            CartItem cartItem = new CartItem();
            cartItem.setUserId(request.getUserId());
            cartItem.setProductId(request.getProductId());
            cartItem.setProductName(product.getProductName());
            cartItem.setProductImage(product.getMainImage());
            cartItem.setPrice(product.getPrice());
            cartItem.setQuantity(request.getQuantity());
            cartItem.setSelected(true);
            
            cartItemMapper.insert(cartItem);
            log.info("添加商品到购物车，用户ID：{}，商品ID：{}", request.getUserId(), request.getProductId());
            return convertToRspVO(cartItem, product);
        }
    }

    /**
     * 查看用户购物车
     */
    public List<CartItemRspVO> getCartItems(Long userId) {
        LambdaQueryWrapper<CartItem> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(CartItem::getUserId, userId)
               .orderByDesc(CartItem::getAddTime);
        
        List<CartItem> items = cartItemMapper.selectList(wrapper);
        
        return items.stream().map(item -> {
            Product product = productMapper.selectById(item.getProductId());
            return convertToRspVO(item, product);
        }).collect(Collectors.toList());
    }

    /**
     * 根据购物车项ID列表查询
     */
    public List<CartItemRspVO> getCartItemsByIds(Long userId, List<Long> cartItemIds) {
        if (cartItemIds == null || cartItemIds.isEmpty()) {
            return List.of();
        }
        
        LambdaQueryWrapper<CartItem> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(CartItem::getUserId, userId)
               .in(CartItem::getCartItemId, cartItemIds);
        
        List<CartItem> items = cartItemMapper.selectList(wrapper);
        
        return items.stream().map(item -> {
            Product product = productMapper.selectById(item.getProductId());
            return convertToRspVO(item, product);
        }).collect(Collectors.toList());
    }

    /**
     * 修改商品数量
     */
    @Transactional
    public void updateItemQuantity(Long cartItemId, Integer quantity) {
        CartItem item = cartItemMapper.selectById(cartItemId);
        if (item == null) {
            throw new CartItemNotFoundException("购物车项不存在");
        }
        
        if (quantity <= 0) {
            cartItemMapper.deleteById(cartItemId);
            log.info("删除购物车项，ID：{}", cartItemId);
        } else {
            item.setQuantity(quantity);
            cartItemMapper.updateById(item);
            log.info("更新购物车项数量，ID：{}，数量：{}", cartItemId, quantity);
        }
    }

    /**
     * 删除购物车项
     */
    @Transactional
    public void removeItem(Long cartItemId) {
        cartItemMapper.deleteById(cartItemId);
        log.info("删除购物车项，ID：{}", cartItemId);
    }

    /**
     * 清空用户购物车
     */
    @Transactional
    public void clearCart(Long userId) {
        LambdaQueryWrapper<CartItem> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(CartItem::getUserId, userId);
        cartItemMapper.delete(wrapper);
        log.info("清空用户购物车，用户ID：{}", userId);
    }

    /**
     * 删除指定商品（下单后清除已购买的商品）
     */
    @Transactional
    public void removeItemsByIds(Long userId, List<Long> cartItemIds) {
        if (cartItemIds == null || cartItemIds.isEmpty()) {
            return;
        }
        LambdaQueryWrapper<CartItem> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(CartItem::getUserId, userId)
               .in(CartItem::getCartItemId, cartItemIds);
        cartItemMapper.delete(wrapper);
        log.info("删除购物车项，用户ID：{}，数量：{}", userId, cartItemIds.size());
    }

    /**
     * 计算购物车总价
     */
    public BigDecimal calculateTotalPrice(Long userId) {
        List<CartItemRspVO> items = getCartItems(userId);
        return items.stream()
                .filter(item -> item.getSelected() && item.getValid())
                .map(CartItemRspVO::getSubtotal)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    private CartItemRspVO convertToRspVO(CartItem item, Product product) {
        CartItemRspVO rspVO = new CartItemRspVO();
        rspVO.setCartItemId(item.getCartItemId());
        rspVO.setProductId(item.getProductId());
        rspVO.setProductName(item.getProductName());
        rspVO.setProductImage(item.getProductImage());
        rspVO.setPrice(item.getPrice());
        rspVO.setQuantity(item.getQuantity());
        rspVO.setSubtotal(item.calculateSubtotal());
        rspVO.setSelected(item.getSelected());
        rspVO.setValid(product != null && product.isAvailable() && product.hasStock(item.getQuantity()));
        return rspVO;
    }
}
