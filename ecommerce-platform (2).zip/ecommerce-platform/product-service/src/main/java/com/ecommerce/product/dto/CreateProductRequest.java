package com.ecommerce.product.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.*;
import lombok.Data;

import java.math.BigDecimal;

/**
 * 创建商品请求DTO
 */
@Data
@Schema(description = "创建商品请求")
public class CreateProductRequest {

    @NotBlank(message = "商品名称不能为空")
    @Size(max = 100, message = "商品名称最长100字符")
    @Schema(description = "商品名称", required = true, example = "iPhone 15 Pro")
    private String productName;

    @NotNull(message = "分类ID不能为空")
    @Schema(description = "分类ID", required = true, example = "1")
    private Long categoryId;

    @NotNull(message = "商品价格不能为空")
    @DecimalMin(value = "0.01", message = "价格最小0.01元")
    @DecimalMax(value = "99999.99", message = "价格最大99999.99元")
    @Schema(description = "商品价格", required = true, example = "7999.00")
    private BigDecimal price;

    @Schema(description = "原价", example = "8999.00")
    private BigDecimal originalPrice;

    @Size(max = 1000, message = "商品描述最长1000字符")
    @Schema(description = "商品描述", example = "Apple iPhone 15 Pro 256GB")
    private String description;

    @Schema(description = "主图URL", example = "https://example.com/iphone15.jpg")
    private String mainImage;

    @Schema(description = "规格参数JSON", example = "{\"颜色\":\"黑色\",\"存储\":\"256GB\"}")
    private String specification;

    @NotNull(message = "库存数量不能为空")
    @Min(value = 0, message = "库存不能为负数")
    @Schema(description = "库存数量", required = true, example = "100")
    private Integer stock;
}
