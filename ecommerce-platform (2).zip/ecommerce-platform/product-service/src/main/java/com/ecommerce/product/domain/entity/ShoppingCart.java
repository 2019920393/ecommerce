package com.ecommerce.product.domain.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 购物车实体类
 * 对应文档：6.2.1类的属性和操作定义.md - ShoppingCart（购物车）
 */
@Data
@TableName("shopping_carts")
public class ShoppingCart {

    /**
     * 购物车ID，主键
     */
    @TableId(value = "cart_id", type = IdType.AUTO)
    private Long cartId;

    /**
     * 用户ID，外键，唯一
     */
    @TableField("user_id")
    private Long userId;

    /**
     * 创建时间
     */
    @TableField(value = "create_time", fill = FieldFill.INSERT)
    private LocalDateTime createTime;

    /**
     * 更新时间
     */
    @TableField(value = "update_time", fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;

    /**
     * 购物车项列表（非数据库字段）
     */
    @TableField(exist = false)
    private List<CartItem> items;
}
