package com.ecommerce.product.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * 分类响应VO
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "分类响应")
public class CategoryRspVO {

    @Schema(description = "分类ID")
    private Long categoryId;

    @Schema(description = "分类名称")
    private String categoryName;

    @Schema(description = "父分类ID")
    private Long parentId;

    @Schema(description = "分类层级：1-一级，2-二级")
    private Integer level;

    @Schema(description = "排序值")
    private Integer sortOrder;

    @Schema(description = "分类图标URL")
    private String icon;

    @Schema(description = "状态：1-启用，0-禁用")
    private Integer status;

    @Schema(description = "子分类列表")
    private List<CategoryRspVO> children;
}
