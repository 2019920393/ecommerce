package com.ecommerce.product.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ecommerce.common.exception.BusinessException;
import com.ecommerce.product.domain.entity.Category;
import com.ecommerce.product.domain.entity.Product;
import com.ecommerce.product.dto.CreateProductRequest;
import com.ecommerce.product.dto.ProductRspVO;
import com.ecommerce.product.mapper.CategoryMapper;
import com.ecommerce.product.mapper.ProductMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.util.List;
import java.util.stream.Collectors;

/**
 * 商品服务
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ProductService {

    private final ProductMapper productMapper;
    private final CategoryMapper categoryMapper;

    /**
     * 创建商品
     */
    @Transactional
    public ProductRspVO createProduct(CreateProductRequest request) {
        Product product = new Product();
        BeanUtils.copyProperties(request, product);
        product.setStatus("ON_SALE");
        product.setSales(0);
        
        productMapper.insert(product);
        log.info("创建商品成功，商品ID：{}", product.getProductId());
        
        return convertToRspVO(product);
    }

    /**
     * 根据ID查询商品
     */
    public ProductRspVO getProductById(Long productId) {
        Product product = productMapper.selectById(productId);
        if (product == null) {
            throw new BusinessException(404, "商品不存在");
        }
        return convertToRspVO(product);
    }

    /**
     * 查询商品列表（分页）
     */
    public Page<ProductRspVO> getProductList(Long categoryId, String keyword, int pageNum, int pageSize) {
        return getProductList(categoryId, keyword, null, pageNum, pageSize);
    }

    /**
     * 查询商品列表（分页，支持状态筛选）
     */
    public Page<ProductRspVO> getProductList(Long categoryId, String keyword, String status, int pageNum, int pageSize) {
        Page<Product> page = new Page<>(pageNum, pageSize);
        
        LambdaQueryWrapper<Product> wrapper = new LambdaQueryWrapper<>();
        // status为null时查询所有状态（管理后台），否则按状态筛选
        if (StringUtils.hasText(status)) {
            wrapper.eq(Product::getStatus, status);
        }
        
        if (categoryId != null) {
            wrapper.eq(Product::getCategoryId, categoryId);
        }
        if (StringUtils.hasText(keyword)) {
            wrapper.like(Product::getProductName, keyword);
        }
        wrapper.orderByDesc(Product::getCreateTime);
        
        Page<Product> productPage = productMapper.selectPage(page, wrapper);
        
        Page<ProductRspVO> rspPage = new Page<>(productPage.getCurrent(), productPage.getSize(), productPage.getTotal());
        rspPage.setRecords(productPage.getRecords().stream()
                .map(this::convertToRspVO)
                .collect(Collectors.toList()));
        
        return rspPage;
    }

    /**
     * 更新商品状态（上架/下架）
     */
    @Transactional
    public void updateProductStatus(Long productId, String status) {
        Product product = productMapper.selectById(productId);
        if (product == null) {
            throw new BusinessException(404, "商品不存在");
        }
        product.setStatus(status);
        productMapper.updateById(product);
        log.info("更新商品状态，商品ID：{}，状态：{}", productId, status);
    }

    /**
     * 批量查询商品
     */
    public List<ProductRspVO> getProductsByIds(List<Long> productIds) {
        if (productIds == null || productIds.isEmpty()) {
            return List.of();
        }
        List<Product> products = productMapper.selectBatchIds(productIds);
        return products.stream().map(this::convertToRspVO).collect(Collectors.toList());
    }

    /**
     * 检查库存是否充足
     */
    public boolean checkStock(Long productId, Integer quantity) {
        Product product = productMapper.selectById(productId);
        if (product == null) {
            return false;
        }
        return product.hasStock(quantity);
    }

    /**
     * 扣减库存
     */
    @Transactional
    public boolean deductStock(Long productId, Integer quantity) {
        Product product = productMapper.selectById(productId);
        if (product == null || !product.hasStock(quantity)) {
            return false;
        }
        product.setStock(product.getStock() - quantity);
        product.setSales(product.getSales() + quantity);
        productMapper.updateById(product);
        log.info("扣减库存成功，商品ID：{}，扣减数量：{}", productId, quantity);
        return true;
    }

    /**
     * 释放库存
     */
    @Transactional
    public void releaseStock(Long productId, Integer quantity) {
        Product product = productMapper.selectById(productId);
        if (product != null) {
            product.setStock(product.getStock() + quantity);
            productMapper.updateById(product);
            log.info("释放库存成功，商品ID：{}，释放数量：{}", productId, quantity);
        }
    }

    private ProductRspVO convertToRspVO(Product product) {
        ProductRspVO rspVO = new ProductRspVO();
        BeanUtils.copyProperties(product, rspVO);
        
        // 查询分类名称
        if (product.getCategoryId() != null) {
            Category category = categoryMapper.selectById(product.getCategoryId());
            if (category != null) {
                rspVO.setCategoryName(category.getCategoryName());
            }
        }
        return rspVO;
    }
}
