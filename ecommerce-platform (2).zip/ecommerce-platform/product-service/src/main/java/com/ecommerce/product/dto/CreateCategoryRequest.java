package com.ecommerce.product.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

/**
 * 创建分类请求DTO
 */
@Data
@Schema(description = "创建分类请求")
public class CreateCategoryRequest {

    @Schema(description = "分类名称", example = "手机数码", required = true)
    @NotBlank(message = "分类名称不能为空")
    private String categoryName;

    @Schema(description = "父分类ID，0表示一级分类", example = "0")
    private Long parentId = 0L;

    @Schema(description = "排序值，越小越靠前", example = "1")
    private Integer sortOrder = 0;

    @Schema(description = "分类图标URL", example = "http://example.com/icon.png")
    private String icon;

    @Schema(description = "状态：1-启用，0-禁用", example = "1")
    private Integer status;
}
