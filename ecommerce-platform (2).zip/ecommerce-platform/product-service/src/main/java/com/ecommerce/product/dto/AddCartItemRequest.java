package com.ecommerce.product.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

/**
 * 添加购物车请求DTO
 */
@Data
@Schema(description = "添加购物车请求")
public class AddCartItemRequest {

    @NotNull(message = "用户ID不能为空")
    @Schema(description = "用户ID", required = true, example = "1001")
    private Long userId;

    @NotNull(message = "商品ID不能为空")
    @Schema(description = "商品ID", required = true, example = "1")
    private Long productId;

    @NotNull(message = "数量不能为空")
    @Min(value = 1, message = "数量最小为1")
    @Schema(description = "数量", required = true, example = "1")
    private Integer quantity;
}
