package com.ecommerce.product.controller;

import com.ecommerce.common.result.Result;
import com.ecommerce.product.dto.CategoryRspVO;
import com.ecommerce.product.dto.CreateCategoryRequest;
import com.ecommerce.product.service.CategoryService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 分类控制器
 */
@Slf4j
@RestController
@RequestMapping("/api/v1/categories")
@RequiredArgsConstructor
@Tag(name = "分类管理", description = "商品分类的增删改查接口")
public class CategoryController {

    private final CategoryService categoryService;

    @PostMapping
    @Operation(summary = "创建分类", description = "创建商品分类，支持两级分类")
    public Result<CategoryRspVO> createCategory(@Valid @RequestBody CreateCategoryRequest request) {
        log.info("创建分类请求: categoryName={}", request.getCategoryName());
        CategoryRspVO category = categoryService.createCategory(request);
        return Result.success(category);
    }

    @GetMapping("/tree")
    @Operation(summary = "查询分类树", description = "获取完整的分类树形结构")
    public Result<List<CategoryRspVO>> getCategoryTree() {
        List<CategoryRspVO> tree = categoryService.getCategoryTree();
        return Result.success(tree);
    }

    @GetMapping("/top")
    @Operation(summary = "查询一级分类", description = "获取所有一级分类")
    public Result<List<CategoryRspVO>> getTopCategories() {
        List<CategoryRspVO> categories = categoryService.getTopCategories();
        return Result.success(categories);
    }

    @GetMapping("/{parentId}/children")
    @Operation(summary = "查询子分类", description = "根据父分类ID查询子分类")
    public Result<List<CategoryRspVO>> getSubCategories(
            @Parameter(name = "parentId", description = "父分类ID", required = true)
            @PathVariable("parentId") Long parentId) {
        List<CategoryRspVO> categories = categoryService.getSubCategories(parentId);
        return Result.success(categories);
    }

    @GetMapping("/{categoryId}")
    @Operation(summary = "查询分类详情", description = "根据分类ID查询分类详情")
    public Result<CategoryRspVO> getCategory(
            @Parameter(name = "categoryId", description = "分类ID", required = true)
            @PathVariable("categoryId") Long categoryId) {
        CategoryRspVO category = categoryService.getCategoryById(categoryId);
        return Result.success(category);
    }

    @PutMapping("/{categoryId}")
    @Operation(summary = "更新分类", description = "更新分类信息")
    public Result<CategoryRspVO> updateCategory(
            @Parameter(name = "categoryId", description = "分类ID", required = true)
            @PathVariable("categoryId") Long categoryId,
            @Valid @RequestBody CreateCategoryRequest request) {
        log.info("更新分类请求: categoryId={}, categoryName={}", categoryId, request.getCategoryName());
        CategoryRspVO category = categoryService.updateCategory(categoryId, request);
        return Result.success(category);
    }

    @PutMapping("/{categoryId}/status")
    @Operation(summary = "更新分类状态", description = "启用或禁用分类")
    public Result<Void> updateCategoryStatus(
            @Parameter(name = "categoryId", description = "分类ID", required = true)
            @PathVariable("categoryId") Long categoryId,
            @Parameter(name = "status", description = "状态：1-启用，0-禁用", required = true)
            @RequestParam("status") Integer status) {
        categoryService.updateCategoryStatus(categoryId, status);
        return Result.success();
    }
}
