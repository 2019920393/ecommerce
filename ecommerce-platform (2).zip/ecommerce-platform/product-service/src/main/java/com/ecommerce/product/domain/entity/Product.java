package com.ecommerce.product.domain.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 商品实体类
 * 对应文档：6.2.1类的属性和操作定义.md - Product（商品）
 */
@Data
@TableName("products")
public class Product {

    /**
     * 商品ID，主键
     */
    @TableId(value = "product_id", type = IdType.AUTO)
    private Long productId;

    /**
     * 商品名称，最长100字符
     */
    @TableField("product_name")
    private String productName;

    /**
     * 分类ID
     */
    @TableField("category_id")
    private Long categoryId;

    /**
     * 商品价格，精确到0.01元，范围0.01-99999.99
     */
    @TableField("price")
    private BigDecimal price;

    /**
     * 原价
     */
    @TableField("original_price")
    private BigDecimal originalPrice;

    /**
     * 商品描述，最长1000字符
     */
    @TableField("description")
    private String description;

    /**
     * 主图URL，最长255字符
     */
    @TableField("main_image")
    private String mainImage;

    /**
     * 商品图片列表，JSON格式，最多10张
     */
    @TableField("images")
    private String images;

    /**
     * 规格参数，JSON格式
     */
    @TableField("specification")
    private String specification;

    /**
     * 库存数量
     */
    @TableField("stock")
    private Integer stock;

    /**
     * 销量
     */
    @TableField("sales")
    private Integer sales;

    /**
     * 商品状态：ON_SALE-在售，OFF_SALE-下架，SOLD_OUT-售罄
     */
    @TableField("status")
    private String status;

    /**
     * 创建时间
     */
    @TableField(value = "create_time", fill = FieldFill.INSERT)
    private LocalDateTime createTime;

    /**
     * 更新时间
     */
    @TableField(value = "update_time", fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;

    /**
     * 逻辑删除标记
     */
    @TableLogic
    @TableField("is_deleted")
    private Integer isDeleted;

    // ========== 业务方法 ==========

    /**
     * 判断商品是否可购买
     */
    public boolean isAvailable() {
        return "ON_SALE".equals(status) && stock != null && stock > 0;
    }

    /**
     * 判断库存是否充足
     */
    public boolean hasStock(Integer quantity) {
        return stock != null && stock >= quantity;
    }

    /**
     * 获取显示价格
     */
    public BigDecimal getDisplayPrice() {
        return price;
    }
}
