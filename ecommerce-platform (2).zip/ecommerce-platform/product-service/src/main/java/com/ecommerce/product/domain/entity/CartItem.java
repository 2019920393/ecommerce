package com.ecommerce.product.domain.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 购物车项实体类
 * 对应文档：6.2.1类的属性和操作定义.md - CartItem（购物车项）
 */
@Data
@TableName("cart_items")
public class CartItem {

    /**
     * 购物车项ID，主键
     */
    @TableId(value = "cart_item_id", type = IdType.AUTO)
    private Long cartItemId;

    /**
     * 购物车ID，外键
     */
    @TableField("cart_id")
    private Long cartId;

    /**
     * 用户ID（冗余字段，便于查询）
     */
    @TableField("user_id")
    private Long userId;

    /**
     * 商品ID
     */
    @TableField("product_id")
    private Long productId;

    /**
     * 商品名称（快照）
     */
    @TableField("product_name")
    private String productName;

    /**
     * 商品图片URL（快照）
     */
    @TableField("product_image")
    private String productImage;

    /**
     * 商品价格，加入购物车时的快照价格
     */
    @TableField("price")
    private BigDecimal price;

    /**
     * 数量，1-999
     */
    @TableField("quantity")
    private Integer quantity;

    /**
     * 是否选中，用于结算
     */
    @TableField("selected")
    private Boolean selected;

    /**
     * 添加时间
     */
    @TableField(value = "add_time", fill = FieldFill.INSERT)
    private LocalDateTime addTime;

    /**
     * 更新时间
     */
    @TableField(value = "update_time", fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;

    // ========== 业务方法 ==========

    /**
     * 计算小计金额
     */
    public BigDecimal calculateSubtotal() {
        if (price == null || quantity == null) {
            return BigDecimal.ZERO;
        }
        return price.multiply(BigDecimal.valueOf(quantity));
    }

    /**
     * 判断是否过期（30天未更新）
     */
    public boolean isExpired() {
        if (updateTime == null) {
            return false;
        }
        return updateTime.plusDays(30).isBefore(LocalDateTime.now());
    }
}
