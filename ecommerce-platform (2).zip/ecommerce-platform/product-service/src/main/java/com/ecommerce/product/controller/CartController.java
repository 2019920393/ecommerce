package com.ecommerce.product.controller;

import com.ecommerce.common.result.Result;
import com.ecommerce.product.dto.AddCartItemRequest;
import com.ecommerce.product.dto.CartItemRspVO;
import com.ecommerce.product.service.CartService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

/**
 * 购物车控制器
 */
@RestController
@RequestMapping("/api/v1/cart")
@RequiredArgsConstructor
@Tag(name = "购物车管理", description = "购物车的增删改查接口")
public class CartController {

    private final CartService cartService;

    @PostMapping("/items")
    @Operation(summary = "添加商品到购物车", description = "将商品添加到用户购物车")
    public Result<CartItemRspVO> addItem(@Valid @RequestBody AddCartItemRequest request) {
        CartItemRspVO item = cartService.addItem(request);
        return Result.success(item);
    }

    @GetMapping("/{userId}")
    @Operation(summary = "查看购物车", description = "查看用户购物车中的所有商品")
    public Result<List<CartItemRspVO>> getCartItems(
            @Parameter(name = "userId", description = "用户ID", required = true)
            @PathVariable("userId") Long userId) {
        List<CartItemRspVO> items = cartService.getCartItems(userId);
        return Result.success(items);
    }

    @GetMapping("/{userId}/items")
    @Operation(summary = "根据ID列表查询购物车项", description = "根据购物车项ID列表查询，用于订单确认页")
    public Result<List<CartItemRspVO>> getCartItemsByIds(
            @Parameter(name = "userId", description = "用户ID", required = true)
            @PathVariable("userId") Long userId,
            @Parameter(name = "cartItemIds", description = "购物车项ID列表", required = true)
            @RequestParam("cartItemIds") List<Long> cartItemIds) {
        List<CartItemRspVO> items = cartService.getCartItemsByIds(userId, cartItemIds);
        return Result.success(items);
    }

    @PutMapping("/items/{cartItemId}")
    @Operation(summary = "修改商品数量", description = "修改购物车中商品的数量")
    public Result<Void> updateItemQuantity(
            @Parameter(name = "cartItemId", description = "购物车项ID", required = true)
            @PathVariable("cartItemId") Long cartItemId,
            @Parameter(name = "quantity", description = "新数量", required = true)
            @RequestParam("quantity") Integer quantity) {
        cartService.updateItemQuantity(cartItemId, quantity);
        return Result.success();
    }

    @DeleteMapping("/items/{cartItemId}")
    @Operation(summary = "删除购物车项", description = "从购物车中删除指定商品")
    public Result<Void> removeItem(
            @Parameter(name = "cartItemId", description = "购物车项ID", required = true)
            @PathVariable("cartItemId") Long cartItemId) {
        cartService.removeItem(cartItemId);
        return Result.success();
    }

    @DeleteMapping("/{userId}")
    @Operation(summary = "清空购物车", description = "清空用户购物车中的所有商品")
    public Result<Void> clearCart(
            @Parameter(name = "userId", description = "用户ID", required = true)
            @PathVariable("userId") Long userId) {
        cartService.clearCart(userId);
        return Result.success();
    }

    @GetMapping("/{userId}/total")
    @Operation(summary = "计算购物车总价", description = "计算用户购物车中已选商品的总价")
    public Result<Map<String, BigDecimal>> calculateTotal(
            @Parameter(name = "userId", description = "用户ID", required = true)
            @PathVariable("userId") Long userId) {
        BigDecimal total = cartService.calculateTotalPrice(userId);
        return Result.success(Map.of("totalPrice", total));
    }
}
