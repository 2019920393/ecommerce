package com.ecommerce.product.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.math.BigDecimal;

/**
 * 购物车项响应VO
 */
@Data
@Schema(description = "购物车项信息")
public class CartItemRspVO {

    @Schema(description = "购物车项ID")
    private Long cartItemId;

    @Schema(description = "商品ID")
    private Long productId;

    @Schema(description = "商品名称")
    private String productName;

    @Schema(description = "商品图片")
    private String productImage;

    @Schema(description = "商品单价")
    private BigDecimal price;

    @Schema(description = "数量")
    private Integer quantity;

    @Schema(description = "小计金额")
    private BigDecimal subtotal;

    @Schema(description = "是否选中")
    private Boolean selected;

    @Schema(description = "商品是否有效（是否下架或库存不足）")
    private Boolean valid;
}
