-- 商品服务数据库初始化脚本
-- 数据库：product_db

-- 创建数据库
CREATE DATABASE IF NOT EXISTS product_db DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE product_db;

-- 商品分类表
CREATE TABLE IF NOT EXISTS `categories` (
  `category_id` BIGINT(20) NOT NULL AUTO_INCREMENT COMMENT '分类ID，主键',
  `category_name` VARCHAR(50) NOT NULL COMMENT '分类名称',
  `parent_id` BIGINT(20) NOT NULL DEFAULT 0 COMMENT '父分类ID，0表示一级分类',
  `level` INT(11) NOT NULL DEFAULT 1 COMMENT '分类层级：1-一级分类，2-二级分类',
  `sort_order` INT(11) NOT NULL DEFAULT 0 COMMENT '排序值，越小越靠前',
  `icon` VARCHAR(255) NULL COMMENT '分类图标URL',
  `status` TINYINT(1) NOT NULL DEFAULT 1 COMMENT '状态：1-启用，0-禁用',
  `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`category_id`),
  KEY `idx_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='商品分类表';

-- 商品表
CREATE TABLE IF NOT EXISTS `products` (
  `product_id` BIGINT(20) NOT NULL AUTO_INCREMENT COMMENT '商品ID，主键',
  `product_name` VARCHAR(100) NOT NULL COMMENT '商品名称',
  `category_id` BIGINT(20) NOT NULL COMMENT '分类ID',
  `price` DECIMAL(10,2) NOT NULL COMMENT '商品价格',
  `original_price` DECIMAL(10,2) NULL COMMENT '原价',
  `description` VARCHAR(1000) NULL COMMENT '商品描述',
  `main_image` VARCHAR(255) NULL COMMENT '主图URL',
  `images` TEXT NULL COMMENT '商品图片列表，JSON格式',
  `specification` TEXT NULL COMMENT '规格参数，JSON格式',
  `stock` INT(11) NOT NULL DEFAULT 0 COMMENT '库存数量',
  `sales` INT(11) NOT NULL DEFAULT 0 COMMENT '销量',
  `status` VARCHAR(20) NOT NULL DEFAULT 'ON_SALE' COMMENT '商品状态：ON_SALE-在售，OFF_SALE-下架，SOLD_OUT-售罄',
  `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_deleted` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '逻辑删除标记',
  PRIMARY KEY (`product_id`),
  KEY `idx_category_id` (`category_id`),
  KEY `idx_status` (`status`),
  KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='商品表';

-- 购物车项表（简化设计，不单独创建购物车表）
CREATE TABLE IF NOT EXISTS `cart_items` (
  `cart_item_id` BIGINT(20) NOT NULL AUTO_INCREMENT COMMENT '购物车项ID，主键',
  `cart_id` BIGINT(20) NULL COMMENT '购物车ID（预留）',
  `user_id` BIGINT(20) NOT NULL COMMENT '用户ID',
  `product_id` BIGINT(20) NOT NULL COMMENT '商品ID',
  `product_name` VARCHAR(100) NOT NULL COMMENT '商品名称（快照）',
  `product_image` VARCHAR(255) NULL COMMENT '商品图片URL（快照）',
  `price` DECIMAL(10,2) NOT NULL COMMENT '商品价格（快照）',
  `quantity` INT(11) NOT NULL DEFAULT 1 COMMENT '数量',
  `selected` TINYINT(1) NOT NULL DEFAULT 1 COMMENT '是否选中',
  `add_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `update_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`cart_item_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_product_id` (`product_id`),
  UNIQUE KEY `uk_user_product` (`user_id`, `product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='购物车项表';

-- 初始化分类数据
INSERT INTO `categories` (`category_name`, `parent_id`, `level`, `sort_order`) VALUES
('手机数码', 0, 1, 1),
('电脑办公', 0, 1, 2),
('家用电器', 0, 1, 3),
('服装鞋包', 0, 1, 4);

INSERT INTO `categories` (`category_name`, `parent_id`, `level`, `sort_order`) VALUES
('手机', 1, 2, 1),
('平板电脑', 1, 2, 2),
('笔记本电脑', 2, 2, 1),
('台式机', 2, 2, 2),
('冰箱', 3, 2, 1),
('洗衣机', 3, 2, 2),
('男装', 4, 2, 1),
('女装', 4, 2, 2);

-- 初始化商品数据
INSERT INTO `products` (`product_name`, `category_id`, `price`, `original_price`, `description`, `main_image`, `stock`, `sales`, `status`) VALUES
('iPhone 15 Pro 256GB', 5, 7999.00, 8999.00, 'Apple iPhone 15 Pro 256GB 黑色钛金属', 'https://example.com/iphone15.jpg', 100, 50, 'ON_SALE'),
('华为 Mate 60 Pro', 5, 6999.00, 7499.00, '华为 Mate 60 Pro 12GB+512GB 雅丹黑', 'https://example.com/mate60.jpg', 80, 30, 'ON_SALE'),
('小米14 Ultra', 5, 5999.00, 6299.00, '小米14 Ultra 16GB+512GB 黑色', 'https://example.com/mi14.jpg', 120, 45, 'ON_SALE'),
('iPad Pro 12.9英寸', 6, 8999.00, 9499.00, 'Apple iPad Pro 12.9英寸 M2芯片 256GB', 'https://example.com/ipadpro.jpg', 50, 20, 'ON_SALE'),
('MacBook Pro 14英寸', 7, 14999.00, 15999.00, 'Apple MacBook Pro 14英寸 M3 Pro芯片', 'https://example.com/macbook.jpg', 30, 15, 'ON_SALE'),
('联想小新Pro 16', 7, 5999.00, 6499.00, '联想小新Pro 16 2024 酷睿Ultra 7', 'https://example.com/xiaoxin.jpg', 60, 25, 'ON_SALE'),
('海尔冰箱 BCD-470', 9, 3999.00, 4299.00, '海尔冰箱 470升 对开门 变频风冷无霜', 'https://example.com/haier.jpg', 40, 18, 'ON_SALE'),
('西门子洗衣机', 10, 2999.00, 3299.00, '西门子 10公斤 滚筒洗衣机 变频', 'https://example.com/siemens.jpg', 35, 12, 'ON_SALE');
