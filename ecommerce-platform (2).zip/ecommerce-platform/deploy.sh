#!/bin/bash

# 云原生微服务电商平台 - 部署脚本
# 使用方法: ./deploy.sh [dev|test|prod] [version]

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# 参数检查
if [ $# -lt 2 ]; then
    echo -e "${RED}使用方法: $0 [dev|test|prod] [version]${NC}"
    echo "示例: $0 dev 1"
    exit 1
fi

DEPLOY_ENV=$1
BUILD_VERSION=$2
DOCKER_REGISTRY="docker.io"
DOCKER_NAMESPACE="ecommerce"

echo -e "${GREEN}========== 部署开始 ==========${NC}"
echo "部署环境: $DEPLOY_ENV"
echo "构建版本: $BUILD_VERSION"
echo ""

# 根据环境选择配置文件
case $DEPLOY_ENV in
    dev)
        COMPOSE_FILE="docker-compose.yml"
        MYSQL_PASSWORD="123456"
        NACOS_ENABLED="true"
        ;;
    test)
        COMPOSE_FILE="docker-compose.test.yml"
        MYSQL_PASSWORD="test123456"
        NACOS_ENABLED="true"
        ;;
    prod)
        COMPOSE_FILE="docker-compose.prod.yml"
        MYSQL_PASSWORD=$(cat /etc/ecommerce/mysql_password)
        NACOS_ENABLED="true"
        ;;
    *)
        echo -e "${RED}无效的环境: $DEPLOY_ENV${NC}"
        exit 1
        ;;
esac

# 检查Docker和Docker Compose
if ! command -v docker &> /dev/null; then
    echo -e "${RED}Docker未安装${NC}"
    exit 1
fi

if ! command -v docker-compose &> /dev/null; then
    echo -e "${RED}Docker Compose未安装${NC}"
    exit 1
fi

echo -e "${GREEN}✅ Docker环境检查通过${NC}"
echo ""

# 停止现有容器
echo -e "${YELLOW}停止现有容器...${NC}"
docker-compose -f $COMPOSE_FILE down || true
sleep 5

# 更新镜像标签
echo -e "${YELLOW}更新镜像标签...${NC}"
docker tag ${DOCKER_REGISTRY}/${DOCKER_NAMESPACE}/order-service:${BUILD_VERSION} \
           ${DOCKER_REGISTRY}/${DOCKER_NAMESPACE}/order-service:latest || true

docker tag ${DOCKER_REGISTRY}/${DOCKER_NAMESPACE}/user-service:${BUILD_VERSION} \
           ${DOCKER_REGISTRY}/${DOCKER_NAMESPACE}/user-service:latest || true

docker tag ${DOCKER_REGISTRY}/${DOCKER_NAMESPACE}/product-service:${BUILD_VERSION} \
           ${DOCKER_REGISTRY}/${DOCKER_NAMESPACE}/product-service:latest || true

docker tag ${DOCKER_REGISTRY}/${DOCKER_NAMESPACE}/payment-service:${BUILD_VERSION} \
           ${DOCKER_REGISTRY}/${DOCKER_NAMESPACE}/payment-service:latest || true

docker tag ${DOCKER_REGISTRY}/${DOCKER_NAMESPACE}/gateway-service:${BUILD_VERSION} \
           ${DOCKER_REGISTRY}/${DOCKER_NAMESPACE}/gateway-service:latest || true

echo -e "${GREEN}✅ 镜像标签更新完成${NC}"
echo ""

# 启动容器
echo -e "${YELLOW}启动容器...${NC}"
export MYSQL_ROOT_PASSWORD=$MYSQL_PASSWORD
export NACOS_ENABLED=$NACOS_ENABLED
export JWT_SECRET="ecommerce-platform-secret-key-2025"

docker-compose -f $COMPOSE_FILE up -d

echo -e "${GREEN}✅ 容器启动完成${NC}"
echo ""

# 等待服务启动
echo -e "${YELLOW}等待服务启动...${NC}"
sleep 30

# 验证服务健康状态
echo -e "${YELLOW}验证服务健康状态...${NC}"

SERVICES=(
    "gateway:8080"
    "product:8081"
    "payment:8082"
    "order:8083"
    "user:8084"
)

for service in "${SERVICES[@]}"; do
    IFS=':' read -r name port <<< "$service"
    
    echo -n "检查 $name 服务 (端口 $port)... "
    
    for i in {1..10}; do
        if curl -f http://localhost:$port/actuator/health &> /dev/null; then
            echo -e "${GREEN}✅ 正常${NC}"
            break
        fi
        
        if [ $i -eq 10 ]; then
            echo -e "${RED}❌ 超时${NC}"
            exit 1
        fi
        
        sleep 3
    done
done

echo ""
echo -e "${GREEN}========== 部署完成 ==========${NC}"
echo ""
echo "服务访问地址:"
echo "  Gateway: http://localhost:8080"
echo "  Product: http://localhost:8081/swagger-ui.html"
echo "  Payment: http://localhost:8082/swagger-ui.html"
echo "  Order:   http://localhost:8083/swagger-ui.html"
echo "  User:    http://localhost:8084/swagger-ui.html"
echo "  Nacos:   http://localhost:8848/nacos"
echo ""
echo "默认账号: admin / nacos"
echo ""
