package com.ecommerce.common.constant;

/**
 * 系统常量类
 * 
 * <p>定义系统中使用的所有常量，包括业务常量、时间常量、编号前缀等。</p>
 * 
 * @author 系统架构团队
 * @since 1.0.0
 */
public class Constants {
    
    /**
     * 私有构造函数，防止实例化
     */
    private Constants() {
        throw new UnsupportedOperationException("Constants class cannot be instantiated");
    }
    
    // ==================== 订单相关常量 ====================
    
    /**
     * 订单号前缀
     */
    public static final String ORDER_NO_PREFIX = "ORD";
    
    /**
     * 订单超时时间（分钟）
     * 订单创建后30分钟内未支付将自动取消
     */
    public static final int ORDER_TIMEOUT_MINUTES = 30;
    
    /**
     * 订单号序列号长度
     */
    public static final int ORDER_NO_SEQUENCE_LENGTH = 6;
    
    // ==================== 支付相关常量 ====================
    
    /**
     * 支付流水号前缀
     */
    public static final String PAYMENT_NO_PREFIX = "PAY";
    
    /**
     * 支付超时时间（分钟）
     * 支付订单创建后15分钟内未完成支付将超时
     */
    public static final int PAYMENT_TIMEOUT_MINUTES = 15;
    
    /**
     * 支付流水号序列号长度
     */
    public static final int PAYMENT_NO_SEQUENCE_LENGTH = 7;
    
    // ==================== 库存相关常量 ====================
    
    /**
     * 库存锁定超时时间（分钟）
     * 与订单超时时间保持一致
     */
    public static final int STOCK_LOCK_TIMEOUT_MINUTES = ORDER_TIMEOUT_MINUTES;
    
    /**
     * 乐观锁最大重试次数
     */
    public static final int OPTIMISTIC_LOCK_MAX_RETRY = 3;
    
    // ==================== 运费相关常量 ====================
    
    /**
     * 免运费门槛金额（元）
     */
    public static final double FREE_SHIPPING_THRESHOLD = 99.00;
    
    /**
     * 默认运费（元）
     */
    public static final double DEFAULT_SHIPPING_FEE = 10.00;
    
    // ==================== 日期时间格式常量 ====================
    
    /**
     * 标准日期时间格式
     */
    public static final String DATETIME_FORMAT = "yyyy-MM-dd HH:mm:ss";
    
    /**
     * 标准日期格式
     */
    public static final String DATE_FORMAT = "yyyy-MM-dd";
    
    /**
     * 标准时间格式
     */
    public static final String TIME_FORMAT = "HH:mm:ss";
    
    /**
     * 订单号日期格式（年月日）
     */
    public static final String ORDER_NO_DATE_FORMAT = "yyyyMMdd";
    
    /**
     * 支付流水号日期格式（年月日）
     */
    public static final String PAYMENT_NO_DATE_FORMAT = "yyyyMMdd";
    
    // ==================== 缓存相关常量 ====================
    
    /**
     * 缓存键前缀 - 订单
     */
    public static final String CACHE_KEY_ORDER = "order:";
    
    /**
     * 缓存键前缀 - 支付订单
     */
    public static final String CACHE_KEY_PAYMENT = "payment:";
    
    /**
     * 缓存键前缀 - 库存
     */
    public static final String CACHE_KEY_INVENTORY = "inventory:";
    
    /**
     * 缓存键前缀 - 用户
     */
    public static final String CACHE_KEY_USER = "user:";
    
    /**
     * 缓存过期时间（秒） - 短期缓存（5分钟）
     */
    public static final long CACHE_EXPIRE_SHORT = 300L;
    
    /**
     * 缓存过期时间（秒） - 中期缓存（30分钟）
     */
    public static final long CACHE_EXPIRE_MEDIUM = 1800L;
    
    /**
     * 缓存过期时间（秒） - 长期缓存（2小时）
     */
    public static final long CACHE_EXPIRE_LONG = 7200L;
    
    // ==================== 消息队列相关常量 ====================
    
    /**
     * 交换机名称 - 支付
     */
    public static final String EXCHANGE_PAYMENT = "payment.exchange";
    
    /**
     * 路由键 - 支付成功
     */
    public static final String ROUTING_KEY_PAYMENT_SUCCESS = "payment.success";
    
    /**
     * 路由键 - 支付失败
     */
    public static final String ROUTING_KEY_PAYMENT_FAILED = "payment.failed";
    
    /**
     * 队列名称 - 支付成功
     */
    public static final String QUEUE_PAYMENT_SUCCESS = "payment.success.queue";
    
    /**
     * 队列名称 - 支付失败
     */
    public static final String QUEUE_PAYMENT_FAILED = "payment.failed.queue";
    
    // ==================== 分页相关常量 ====================
    
    /**
     * 默认页码
     */
    public static final int DEFAULT_PAGE_NUM = 1;
    
    /**
     * 默认每页大小
     */
    public static final int DEFAULT_PAGE_SIZE = 10;
    
    /**
     * 最大每页大小
     */
    public static final int MAX_PAGE_SIZE = 100;
    
    // ==================== 业务规则常量 ====================
    
    /**
     * 订单备注最大长度
     */
    public static final int ORDER_REMARK_MAX_LENGTH = 500;
    
    /**
     * 商品名称最大长度
     */
    public static final int PRODUCT_NAME_MAX_LENGTH = 200;
    
    /**
     * 收货人姓名最大长度
     */
    public static final int RECEIVER_NAME_MAX_LENGTH = 50;
    
    /**
     * 收货人电话长度
     */
    public static final int RECEIVER_PHONE_LENGTH = 11;
    
    /**
     * 详细地址最大长度
     */
    public static final int DETAIL_ADDRESS_MAX_LENGTH = 200;
    
    // ==================== 系统配置常量 ====================
    
    /**
     * 系统名称
     */
    public static final String SYSTEM_NAME = "云原生微服务电商平台";
    
    /**
     * 系统版本
     */
    public static final String SYSTEM_VERSION = "1.0.0";
    
    /**
     * 系统编码
     */
    public static final String SYSTEM_CHARSET = "UTF-8";
    
    /**
     * 成功标识
     */
    public static final String SUCCESS = "success";
    
    /**
     * 失败标识
     */
    public static final String FAIL = "fail";
}