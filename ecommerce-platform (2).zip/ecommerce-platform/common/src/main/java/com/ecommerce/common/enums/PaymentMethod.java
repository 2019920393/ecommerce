package com.ecommerce.common.enums;

/**
 * 支付方式枚举
 * 
 * <p>定义系统支持的所有支付方式。</p>
 * 
 * @author 系统架构团队
 * @since 1.0.0
 */
public enum PaymentMethod {
    
    /**
     * 支付宝支付
     */
    ALIPAY("ALIPAY", "支付宝支付"),
    
    /**
     * 微信支付
     */
    WECHAT("WECHAT", "微信支付"),
    
    /**
     * 银行卡支付
     */
    BANK_CARD("BANK_CARD", "银行卡支付"),
    
    /**
     * 模拟支付（用于测试）
     */
    MOCK("MOCK", "模拟支付");
    
    /**
     * 支付方式代码
     */
    private final String code;
    
    /**
     * 支付方式描述
     */
    private final String description;
    
    /**
     * 构造函数
     * 
     * @param code 支付方式代码
     * @param description 支付方式描述
     */
    PaymentMethod(String code, String description) {
        this.code = code;
        this.description = description;
    }
    
    /**
     * 获取支付方式代码
     * 
     * @return 支付方式代码
     */
    public String getCode() {
        return code;
    }
    
    /**
     * 获取支付方式描述
     * 
     * @return 支付方式描述
     */
    public String getDescription() {
        return description;
    }
    
    /**
     * 根据代码获取枚举
     * 
     * @param code 支付方式代码
     * @return 支付方式枚举，如果不存在返回null
     */
    public static PaymentMethod fromCode(String code) {
        for (PaymentMethod method : PaymentMethod.values()) {
            if (method.getCode().equals(code)) {
                return method;
            }
        }
        return null;
    }
    
    /**
     * 判断是否为第三方支付
     * 支付宝和微信支付属于第三方支付
     * 
     * @return 是否为第三方支付
     */
    public boolean isThirdParty() {
        return this == ALIPAY || this == WECHAT;
    }
    
    /**
     * 判断是否为模拟支付
     * 
     * @return 是否为模拟支付
     */
    public boolean isMock() {
        return this == MOCK;
    }
}