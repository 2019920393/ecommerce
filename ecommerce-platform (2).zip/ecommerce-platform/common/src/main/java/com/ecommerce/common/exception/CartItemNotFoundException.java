package com.ecommerce.common.exception;

/**
 * 购物车项不存在异常
 * 
 * <p>当根据购物车项ID查询购物车项时，如果购物车项不存在则抛出此异常。</p>
 * 
 * @author 系统架构团队
 * @since 1.0.0
 */
public class CartItemNotFoundException extends BusinessException {
    
    /**
     * 默认错误码：404
     */
    private static final Integer DEFAULT_CODE = 404;
    
    /**
     * 构造函数 - 仅包含错误消息
     * 
     * @param message 错误消息
     */
    public CartItemNotFoundException(String message) {
        super(DEFAULT_CODE, message);
    }
    
    /**
     * 构造函数 - 包含购物车项ID信息
     * 
     * @param message 错误消息
     * @param cartItemIds 购物车项ID列表
     */
    public CartItemNotFoundException(String message, Object cartItemIds) {
        super(DEFAULT_CODE, message, cartItemIds);
    }
    
    /**
     * 构造函数 - 包含错误消息和原始异常
     * 
     * @param message 错误消息
     * @param cause 原始异常
     */
    public CartItemNotFoundException(String message, Throwable cause) {
        super(DEFAULT_CODE, message, cause);
    }
}