package com.ecommerce.common.exception;

/**
 * 收货地址不存在异常
 * 
 * <p>当根据地址ID查询收货地址时，如果地址不存在则抛出此异常。</p>
 * 
 * @author 系统架构团队
 * @since 1.0.0
 */
public class AddressNotFoundException extends BusinessException {
    
    /**
     * 默认错误码：404
     */
    private static final Integer DEFAULT_CODE = 404;
    
    /**
     * 构造函数 - 仅包含错误消息
     * 
     * @param message 错误消息
     */
    public AddressNotFoundException(String message) {
        super(DEFAULT_CODE, message);
    }
    
    /**
     * 构造函数 - 包含地址ID信息
     * 
     * @param message 错误消息
     * @param addressId 地址ID
     */
    public AddressNotFoundException(String message, Long addressId) {
        super(DEFAULT_CODE, message, addressId);
    }
    
    /**
     * 构造函数 - 包含错误消息和原始异常
     * 
     * @param message 错误消息
     * @param cause 原始异常
     */
    public AddressNotFoundException(String message, Throwable cause) {
        super(DEFAULT_CODE, message, cause);
    }
}