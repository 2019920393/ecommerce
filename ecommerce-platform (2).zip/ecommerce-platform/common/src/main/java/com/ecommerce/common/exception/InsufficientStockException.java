package com.ecommerce.common.exception;

/**
 * 库存不足异常
 * 
 * <p>当商品库存不足以满足订单需求时抛出此异常。</p>
 * 
 * <p>异常信息通常包含库存不足的商品列表，便于前端展示详细信息。</p>
 * 
 * @author 系统架构团队
 * @since 1.0.0
 */
public class InsufficientStockException extends BusinessException {
    
    /**
     * 默认错误码：4001
     */
    private static final Integer DEFAULT_CODE = 4001;
    
    /**
     * 构造函数 - 仅包含错误消息
     * 
     * @param message 错误消息
     */
    public InsufficientStockException(String message) {
        super(DEFAULT_CODE, message);
    }
    
    /**
     * 构造函数 - 包含错误消息和库存不足的商品列表
     * 
     * @param message 错误消息
     * @param insufficientProducts 库存不足的商品列表
     */
    public InsufficientStockException(String message, Object insufficientProducts) {
        super(DEFAULT_CODE, message, insufficientProducts);
    }
    
    /**
     * 构造函数 - 包含错误消息和原始异常
     * 
     * @param message 错误消息
     * @param cause 原始异常
     */
    public InsufficientStockException(String message, Throwable cause) {
        super(DEFAULT_CODE, message, cause);
    }
}