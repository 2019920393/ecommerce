package com.ecommerce.payment.message;

import com.ecommerce.payment.config.RabbitMQConfig;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Service;

/**
 * 支付消息发送服务
 * 对应文档：15.接口设计文档.md - 3.6 消息队列接口
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class PaymentMessageProducer {

    private final RabbitTemplate rabbitTemplate;

    /**
     * 发送支付成功消息
     * @param message 支付成功消息
     */
    public void sendPaymentSuccessMessage(PaymentSuccessMessage message) {
        log.info("发送支付成功消息: paymentNumber={}, orderNumber={}", 
                message.getPaymentNumber(), message.getOrderNumber());
        
        rabbitTemplate.convertAndSend(
            RabbitMQConfig.PAYMENT_EXCHANGE,
            RabbitMQConfig.PAYMENT_SUCCESS_ROUTING_KEY,
            message
        );
        
        log.info("支付成功消息发送完成: paymentNumber={}", message.getPaymentNumber());
    }

    /**
     * 发送支付失败消息
     * @param message 支付失败消息
     */
    public void sendPaymentFailedMessage(PaymentFailedMessage message) {
        log.info("发送支付失败消息: paymentNumber={}, orderNumber={}, reason={}", 
                message.getPaymentNumber(), message.getOrderNumber(), message.getFailReason());
        
        rabbitTemplate.convertAndSend(
            RabbitMQConfig.PAYMENT_EXCHANGE,
            RabbitMQConfig.PAYMENT_FAILED_ROUTING_KEY,
            message
        );
        
        log.info("支付失败消息发送完成: paymentNumber={}", message.getPaymentNumber());
    }
}
