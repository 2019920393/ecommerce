package com.ecommerce.payment.controller;

import com.ecommerce.common.result.Result;
import com.ecommerce.payment.dto.*;
import com.ecommerce.payment.service.PaymentService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;

/**
 * 支付控制器
 * 对应文档：6.3.1精化后的CRC卡设计文档.md - PaymentController
 */
@Slf4j
@RestController
@RequestMapping("/api/v1/payments")
@RequiredArgsConstructor
@Tag(name = "支付管理", description = "支付订单创建、模拟支付、支付状态查询等接口")
public class PaymentController {

    private final PaymentService paymentService;

    @PostMapping
    @Operation(summary = "创建支付订单", description = "根据订单号创建支付订单")
    public Result<PaymentRspVO> createPayment(
            @Valid @RequestBody CreatePaymentRequest request,
            @Parameter(name = "amount", description = "支付金额", required = true)
            @RequestParam("amount") BigDecimal amount) {
        log.info("创建支付订单请求: orderNumber={}, amount={}", request.getOrderNumber(), amount);
        PaymentRspVO payment = paymentService.createPaymentOrder(request, amount);
        return Result.success(payment);
    }

    @PostMapping("/{paymentNumber}/pay")
    @Operation(summary = "模拟支付", description = "执行模拟支付，90%概率成功")
    public Result<PaymentRspVO> mockPay(
            @Parameter(name = "paymentNumber", description = "支付流水号", required = true)
            @PathVariable("paymentNumber") String paymentNumber,
            @Parameter(name = "forceSuccess", description = "强制成功（测试用）")
            @RequestParam(value = "forceSuccess", required = false) Boolean forceSuccess) {
        log.info("模拟支付请求: paymentNumber={}, forceSuccess={}", paymentNumber, forceSuccess);
        PaymentRspVO payment = paymentService.processPayment(paymentNumber, forceSuccess);
        return Result.success(payment);
    }

    @GetMapping
    @Operation(summary = "查询支付记录列表", description = "分页查询所有支付记录（管理后台用）")
    public Result<List<PaymentRspVO>> getPaymentList(
            @Parameter(name = "page", description = "页码") @RequestParam(value = "page", defaultValue = "1") Integer page,
            @Parameter(name = "size", description = "每页数量") @RequestParam(value = "size", defaultValue = "10") Integer size) {
        log.info("查询支付记录列表: page={}, size={}", page, size);
        List<PaymentRspVO> list = paymentService.getPaymentList(page, size);
        return Result.success(list);
    }

    @GetMapping("/{paymentNumber}")
    @Operation(summary = "查询支付状态", description = "根据支付流水号查询支付状态")
    public Result<PaymentRspVO> getPaymentStatus(
            @Parameter(name = "paymentNumber", description = "支付流水号", required = true)
            @PathVariable("paymentNumber") String paymentNumber) {
        log.info("查询支付状态: paymentNumber={}", paymentNumber);
        PaymentRspVO payment = paymentService.getPaymentStatus(paymentNumber);
        return Result.success(payment);
    }

    @GetMapping("/order/{orderNumber}")
    @Operation(summary = "根据订单号查询支付", description = "根据订单号查询最新的支付订单")
    public Result<PaymentRspVO> getPaymentByOrderNumber(
            @Parameter(name = "orderNumber", description = "订单号", required = true)
            @PathVariable("orderNumber") String orderNumber) {
        log.info("根据订单号查询支付: orderNumber={}", orderNumber);
        PaymentRspVO payment = paymentService.getPaymentByOrderNumber(orderNumber);
        return Result.success(payment);
    }

    @GetMapping("/user/{userId}")
    @Operation(summary = "查询用户支付记录", description = "查询用户的所有支付记录")
    public Result<List<PaymentRecordRspVO>> getUserPaymentRecords(
            @Parameter(name = "userId", description = "用户ID", required = true)
            @PathVariable("userId") Long userId) {
        log.info("查询用户支付记录: userId={}", userId);
        List<PaymentRecordRspVO> records = paymentService.getUserPaymentRecords(userId);
        return Result.success(records);
    }
}
