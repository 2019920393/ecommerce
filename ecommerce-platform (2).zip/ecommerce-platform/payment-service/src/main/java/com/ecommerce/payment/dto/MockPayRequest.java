package com.ecommerce.payment.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 模拟支付请求DTO
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "模拟支付请求")
public class MockPayRequest {

    @Schema(description = "支付流水号", example = "PAY20251205001", required = true)
    @NotBlank(message = "支付流水号不能为空")
    private String paymentNumber;

    @Schema(description = "是否强制成功（用于测试）", example = "true")
    private Boolean forceSuccess;
}
