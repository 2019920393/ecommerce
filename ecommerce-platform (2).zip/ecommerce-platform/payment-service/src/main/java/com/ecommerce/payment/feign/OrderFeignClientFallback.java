package com.ecommerce.payment.feign;

import com.ecommerce.common.result.Result;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.openfeign.FallbackFactory;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * 订单服务Feign降级处理
 * 
 * @author ecommerce-team
 * @since 1.0.0
 */
@Slf4j
@Component
public class OrderFeignClientFallback implements FallbackFactory<OrderFeignClient> {

    @Override
    public OrderFeignClient create(Throwable cause) {
        log.error("订单服务调用失败: {}", cause.getMessage());
        
        return new OrderFeignClient() {
            @Override
            public Result<Void> updateOrderStatus(String orderNumber, String status) {
                log.error("更新订单状态降级: orderNumber={}, status={}", orderNumber, status);
                return Result.error("订单服务暂不可用");
            }

            @Override
            public Result<Map<String, Object>> getOrder(String orderNumber) {
                log.error("获取订单详情降级: orderNumber={}", orderNumber);
                return Result.error("订单服务暂不可用");
            }
        };
    }
}
