package com.ecommerce.payment.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 创建支付请求DTO
 * 对应文档：6.3.1精化后的CRC卡设计文档.md - CreatePaymentRequest
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "创建支付请求")
public class CreatePaymentRequest {

    @Schema(description = "订单号", example = "ORD20251205001", required = true)
    @NotBlank(message = "订单号不能为空")
    private String orderNumber;

    @Schema(description = "用户ID", example = "1", required = true)
    @NotNull(message = "用户ID不能为空")
    private Long userId;

    @Schema(description = "支付方式：ALIPAY/WECHAT/BANK_CARD/MOCK", example = "MOCK", required = true)
    @NotBlank(message = "支付方式不能为空")
    private String paymentMethod;
}
