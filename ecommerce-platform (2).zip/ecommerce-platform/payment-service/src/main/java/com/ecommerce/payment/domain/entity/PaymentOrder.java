package com.ecommerce.payment.domain.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 支付订单实体
 * 对应文档：6.2.1类的属性和操作定义.md - PaymentOrder
 */
@Data
@TableName("payment_order")
public class PaymentOrder {

    /**
     * 支付ID，主键
     */
    @TableId(type = IdType.AUTO)
    private Long paymentId;

    /**
     * 支付流水号，20位字符，格式PAY+时间戳+随机数，唯一
     */
    private String paymentNumber;

    /**
     * 订单ID，外键
     */
    private Long orderId;

    /**
     * 订单号
     */
    private String orderNumber;

    /**
     * 用户ID
     */
    private Long userId;

    /**
     * 支付金额，精确到0.01元
     */
    private BigDecimal amount;

    /**
     * 支付方式：ALIPAY/WECHAT/BANK_CARD/MOCK
     */
    private String paymentMethod;

    /**
     * 支付状态：PENDING/SUCCESS/FAILED
     */
    private String status;

    /**
     * 第三方交易ID
     */
    private String transactionId;

    /**
     * 交易详情，JSON格式
     */
    private String transactionDetails;

    /**
     * 创建时间
     */
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;

    /**
     * 支付完成时间
     */
    private LocalDateTime payTime;

    /**
     * 过期时间，创建后15分钟
     */
    private LocalDateTime expireTime;

    /**
     * 更新时间
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;

    /**
     * 判断是否过期
     */
    public boolean isExpired() {
        return expireTime != null && LocalDateTime.now().isAfter(expireTime);
    }

    /**
     * 判断是否可支付
     */
    public boolean canPay() {
        return "PENDING".equals(status) && !isExpired();
    }

    /**
     * 判断是否支付成功
     */
    public boolean isSuccess() {
        return "SUCCESS".equals(status);
    }

    /**
     * 判断是否支付失败
     */
    public boolean isFailed() {
        return "FAILED".equals(status);
    }
}
