package com.ecommerce.payment.task;

import com.ecommerce.payment.service.PaymentService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * 支付超时定时任务
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class PaymentTimeoutTask {

    private final PaymentService paymentService;

    /**
     * 每分钟检查一次过期支付订单
     */
    @Scheduled(fixedRate = 60000)
    public void checkExpiredPayments() {
        log.debug("开始检查过期支付订单...");
        try {
            paymentService.handleExpiredPayments();
        } catch (Exception e) {
            log.error("检查过期支付订单失败", e);
        }
    }
}
