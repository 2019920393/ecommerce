package com.ecommerce.payment.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ecommerce.payment.domain.entity.PaymentOrder;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * 支付订单数据访问层
 * 对应文档：6.3.1精化后的CRC卡设计文档.md - PaymentOrderRepository
 */
@Mapper
public interface PaymentOrderMapper extends BaseMapper<PaymentOrder> {

    /**
     * 根据支付流水号查询
     */
    @Select("SELECT * FROM payment_order WHERE payment_number = #{paymentNumber}")
    PaymentOrder findByPaymentNumber(@Param("paymentNumber") String paymentNumber);

    /**
     * 根据订单号查询
     */
    @Select("SELECT * FROM payment_order WHERE order_number = #{orderNumber} ORDER BY create_time DESC LIMIT 1")
    PaymentOrder findByOrderNumber(@Param("orderNumber") String orderNumber);

    /**
     * 根据订单ID查询
     */
    @Select("SELECT * FROM payment_order WHERE order_id = #{orderId} ORDER BY create_time DESC LIMIT 1")
    PaymentOrder findByOrderId(@Param("orderId") Long orderId);

    /**
     * 查询过期未支付的支付订单
     */
    @Select("SELECT * FROM payment_order WHERE status = 'PENDING' AND expire_time < NOW()")
    List<PaymentOrder> findExpiredPayments();

    /**
     * 根据用户ID查询支付订单列表
     */
    @Select("SELECT * FROM payment_order WHERE user_id = #{userId} ORDER BY create_time DESC")
    List<PaymentOrder> findByUserId(@Param("userId") Long userId);

    /**
     * 查询所有支付订单（管理后台用）
     */
    @Select("SELECT * FROM payment_order ORDER BY create_time DESC")
    List<PaymentOrder> findAll();
}
