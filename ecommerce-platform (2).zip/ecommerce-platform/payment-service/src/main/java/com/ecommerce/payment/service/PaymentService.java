package com.ecommerce.payment.service;

import cn.hutool.core.util.IdUtil;
import com.ecommerce.common.exception.BusinessException;
import com.ecommerce.common.exception.OrderExpiredException;
import com.ecommerce.common.exception.PaymentNotFoundException;
import com.ecommerce.common.result.Result;
import com.ecommerce.payment.domain.entity.PaymentOrder;
import com.ecommerce.payment.domain.entity.PaymentRecord;
import com.ecommerce.payment.dto.CreatePaymentRequest;
import com.ecommerce.payment.dto.PaymentRecordRspVO;
import com.ecommerce.payment.dto.PaymentRspVO;
import com.ecommerce.payment.feign.OrderFeignClient;
import com.ecommerce.payment.mapper.PaymentOrderMapper;
import com.ecommerce.payment.mapper.PaymentRecordMapper;
import com.ecommerce.payment.message.PaymentFailedMessage;
import com.ecommerce.payment.message.PaymentMessageProducer;
import com.ecommerce.payment.message.PaymentSuccessMessage;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

/**
 * 支付服务
 * 对应文档：6.2.1类的属性和操作定义.md - PaymentService
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class PaymentService {

    private final PaymentOrderMapper paymentOrderMapper;
    private final PaymentRecordMapper paymentRecordMapper;
    private final OrderFeignClient orderFeignClient;
    private final PaymentMessageProducer paymentMessageProducer;

    /**
     * 模拟支付成功率，默认0.9（90%）
     */
    @Value("${payment.mock.success-rate:0.9}")
    private double mockPaymentSuccessRate;

    /**
     * 支付订单过期时间（分钟）
     */
    @Value("${payment.expire-minutes:15}")
    private int expireMinutes;

    private final Random random = new Random();

    /**
     * 创建支付订单
     * 对应文档操作：+createPaymentOrder(orderNumber, paymentMethod): PaymentOrder
     */
    @Transactional
    public PaymentRspVO createPaymentOrder(CreatePaymentRequest request, BigDecimal amount) {
        log.info("创建支付订单: orderNumber={}, amount={}, paymentMethod={}", 
                request.getOrderNumber(), amount, request.getPaymentMethod());

        // 检查是否已有待支付的支付订单
        PaymentOrder existingPayment = paymentOrderMapper.findByOrderNumber(request.getOrderNumber());
        if (existingPayment != null && existingPayment.canPay()) {
            log.info("已存在待支付订单，返回现有支付订单: paymentNumber={}", existingPayment.getPaymentNumber());
            return convertToRspVO(existingPayment);
        }

        // 生成支付流水号
        String paymentNumber = generatePaymentNumber();

        // 创建支付订单
        PaymentOrder paymentOrder = new PaymentOrder();
        paymentOrder.setPaymentNumber(paymentNumber);
        paymentOrder.setOrderNumber(request.getOrderNumber());
        paymentOrder.setUserId(request.getUserId());
        paymentOrder.setAmount(amount);
        paymentOrder.setPaymentMethod(request.getPaymentMethod());
        paymentOrder.setStatus("PENDING");
        paymentOrder.setExpireTime(LocalDateTime.now().plusMinutes(expireMinutes));

        paymentOrderMapper.insert(paymentOrder);
        log.info("支付订单创建成功: paymentNumber={}", paymentNumber);

        return convertToRspVO(paymentOrder);
    }

    /**
     * 处理模拟支付
     * 对应文档操作：+processPayment(paymentNumber): Boolean
     */
    @Transactional
    public PaymentRspVO processPayment(String paymentNumber, Boolean forceSuccess) {
        log.info("处理模拟支付: paymentNumber={}, forceSuccess={}", paymentNumber, forceSuccess);

        PaymentOrder paymentOrder = paymentOrderMapper.findByPaymentNumber(paymentNumber);
        if (paymentOrder == null) {
            throw new PaymentNotFoundException("支付订单不存在: " + paymentNumber);
        }

        // 检查是否可支付
        if (!paymentOrder.canPay()) {
            if (paymentOrder.isExpired()) {
                throw new OrderExpiredException("支付订单已过期");
            }
            if (paymentOrder.isSuccess()) {
                throw new BusinessException(400, "订单已支付，请勿重复支付");
            }
            throw new BusinessException(400, "支付订单状态异常，无法支付");
        }

        // 模拟支付结果
        boolean success;
        if (forceSuccess != null) {
            success = forceSuccess;
        } else {
            success = random.nextDouble() < mockPaymentSuccessRate;
        }

        // 更新支付订单状态
        LocalDateTime now = LocalDateTime.now();
        String transactionId = "TXN" + IdUtil.getSnowflakeNextIdStr();

        if (success) {
            paymentOrder.setStatus("SUCCESS");
            paymentOrder.setPayTime(now);
            paymentOrder.setTransactionId(transactionId);
            paymentOrder.setTransactionDetails("{\"result\":\"success\",\"mock\":true}");
            log.info("模拟支付成功: paymentNumber={}, transactionId={}", paymentNumber, transactionId);
            
            // 支付成功，更新订单状态
            handlePaymentSuccess(paymentOrder);
        } else {
            paymentOrder.setStatus("FAILED");
            paymentOrder.setTransactionDetails("{\"result\":\"failed\",\"reason\":\"模拟支付失败\",\"mock\":true}");
            log.info("模拟支付失败: paymentNumber={}", paymentNumber);
            
            // 支付失败，释放库存（发送失败消息）
            handlePaymentFailed(paymentOrder, "模拟支付失败");
        }

        paymentOrderMapper.updateById(paymentOrder);

        // 创建支付记录
        createPaymentRecord(paymentOrder);

        return convertToRspVO(paymentOrder);
    }

    /**
     * 查询支付状态
     * 对应文档操作：+queryPaymentStatus(paymentNumber): PaymentStatus
     */
    public PaymentRspVO getPaymentStatus(String paymentNumber) {
        log.info("查询支付状态: paymentNumber={}", paymentNumber);

        PaymentOrder paymentOrder = paymentOrderMapper.findByPaymentNumber(paymentNumber);
        if (paymentOrder == null) {
            throw new PaymentNotFoundException("支付订单不存在: " + paymentNumber);
        }

        return convertToRspVO(paymentOrder);
    }

    /**
     * 根据订单号查询支付订单
     */
    public PaymentRspVO getPaymentByOrderNumber(String orderNumber) {
        log.info("根据订单号查询支付订单: orderNumber={}", orderNumber);

        PaymentOrder paymentOrder = paymentOrderMapper.findByOrderNumber(orderNumber);
        if (paymentOrder == null) {
            throw new PaymentNotFoundException("该订单暂无支付记录");
        }

        return convertToRspVO(paymentOrder);
    }

    /**
     * 查询用户支付记录
     * 对应文档操作：+queryUserPayments(userId, startTime, endTime): List<PaymentRecord>
     */
    public List<PaymentRecordRspVO> getUserPaymentRecords(Long userId) {
        log.info("查询用户支付记录: userId={}", userId);

        List<PaymentRecord> records = paymentRecordMapper.findByUserId(userId);
        return records.stream()
                .map(this::convertToRecordRspVO)
                .collect(Collectors.toList());
    }

    /**
     * 查询支付记录列表（管理后台用）
     */
    public List<PaymentRspVO> getPaymentList(Integer page, Integer size) {
        log.info("查询支付记录列表: page={}, size={}", page, size);
        
        List<PaymentOrder> payments = paymentOrderMapper.findAll();
        return payments.stream()
                .map(this::convertToRspVO)
                .collect(Collectors.toList());
    }

    /**
     * 处理过期支付订单（定时任务调用）
     */
    @Transactional
    public void handleExpiredPayments() {
        log.info("开始处理过期支付订单");

        List<PaymentOrder> expiredPayments = paymentOrderMapper.findExpiredPayments();
        log.info("发现过期支付订单数量: {}", expiredPayments.size());

        for (PaymentOrder payment : expiredPayments) {
            try {
                payment.setStatus("FAILED");
                payment.setTransactionDetails("{\"result\":\"failed\",\"reason\":\"支付超时\"}");
                paymentOrderMapper.updateById(payment);

                createPaymentRecord(payment);
                log.info("过期支付订单处理完成: paymentNumber={}", payment.getPaymentNumber());
            } catch (Exception e) {
                log.error("处理过期支付订单失败: paymentNumber={}", payment.getPaymentNumber(), e);
            }
        }

        log.info("过期支付订单处理完成");
    }

    /**
     * 生成支付流水号
     */
    private String generatePaymentNumber() {
        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));
        String random = String.format("%06d", this.random.nextInt(1000000));
        return "PAY" + timestamp + random;
    }

    /**
     * 创建支付记录
     */
    private void createPaymentRecord(PaymentOrder paymentOrder) {
        PaymentRecord record = new PaymentRecord();
        record.setPaymentNumber(paymentOrder.getPaymentNumber());
        record.setUserId(paymentOrder.getUserId());
        record.setOrderId(paymentOrder.getOrderId());
        record.setOrderNumber(paymentOrder.getOrderNumber());
        record.setAmount(paymentOrder.getAmount());
        record.setPaymentMethod(paymentOrder.getPaymentMethod());
        record.setStatus(paymentOrder.getStatus());
        record.setPayTime(paymentOrder.getPayTime());
        record.setTransactionId(paymentOrder.getTransactionId());
        record.setTransactionDetails(paymentOrder.getTransactionDetails());

        paymentRecordMapper.insert(record);
        log.info("支付记录创建成功: paymentNumber={}, status={}", 
                paymentOrder.getPaymentNumber(), paymentOrder.getStatus());
    }

    /**
     * 转换为响应VO
     */
    private PaymentRspVO convertToRspVO(PaymentOrder paymentOrder) {
        String statusDesc = switch (paymentOrder.getStatus()) {
            case "PENDING" -> "待支付";
            case "SUCCESS" -> "支付成功";
            case "FAILED" -> "支付失败";
            default -> paymentOrder.getStatus();
        };

        return PaymentRspVO.builder()
                .paymentNumber(paymentOrder.getPaymentNumber())
                .orderNumber(paymentOrder.getOrderNumber())
                .amount(paymentOrder.getAmount())
                .paymentMethod(paymentOrder.getPaymentMethod())
                .status(paymentOrder.getStatus())
                .statusDescription(statusDesc)
                .createTime(paymentOrder.getCreateTime())
                .payTime(paymentOrder.getPayTime())
                .expireTime(paymentOrder.getExpireTime())
                .transactionId(paymentOrder.getTransactionId())
                .build();
    }

    /**
     * 转换为记录响应VO
     */
    private PaymentRecordRspVO convertToRecordRspVO(PaymentRecord record) {
        return PaymentRecordRspVO.builder()
                .recordId(record.getRecordId())
                .paymentNumber(record.getPaymentNumber())
                .orderNumber(record.getOrderNumber())
                .amount(record.getAmount())
                .paymentMethod(record.getPaymentMethod())
                .status(record.getStatus())
                .payTime(record.getPayTime())
                .transactionId(record.getTransactionId())
                .createTime(record.getCreateTime())
                .build();
    }

    /**
     * 处理支付成功回调
     * 
     * <p>支付成功后的业务流程（通过RabbitMQ异步通知）：</p>
     * <ol>
     *   <li>发送支付成功消息到RabbitMQ</li>
     *   <li>订单服务消费消息并更新订单状态</li>
     *   <li>同时保留HTTP同步调用作为备用</li>
     * </ol>
     * 
     * @param paymentOrder 支付订单
     */
    private void handlePaymentSuccess(PaymentOrder paymentOrder) {
        log.info("处理支付成功回调: paymentNumber={}, orderNumber={}", 
                paymentOrder.getPaymentNumber(), paymentOrder.getOrderNumber());

        try {
            // 1. 发送支付成功消息到RabbitMQ（异步通知订单服务）
            PaymentSuccessMessage message = PaymentSuccessMessage.builder()
                    .paymentNumber(paymentOrder.getPaymentNumber())
                    .orderNumber(paymentOrder.getOrderNumber())
                    .userId(paymentOrder.getUserId())
                    .amount(paymentOrder.getAmount())
                    .paymentMethod(paymentOrder.getPaymentMethod())
                    .status(paymentOrder.getStatus())
                    .transactionId(paymentOrder.getTransactionId())
                    .payTime(paymentOrder.getPayTime())
                    .timestamp(System.currentTimeMillis())
                    .build();
            
            paymentMessageProducer.sendPaymentSuccessMessage(message);
            log.info("支付成功消息已发送到MQ: paymentNumber={}", paymentOrder.getPaymentNumber());

            // 2. 同时保留HTTP同步调用作为备用（可选，保证兼容性）
            Result<Void> updateResult = orderFeignClient.updateOrderStatus(
                    paymentOrder.getOrderNumber(), 
                    "PENDING_SHIPMENT"
            );
            
            if (updateResult.isSuccess()) {
                log.info("订单状态同步更新成功: orderNumber={}, newStatus=PENDING_SHIPMENT", 
                        paymentOrder.getOrderNumber());
            } else {
                log.warn("订单状态同步更新失败（MQ消息已发送）: orderNumber={}, message={}", 
                        paymentOrder.getOrderNumber(), updateResult.getMessage());
            }

            log.info("支付成功回调处理完成: paymentNumber={}", paymentOrder.getPaymentNumber());

        } catch (Exception e) {
            log.error("支付成功回调处理异常: paymentNumber={}, orderNumber={}", 
                    paymentOrder.getPaymentNumber(), paymentOrder.getOrderNumber(), e);
            // 异常不影响支付结果，仅记录日志
        }
    }

    /**
     * 处理支付失败
     * 
     * @param paymentOrder 支付订单
     * @param failReason 失败原因
     */
    private void handlePaymentFailed(PaymentOrder paymentOrder, String failReason) {
        log.info("处理支付失败: paymentNumber={}, orderNumber={}, reason={}", 
                paymentOrder.getPaymentNumber(), paymentOrder.getOrderNumber(), failReason);

        try {
            // 发送支付失败消息到RabbitMQ
            PaymentFailedMessage message = PaymentFailedMessage.builder()
                    .paymentNumber(paymentOrder.getPaymentNumber())
                    .orderNumber(paymentOrder.getOrderNumber())
                    .userId(paymentOrder.getUserId())
                    .amount(paymentOrder.getAmount())
                    .paymentMethod(paymentOrder.getPaymentMethod())
                    .status(paymentOrder.getStatus())
                    .failReason(failReason)
                    .timestamp(System.currentTimeMillis())
                    .build();
            
            paymentMessageProducer.sendPaymentFailedMessage(message);
            log.info("支付失败消息已发送到MQ: paymentNumber={}", paymentOrder.getPaymentNumber());

        } catch (Exception e) {
            log.error("发送支付失败消息异常: paymentNumber={}", paymentOrder.getPaymentNumber(), e);
        }
    }
}
