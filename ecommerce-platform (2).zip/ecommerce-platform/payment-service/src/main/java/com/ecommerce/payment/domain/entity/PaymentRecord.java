package com.ecommerce.payment.domain.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 支付记录实体
 * 对应文档：6.2.1类的属性和操作定义.md - PaymentRecord
 * 用于对账和审计
 */
@Data
@TableName("payment_record")
public class PaymentRecord {

    /**
     * 记录ID，主键
     */
    @TableId(type = IdType.AUTO)
    private Long recordId;

    /**
     * 支付流水号
     */
    private String paymentNumber;

    /**
     * 用户ID
     */
    private Long userId;

    /**
     * 订单ID
     */
    private Long orderId;

    /**
     * 订单号
     */
    private String orderNumber;

    /**
     * 支付金额
     */
    private BigDecimal amount;

    /**
     * 支付方式：ALIPAY/WECHAT/BANK_CARD/MOCK
     */
    private String paymentMethod;

    /**
     * 支付状态：PENDING/SUCCESS/FAILED
     */
    private String status;

    /**
     * 支付时间
     */
    private LocalDateTime payTime;

    /**
     * 第三方交易ID
     */
    private String transactionId;

    /**
     * 交易详情，JSON格式
     */
    private String transactionDetails;

    /**
     * 创建时间
     */
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;
}
