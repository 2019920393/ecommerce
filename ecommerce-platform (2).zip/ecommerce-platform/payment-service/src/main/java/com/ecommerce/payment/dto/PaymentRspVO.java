package com.ecommerce.payment.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 支付响应VO
 * 对应文档：6.3.1精化后的CRC卡设计文档.md - PaymentResponse
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "支付响应")
public class PaymentRspVO {

    @Schema(description = "支付流水号")
    private String paymentNumber;

    @Schema(description = "订单号")
    private String orderNumber;

    @Schema(description = "支付金额")
    private BigDecimal amount;

    @Schema(description = "支付方式")
    private String paymentMethod;

    @Schema(description = "支付状态：PENDING/SUCCESS/FAILED")
    private String status;

    @Schema(description = "状态描述")
    private String statusDescription;

    @Schema(description = "创建时间")
    private LocalDateTime createTime;

    @Schema(description = "支付时间")
    private LocalDateTime payTime;

    @Schema(description = "过期时间")
    private LocalDateTime expireTime;

    @Schema(description = "第三方交易ID")
    private String transactionId;
}
