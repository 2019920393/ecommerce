package com.ecommerce.payment.message;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 支付成功消息
 * 对应文档：15.接口设计文档.md - 3.6.1 支付成功消息
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PaymentSuccessMessage implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 支付流水号
     */
    private String paymentNumber;

    /**
     * 订单号
     */
    private String orderNumber;

    /**
     * 用户ID
     */
    private Long userId;

    /**
     * 支付金额
     */
    private BigDecimal amount;

    /**
     * 支付方式：ALIPAY, WECHAT, BANK_CARD, MOCK
     */
    private String paymentMethod;

    /**
     * 支付状态
     */
    private String status;

    /**
     * 第三方交易ID
     */
    private String transactionId;

    /**
     * 支付时间
     */
    private LocalDateTime payTime;

    /**
     * 消息时间戳
     */
    private Long timestamp;
}
