package com.ecommerce.payment.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ecommerce.payment.domain.entity.PaymentRecord;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 支付记录数据访问层
 * 对应文档：6.3.1精化后的CRC卡设计文档.md - PaymentRecordRepository
 */
@Mapper
public interface PaymentRecordMapper extends BaseMapper<PaymentRecord> {

    /**
     * 根据支付流水号查询
     */
    @Select("SELECT * FROM payment_record WHERE payment_number = #{paymentNumber} ORDER BY create_time DESC")
    List<PaymentRecord> findByPaymentNumber(@Param("paymentNumber") String paymentNumber);

    /**
     * 根据订单号查询
     */
    @Select("SELECT * FROM payment_record WHERE order_number = #{orderNumber} ORDER BY create_time DESC")
    List<PaymentRecord> findByOrderNumber(@Param("orderNumber") String orderNumber);

    /**
     * 根据用户ID查询
     */
    @Select("SELECT * FROM payment_record WHERE user_id = #{userId} ORDER BY create_time DESC")
    List<PaymentRecord> findByUserId(@Param("userId") Long userId);

    /**
     * 根据用户ID和时间范围查询
     */
    @Select("SELECT * FROM payment_record WHERE user_id = #{userId} AND create_time BETWEEN #{startTime} AND #{endTime} ORDER BY create_time DESC")
    List<PaymentRecord> findByUserIdAndTimeRange(@Param("userId") Long userId, 
                                                  @Param("startTime") LocalDateTime startTime,
                                                  @Param("endTime") LocalDateTime endTime);
}
