package com.ecommerce.payment.feign;

import com.ecommerce.common.result.Result;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * 订单服务Feign客户端
 * 
 * <p>用于支付服务调用订单服务（支付成功后更新订单状态）</p>
 * 
 * @author ecommerce-team
 * @since 1.0.0
 */
@FeignClient(name = "order-service", fallbackFactory = OrderFeignClientFallback.class)
public interface OrderFeignClient {

    /**
     * 更新订单状态
     */
    @PutMapping("/api/v1/orders/{orderNumber}/status")
    Result<Void> updateOrderStatus(@PathVariable("orderNumber") String orderNumber,
                                   @RequestParam("status") String status);

    /**
     * 获取订单详情
     */
    @GetMapping("/api/v1/orders/{orderNumber}")
    Result<Map<String, Object>> getOrder(@PathVariable("orderNumber") String orderNumber);
}
