package com.ecommerce.payment.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 支付记录响应VO
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "支付记录响应")
public class PaymentRecordRspVO {

    @Schema(description = "记录ID")
    private Long recordId;

    @Schema(description = "支付流水号")
    private String paymentNumber;

    @Schema(description = "订单号")
    private String orderNumber;

    @Schema(description = "支付金额")
    private BigDecimal amount;

    @Schema(description = "支付方式")
    private String paymentMethod;

    @Schema(description = "支付状态")
    private String status;

    @Schema(description = "支付时间")
    private LocalDateTime payTime;

    @Schema(description = "第三方交易ID")
    private String transactionId;

    @Schema(description = "创建时间")
    private LocalDateTime createTime;
}
