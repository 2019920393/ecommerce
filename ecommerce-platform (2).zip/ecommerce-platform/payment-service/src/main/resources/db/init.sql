-- 支付服务数据库初始化脚本
-- 数据库：payment_db

-- 创建数据库（如果不存在）
CREATE DATABASE IF NOT EXISTS payment_db DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE payment_db;

-- 支付订单表
DROP TABLE IF EXISTS payment_order;
CREATE TABLE payment_order (
    payment_id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '支付ID',
    payment_number VARCHAR(30) NOT NULL UNIQUE COMMENT '支付流水号',
    order_id BIGINT COMMENT '订单ID',
    order_number VARCHAR(30) NOT NULL COMMENT '订单号',
    user_id BIGINT NOT NULL COMMENT '用户ID',
    amount DECIMAL(10, 2) NOT NULL COMMENT '支付金额',
    payment_method VARCHAR(20) NOT NULL COMMENT '支付方式：ALIPAY/WECHAT/BANK_CARD/MOCK',
    status VARCHAR(20) NOT NULL DEFAULT 'PENDING' COMMENT '支付状态：PENDING/SUCCESS/FAILED',
    transaction_id VARCHAR(64) COMMENT '第三方交易ID',
    transaction_details TEXT COMMENT '交易详情JSON',
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    pay_time DATETIME COMMENT '支付完成时间',
    expire_time DATETIME COMMENT '过期时间',
    update_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    INDEX idx_order_number (order_number),
    INDEX idx_user_id (user_id),
    INDEX idx_status (status),
    INDEX idx_create_time (create_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='支付订单表';

-- 支付记录表（用于对账和审计）
DROP TABLE IF EXISTS payment_record;
CREATE TABLE payment_record (
    record_id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '记录ID',
    payment_number VARCHAR(30) NOT NULL COMMENT '支付流水号',
    user_id BIGINT NOT NULL COMMENT '用户ID',
    order_id BIGINT COMMENT '订单ID',
    order_number VARCHAR(30) NOT NULL COMMENT '订单号',
    amount DECIMAL(10, 2) NOT NULL COMMENT '支付金额',
    payment_method VARCHAR(20) NOT NULL COMMENT '支付方式',
    status VARCHAR(20) NOT NULL COMMENT '支付状态',
    pay_time DATETIME COMMENT '支付时间',
    transaction_id VARCHAR(64) COMMENT '第三方交易ID',
    transaction_details TEXT COMMENT '交易详情JSON',
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    INDEX idx_payment_number (payment_number),
    INDEX idx_order_number (order_number),
    INDEX idx_user_id (user_id),
    INDEX idx_create_time (create_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='支付记录表';

-- 插入测试数据
INSERT INTO payment_order (payment_number, order_number, user_id, amount, payment_method, status, expire_time) VALUES
('PAY20251205100001', 'ORD20251205001', 1, 299.00, 'MOCK', 'PENDING', DATE_ADD(NOW(), INTERVAL 15 MINUTE)),
('PAY20251205100002', 'ORD20251205002', 1, 599.00, 'MOCK', 'SUCCESS', DATE_ADD(NOW(), INTERVAL 15 MINUTE)),
('PAY20251205100003', 'ORD20251205003', 2, 199.00, 'ALIPAY', 'FAILED', DATE_ADD(NOW(), INTERVAL 15 MINUTE));

-- 更新成功订单的支付时间和交易ID
UPDATE payment_order SET pay_time = NOW(), transaction_id = 'TXN1234567890' WHERE payment_number = 'PAY20251205100002';

-- 插入支付记录
INSERT INTO payment_record (payment_number, user_id, order_number, amount, payment_method, status, pay_time, transaction_id) VALUES
('PAY20251205100002', 1, 'ORD20251205002', 599.00, 'MOCK', 'SUCCESS', NOW(), 'TXN1234567890'),
('PAY20251205100003', 2, 'ORD20251205003', 199.00, 'ALIPAY', 'FAILED', NULL, NULL);
