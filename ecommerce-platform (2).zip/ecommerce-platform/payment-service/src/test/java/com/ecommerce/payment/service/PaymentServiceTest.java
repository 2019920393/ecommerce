package com.ecommerce.payment.service;

import com.ecommerce.common.exception.BusinessException;
import com.ecommerce.payment.domain.entity.PaymentOrder;
import com.ecommerce.payment.domain.entity.PaymentRecord;
import com.ecommerce.payment.dto.*;
import com.ecommerce.payment.mapper.PaymentOrderMapper;
import com.ecommerce.payment.mapper.PaymentRecordMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * PaymentService 单元测试
 * 测试支付服务的核心业务逻辑（UC10 订单支付）
 * 
 * @author Test Team
 * @since 2025-12-27
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("PaymentService 单元测试")
class PaymentServiceTest {

    @Mock
    private PaymentOrderMapper paymentOrderMapper;

    @Mock
    private PaymentRecordMapper paymentRecordMapper;

    @InjectMocks
    private PaymentService paymentService;

    private PaymentOrder mockPaymentOrder;
    private CreatePaymentRequest createPaymentRequest;

    @BeforeEach
    void setUp() {
        // 构建Mock支付订单
        mockPaymentOrder = new PaymentOrder();
        mockPaymentOrder.setPaymentId(1L);
        mockPaymentOrder.setPaymentNumber("PAY20251227001");
        mockPaymentOrder.setOrderNumber("ORD20251227001");
        mockPaymentOrder.setUserId(1L);
        mockPaymentOrder.setAmount(new BigDecimal("15998.00"));
        mockPaymentOrder.setPaymentMethod("ALIPAY");
        mockPaymentOrder.setStatus("PENDING");
        mockPaymentOrder.setCreateTime(LocalDateTime.now());
        mockPaymentOrder.setExpireTime(LocalDateTime.now().plusMinutes(15));

        // 构建创建支付请求
        createPaymentRequest = new CreatePaymentRequest();
        createPaymentRequest.setOrderNumber("ORD20251227001");
        createPaymentRequest.setUserId(1L);
        createPaymentRequest.setPaymentMethod("ALIPAY");
    }

    @Nested
    @DisplayName("创建支付订单测试")
    class CreatePaymentTests {

        @Test
        @DisplayName("TC-UC10-001: 正常创建支付订单")
        void testCreatePaymentOrder_Success() {
            // Given: 订单未支付
            when(paymentOrderMapper.findByOrderNumber("ORD20251227001")).thenReturn(null);
            when(paymentOrderMapper.insert(any(PaymentOrder.class))).thenReturn(1);

            // When: 创建支付订单
            PaymentRspVO result = paymentService.createPaymentOrder(
                    createPaymentRequest, new BigDecimal("15998.00"));

            // Then: 验证创建成功
            assertNotNull(result, "支付订单不应为空");
            assertNotNull(result.getPaymentNumber(), "支付流水号不应为空");
            assertTrue(result.getPaymentNumber().startsWith("PAY"), "支付流水号应以PAY开头");
            assertEquals("PENDING", result.getStatus(), "支付状态应为待支付");
        }

        @Test
        @DisplayName("TC-UC10-002: 重复创建支付订单")
        void testCreatePaymentOrder_AlreadyExists() {
            // Given: 已存在支付订单
            when(paymentOrderMapper.findByOrderNumber("ORD20251227001")).thenReturn(mockPaymentOrder);

            // When & Then: 应抛出异常或返回已存在的支付订单
            // 根据业务逻辑，可能返回已存在的订单或抛出异常
            PaymentRspVO result = paymentService.createPaymentOrder(
                    createPaymentRequest, new BigDecimal("15998.00"));

            assertNotNull(result);
        }
    }

    @Nested
    @DisplayName("执行支付测试")
    class ProcessPaymentTests {

        @Test
        @DisplayName("TC-UC10-003: 支付成功")
        void testProcessPayment_Success() {
            // Given: 支付订单存在且未过期
            when(paymentOrderMapper.findByPaymentNumber("PAY20251227001")).thenReturn(mockPaymentOrder);
            when(paymentOrderMapper.updateById(any(PaymentOrder.class))).thenReturn(1);
            when(paymentRecordMapper.insert(any(PaymentRecord.class))).thenReturn(1);

            // When: 执行支付（强制成功）
            PaymentRspVO result = paymentService.processPayment("PAY20251227001", true);

            // Then: 验证支付成功
            assertNotNull(result, "支付结果不应为空");
            assertEquals("SUCCESS", result.getStatus(), "支付状态应为成功");
            assertNotNull(result.getPayTime(), "支付时间不应为空");
            assertNotNull(result.getTransactionId(), "交易流水号不应为空");
        }

        @Test
        @DisplayName("TC-UC10-004: 支付失败")
        void testProcessPayment_Failure() {
            // Given: 支付订单存在
            when(paymentOrderMapper.findByPaymentNumber("PAY20251227001")).thenReturn(mockPaymentOrder);
            when(paymentOrderMapper.updateById(any(PaymentOrder.class))).thenReturn(1);

            // When: 模拟支付失败（设置forceSuccess为false，模拟随机失败）
            // 注意：实际测试中需要控制随机性
            PaymentRspVO result = paymentService.processPayment("PAY20251227001", false);

            // Then: 验证返回结果（可能成功或失败）
            assertNotNull(result, "支付结果不应为空");
            assertTrue(Arrays.asList("SUCCESS", "FAILED").contains(result.getStatus()), 
                    "支付状态应为成功或失败");
        }

        @Test
        @DisplayName("TC-UC10-005: 支付订单不存在")
        void testProcessPayment_OrderNotFound() {
            // Given: 支付订单不存在
            when(paymentOrderMapper.findByPaymentNumber("INVALID")).thenReturn(null);

            // When & Then: 应抛出异常
            assertThrows(BusinessException.class, () -> {
                paymentService.processPayment("INVALID", true);
            }, "支付订单不存在时应抛出异常");
        }

        @Test
        @DisplayName("TC-UC10-006: 支付订单已过期")
        void testProcessPayment_Expired() {
            // Given: 支付订单已过期
            mockPaymentOrder.setExpireTime(LocalDateTime.now().minusMinutes(1));
            when(paymentOrderMapper.findByPaymentNumber("PAY20251227001")).thenReturn(mockPaymentOrder);

            // When & Then: 应抛出异常
            assertThrows(BusinessException.class, () -> {
                paymentService.processPayment("PAY20251227001", true);
            }, "支付订单已过期时应抛出异常");
        }

        @Test
        @DisplayName("TC-UC10-007: 重复支付")
        void testProcessPayment_AlreadyPaid() {
            // Given: 支付订单已支付
            mockPaymentOrder.setStatus("SUCCESS");
            when(paymentOrderMapper.findByPaymentNumber("PAY20251227001")).thenReturn(mockPaymentOrder);

            // When & Then: 应抛出异常
            assertThrows(BusinessException.class, () -> {
                paymentService.processPayment("PAY20251227001", true);
            }, "已支付的订单不能重复支付");
        }
    }

    @Nested
    @DisplayName("查询支付状态测试")
    class GetPaymentStatusTests {

        @Test
        @DisplayName("查询支付状态成功")
        void testGetPaymentStatus_Success() {
            // Given: 支付订单存在
            when(paymentOrderMapper.findByPaymentNumber("PAY20251227001")).thenReturn(mockPaymentOrder);

            // When: 查询支付状态
            PaymentRspVO result = paymentService.getPaymentStatus("PAY20251227001");

            // Then: 验证结果
            assertNotNull(result, "支付状态不应为空");
            assertEquals("PAY20251227001", result.getPaymentNumber(), "支付流水号应匹配");
            assertEquals("PENDING", result.getStatus(), "支付状态应匹配");
        }

        @Test
        @DisplayName("查询不存在的支付订单")
        void testGetPaymentStatus_NotFound() {
            // Given: 支付订单不存在
            when(paymentOrderMapper.findByPaymentNumber("INVALID")).thenReturn(null);

            // When & Then: 应抛出异常
            assertThrows(BusinessException.class, () -> {
                paymentService.getPaymentStatus("INVALID");
            }, "支付订单不存在时应抛出异常");
        }
    }

    @Nested
    @DisplayName("根据订单号查询支付测试")
    class GetPaymentByOrderNumberTests {

        @Test
        @DisplayName("根据订单号查询支付记录")
        void testGetPaymentByOrderNumber_Success() {
            // Given: 支付记录存在
            when(paymentOrderMapper.findByOrderNumber("ORD20251227001")).thenReturn(mockPaymentOrder);

            // When: 查询支付
            PaymentRspVO result = paymentService.getPaymentByOrderNumber("ORD20251227001");

            // Then: 验证结果
            assertNotNull(result, "支付记录不应为空");
            assertEquals("ORD20251227001", result.getOrderNumber(), "订单号应匹配");
        }
    }

    @Nested
    @DisplayName("用户支付记录查询测试")
    class GetUserPaymentRecordsTests {

        @Test
        @DisplayName("查询用户支付记录")
        void testGetUserPaymentRecords_Success() {
            // Given: 有支付记录
            PaymentRecord record = new PaymentRecord();
            record.setRecordId(1L);
            record.setPaymentNumber("PAY20251227001");
            record.setAmount(new BigDecimal("15998.00"));
            record.setStatus("SUCCESS");

            when(paymentRecordMapper.findByUserId(1L)).thenReturn(Arrays.asList(record));

            // When: 查询用户支付记录
            List<PaymentRecordRspVO> result = paymentService.getUserPaymentRecords(1L);

            // Then: 验证结果
            assertNotNull(result, "支付记录列表不应为空");
            assertEquals(1, result.size(), "应有1条支付记录");
        }

        @Test
        @DisplayName("用户无支付记录")
        void testGetUserPaymentRecords_Empty() {
            // Given: 无支付记录
            when(paymentRecordMapper.findByUserId(999L)).thenReturn(Arrays.asList());

            // When: 查询用户支付记录
            List<PaymentRecordRspVO> result = paymentService.getUserPaymentRecords(999L);

            // Then: 验证结果
            assertNotNull(result, "结果不应为null");
            assertTrue(result.isEmpty(), "支付记录列表应为空");
        }
    }

    @Nested
    @DisplayName("支付超时处理测试")
    class PaymentTimeoutTests {

        @Test
        @DisplayName("处理过期支付订单")
        void testProcessExpiredPayments() {
            // Given: 有过期支付订单
            List<PaymentOrder> expiredOrders = Arrays.asList(mockPaymentOrder);
            when(paymentOrderMapper.findExpiredPayments()).thenReturn(expiredOrders);
            when(paymentOrderMapper.updateById(any(PaymentOrder.class))).thenReturn(1);

            // When: 处理过期支付订单
            paymentService.handleExpiredPayments();

            // Then: 验证订单状态被更新
            verify(paymentOrderMapper, times(1)).updateById(any(PaymentOrder.class));
        }
    }
}
