-- ============================================================
-- 云原生微服务电商平台 - 测试数据初始化脚本
-- ============================================================

-- ============================================================
-- 1. 用户服务测试数据
-- ============================================================
USE user_db;

-- 测试用户（密码：123456，BCrypt加密）
-- 注意：这是123456的正确BCrypt hash
INSERT INTO user (username, password, phone, email, nickname, role, status) VALUES
('admin', '$2a$10$FYHFf9Oci79OsKIFeiE1a.011Q8C0JUY22H/naZj99FvI55UzPt2e', '13800000000', 'admin@example.com', '管理员', 'ADMIN', 'NORMAL'),
('zhangsan', '$2a$10$FYHFf9Oci79OsKIFeiE1a.011Q8C0JUY22H/naZj99FvI55UzPt2e', '13800138001', 'zhangsan@example.com', '张三', 'USER', 'NORMAL'),
('lisi', '$2a$10$FYHFf9Oci79OsKIFeiE1a.011Q8C0JUY22H/naZj99FvI55UzPt2e', '13800138002', 'lisi@example.com', '李四', 'USER', 'NORMAL');

-- 测试收货地址
INSERT INTO shipping_address (user_id, recipient_name, phone, province, city, district, detail_address, is_default) VALUES
(2, '张三', '13800138001', '广东省', '深圳市', '南山区', '科技园南路88号', 1),
(2, '张三', '13800138001', '广东省', '广州市', '天河区', '天河路100号', 0),
(3, '李四', '13800138002', '北京市', '北京市', '朝阳区', '建国路99号', 1);

-- ============================================================
-- 2. 商品服务测试数据
-- ============================================================
USE product_db;

-- 商品分类（一级分类）
INSERT INTO categories (category_name, parent_id, level, sort_order) VALUES
('手机数码', 0, 1, 1),
('电脑办公', 0, 1, 2),
('家用电器', 0, 1, 3),
('服装鞋包', 0, 1, 4);

-- 商品分类（二级分类）
INSERT INTO categories (category_name, parent_id, level, sort_order) VALUES
('手机', 1, 2, 1),
('平板电脑', 1, 2, 2),
('笔记本电脑', 2, 2, 1),
('台式机', 2, 2, 2),
('冰箱', 3, 2, 1),
('洗衣机', 3, 2, 2),
('男装', 4, 2, 1),
('女装', 4, 2, 2);

-- 商品数据
INSERT INTO products (product_name, category_id, price, original_price, description, main_image, stock, sales, status) VALUES
('iPhone 15 Pro 256GB', 5, 7999.00, 8999.00, 'Apple iPhone 15 Pro 256GB 黑色钛金属', 'https://example.com/iphone15.jpg', 100, 50, 'ON_SALE'),
('华为 Mate 60 Pro', 5, 6999.00, 7499.00, '华为 Mate 60 Pro 12GB+512GB 雅丹黑', 'https://example.com/mate60.jpg', 80, 30, 'ON_SALE'),
('小米14 Ultra', 5, 5999.00, 6299.00, '小米14 Ultra 16GB+512GB 黑色', 'https://example.com/mi14.jpg', 120, 45, 'ON_SALE'),
('iPad Pro 12.9英寸', 6, 8999.00, 9499.00, 'Apple iPad Pro 12.9英寸 M2芯片 256GB', 'https://example.com/ipadpro.jpg', 50, 20, 'ON_SALE'),
('MacBook Pro 14英寸', 7, 14999.00, 15999.00, 'Apple MacBook Pro 14英寸 M3 Pro芯片', 'https://example.com/macbook.jpg', 30, 15, 'ON_SALE'),
('联想小新Pro 16', 7, 5999.00, 6499.00, '联想小新Pro 16 2024 酷睿Ultra 7', 'https://example.com/xiaoxin.jpg', 60, 25, 'ON_SALE'),
('海尔冰箱 BCD-470', 9, 3999.00, 4299.00, '海尔冰箱 470升 对开门 变频风冷无霜', 'https://example.com/haier.jpg', 40, 18, 'ON_SALE'),
('西门子洗衣机', 10, 2999.00, 3299.00, '西门子 10公斤 滚筒洗衣机 变频', 'https://example.com/siemens.jpg', 35, 12, 'ON_SALE');

-- ============================================================
-- 3. 订单服务测试数据
-- ============================================================
USE order_db;

-- 库存数据（与商品对应）
INSERT INTO inventory (product_id, total_stock, available_stock, locked_stock, version) VALUES
(1, 100, 100, 0, 0),
(2, 80, 80, 0, 0),
(3, 120, 120, 0, 0),
(4, 50, 50, 0, 0),
(5, 30, 30, 0, 0),
(6, 60, 60, 0, 0),
(7, 40, 40, 0, 0),
(8, 35, 35, 0, 0);

-- 测试订单
INSERT INTO orders (order_number, user_id, recipient_name, recipient_phone, shipping_address, province, city, district, detail_address, total_amount, product_amount, shipping_fee, discount, status, expire_time) VALUES
('ORD20251205000001', 2, '张三', '13800138001', '广东省深圳市南山区科技园南路88号', '广东省', '深圳市', '南山区', '科技园南路88号', 7999.00, 7999.00, 0.00, 0.00, 'PENDING_PAYMENT', DATE_ADD(NOW(), INTERVAL 30 MINUTE)),
('ORD20251205000002', 2, '张三', '13800138001', '广东省深圳市南山区科技园南路88号', '广东省', '深圳市', '南山区', '科技园南路88号', 6999.00, 6999.00, 0.00, 0.00, 'PENDING_SHIPMENT', NULL),
('ORD20251205000003', 3, '李四', '13800138002', '北京市北京市朝阳区建国路99号', '北京市', '北京市', '朝阳区', '建国路99号', 5999.00, 5999.00, 0.00, 0.00, 'COMPLETED', NULL);

-- 订单明细
INSERT INTO order_items (order_id, order_number, product_id, product_name, product_image, unit_price, quantity, subtotal) VALUES
(1, 'ORD20251205000001', 1, 'iPhone 15 Pro 256GB', 'https://example.com/iphone15.jpg', 7999.00, 1, 7999.00),
(2, 'ORD20251205000002', 2, '华为 Mate 60 Pro', 'https://example.com/mate60.jpg', 6999.00, 1, 6999.00),
(3, 'ORD20251205000003', 3, '小米14 Ultra', 'https://example.com/mi14.jpg', 5999.00, 1, 5999.00);

-- ============================================================
-- 4. 支付服务测试数据
-- ============================================================
USE payment_db;

-- 测试支付订单
INSERT INTO payment_order (payment_number, order_number, user_id, amount, payment_method, status, expire_time) VALUES
('PAY20251205100001', 'ORD20251205000001', 2, 7999.00, 'MOCK', 'PENDING', DATE_ADD(NOW(), INTERVAL 15 MINUTE)),
('PAY20251205100002', 'ORD20251205000002', 2, 6999.00, 'MOCK', 'SUCCESS', DATE_ADD(NOW(), INTERVAL 15 MINUTE)),
('PAY20251205100003', 'ORD20251205000003', 3, 5999.00, 'ALIPAY', 'SUCCESS', DATE_ADD(NOW(), INTERVAL 15 MINUTE));

-- 更新成功订单的支付时间
UPDATE payment_order SET pay_time = NOW(), transaction_id = 'TXN1234567890' WHERE payment_number = 'PAY20251205100002';
UPDATE payment_order SET pay_time = NOW(), transaction_id = 'TXN1234567891' WHERE payment_number = 'PAY20251205100003';

-- 支付记录
INSERT INTO payment_record (payment_number, user_id, order_number, amount, payment_method, status, pay_time, transaction_id) VALUES
('PAY20251205100002', 2, 'ORD20251205000002', 6999.00, 'MOCK', 'SUCCESS', NOW(), 'TXN1234567890'),
('PAY20251205100003', 3, 'ORD20251205000003', 5999.00, 'ALIPAY', 'SUCCESS', NOW(), 'TXN1234567891');
