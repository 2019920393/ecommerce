#!/bin/bash
# Nacos配置初始化脚本
# 等待Nacos启动完成后，通过API创建配置

NACOS_ADDR=${NACOS_ADDR:-"localhost:8848"}

echo "等待Nacos启动..."
sleep 30

echo "开始初始化Nacos配置..."

# 创建公共配置
curl -X POST "http://${NACOS_ADDR}/nacos/v1/cs/configs" \
  -d "dataId=application-common.yaml" \
  -d "group=DEFAULT_GROUP" \
  -d "type=yaml" \
  -d "content=# 公共配置
logging:
  level:
    root: INFO
    com.ecommerce: DEBUG
  pattern:
    level: '%5p [%X{traceId:-},%X{spanId:-}]'

management:
  endpoints:
    web:
      exposure:
        include: health,info,prometheus,metrics
  tracing:
    sampling:
      probability: 1.0"

echo ""
echo "公共配置创建完成"

# 创建product-service配置
curl -X POST "http://${NACOS_ADDR}/nacos/v1/cs/configs" \
  -d "dataId=product-service.yaml" \
  -d "group=DEFAULT_GROUP" \
  -d "type=yaml" \
  -d "content=# 商品服务动态配置
product:
  page:
    default-size: 10
    max-size: 100"

echo ""
echo "product-service配置创建完成"

# 创建order-service配置
curl -X POST "http://${NACOS_ADDR}/nacos/v1/cs/configs" \
  -d "dataId=order-service.yaml" \
  -d "group=DEFAULT_GROUP" \
  -d "type=yaml" \
  -d "content=# 订单服务动态配置
order:
  timeout:
    minutes: 30
  page:
    default-size: 10"

echo ""
echo "order-service配置创建完成"

# 创建payment-service配置
curl -X POST "http://${NACOS_ADDR}/nacos/v1/cs/configs" \
  -d "dataId=payment-service.yaml" \
  -d "group=DEFAULT_GROUP" \
  -d "type=yaml" \
  -d "content=# 支付服务动态配置
payment:
  mock:
    success-rate: 0.9
  expire-minutes: 15"

echo ""
echo "payment-service配置创建完成"

# 创建user-service配置
curl -X POST "http://${NACOS_ADDR}/nacos/v1/cs/configs" \
  -d "dataId=user-service.yaml" \
  -d "group=DEFAULT_GROUP" \
  -d "type=yaml" \
  -d "content=# 用户服务动态配置
user:
  password:
    min-length: 6
    max-length: 20"

echo ""
echo "user-service配置创建完成"

# 创建gateway-service配置
curl -X POST "http://${NACOS_ADDR}/nacos/v1/cs/configs" \
  -d "dataId=gateway-service.yaml" \
  -d "group=DEFAULT_GROUP" \
  -d "type=yaml" \
  -d "content=# 网关服务动态配置
gateway:
  rate-limit:
    enabled: false
    default-limit: 100"

echo ""
echo "gateway-service配置创建完成"

echo ""
echo "=========================================="
echo "Nacos配置初始化完成！"
echo "访问 http://${NACOS_ADDR}/nacos 查看配置"
echo "默认账号: nacos / nacos"
echo "=========================================="
