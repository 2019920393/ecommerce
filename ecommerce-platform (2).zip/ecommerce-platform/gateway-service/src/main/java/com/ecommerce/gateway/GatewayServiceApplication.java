package com.ecommerce.gateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

/**
 * API网关服务启动类
 * 
 * <p>功能：</p>
 * <ul>
 *   <li>统一路由：将请求转发到对应的微服务</li>
 *   <li>JWT鉴权：验证用户Token</li>
 *   <li>限流：防止服务过载</li>
 *   <li>跨域处理：统一处理CORS</li>
 * </ul>
 * 
 * @author ecommerce-team
 * @since 1.0.0
 */
@SpringBootApplication
@EnableDiscoveryClient
public class GatewayServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(GatewayServiceApplication.class, args);
    }
}
