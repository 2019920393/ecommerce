#!/bin/bash
# 云原生微服务电商平台 - 构建脚本
# 使用方法: ./build.sh

echo "=========================================="
echo "云原生微服务电商平台 - 开始构建"
echo "=========================================="

# 构建父项目和common模块
echo "[1/5] 构建父项目和common模块..."
mvn clean install -DskipTests -pl common -am

# 构建各微服务
echo "[2/5] 构建 product-service..."
mvn clean package -DskipTests -pl product-service

echo "[3/5] 构建 payment-service..."
mvn clean package -DskipTests -pl payment-service

echo "[4/5] 构建 order-service..."
mvn clean package -DskipTests -pl order-service

echo "[5/6] 构建 user-service..."
mvn clean package -DskipTests -pl user-service

echo "[6/6] 构建 gateway-service..."
mvn clean package -DskipTests -pl gateway-service

echo "=========================================="
echo "构建完成！"
echo "=========================================="
echo ""
echo "下一步: 运行 docker-compose up -d 启动所有服务"
