# 订单支付集成文档

## 完整支付流程

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                          用户下单支付完整流程                                 │
└─────────────────────────────────────────────────────────────────────────────┘

1️⃣ 创建订单
   POST /api/v1/orders
   ├─ 请求体: CreateOrderRequest (userId, items, addressId, remark)
   ├─ 业务流程:
   │  ├─ 校验库存是否充足
   │  ├─ 生成订单号
   │  ├─ 创建订单和订单明细
   │  ├─ 预扣库存（乐观锁）
   │  └─ 设置订单状态为 PENDING_PAYMENT（待支付）
   └─ 响应: CreateOrderRspVO (orderNumber, totalAmount, expireTime)

2️⃣ 创建支付订单
   POST /api/v1/payments?amount=7999.00
   ├─ 请求体: CreatePaymentRequest (orderNumber, paymentMethod)
   ├─ 业务流程:
   │  ├─ 检查是否已有待支付的支付订单
   │  ├─ 生成支付流水号
   │  ├─ 创建支付订单
   │  └─ 设置支付状态为 PENDING（待支付）
   └─ 响应: PaymentRspVO (paymentNumber, amount, status, expireTime)

3️⃣ 执行支付（模拟支付）
   POST /api/v1/payments/{paymentNumber}/pay
   ├─ 请求参数: forceSuccess (可选，用于测试)
   ├─ 业务流程:
   │  ├─ 校验支付订单是否可支付
   │  ├─ 模拟支付（90%成功率）
   │  ├─ 更新支付订单状态为 SUCCESS/FAILED
   │  ├─ 创建支付记录
   │  └─ 【支付成功时】调用order-service更新订单状态
   └─ 响应: PaymentRspVO (paymentNumber, status, payTime, transactionId)

4️⃣ 支付成功回调（自动触发）
   ├─ 调用 order-service 更新订单状态
   │  PUT /api/v1/orders/{orderNumber}/status?status=PENDING_SHIPMENT
   │  └─ 订单状态: PENDING_PAYMENT → PENDING_SHIPMENT（待发货）
   │
   └─ 【可选】调用 product-service 清空购物车
      DELETE /api/v1/cart/{userId}/items?itemIds=...
      └─ 清空已下单的商品

5️⃣ 查询支付状态
   GET /api/v1/payments/{paymentNumber}
   └─ 响应: PaymentRspVO (status, payTime, transactionId)

6️⃣ 查询订单详情
   GET /api/v1/orders/{orderNumber}
   └─ 响应: OrderDetailRspVO (status=PENDING_SHIPMENT, payTime, items)
```

---

## API接口清单

### 订单服务 (order-service)

| 接口 | 方法 | 路径 | 说明 |
|------|------|------|------|
| 创建订单 | POST | `/api/v1/orders` | 创建新订单 |
| 查询订单详情 | GET | `/api/v1/orders/{orderNumber}` | 查询订单完整信息 |
| 查询订单列表 | GET | `/api/v1/orders/user/{userId}` | 分页查询用户订单 |
| 取消订单 | PUT | `/api/v1/orders/{orderNumber}/cancel` | 取消待支付订单 |
| **更新订单状态** | **PUT** | **`/api/v1/orders/{orderNumber}/status`** | **支付成功后调用** |

### 支付服务 (payment-service)

| 接口 | 方法 | 路径 | 说明 |
|------|------|------|------|
| 创建支付订单 | POST | `/api/v1/payments` | 创建支付订单 |
| 执行支付 | POST | `/api/v1/payments/{paymentNumber}/pay` | 模拟支付 |
| 查询支付状态 | GET | `/api/v1/payments/{paymentNumber}` | 查询支付状态 |
| 根据订单号查询支付 | GET | `/api/v1/payments/order/{orderNumber}` | 查询订单的支付信息 |
| 查询支付记录 | GET | `/api/v1/payments/user/{userId}` | 查询用户支付历史 |

### 商品服务 (product-service)

| 接口 | 方法 | 路径 | 说明 |
|------|------|------|------|
| 查询商品详情 | GET | `/api/v1/products/{productId}` | 获取商品信息 |
| 批量查询商品 | POST | `/api/v1/products/batch` | 批量获取商品 |
| 检查库存 | GET | `/api/v1/products/{productId}/stock/check` | 检查库存是否充足 |
| 查询购物车 | GET | `/api/v1/cart/{userId}/items` | 查询购物车项 |
| 清空购物车 | DELETE | `/api/v1/cart/{userId}/items` | 清空已下单商品 |

---

## 数据流转

### 订单状态流转

```
创建订单
   ↓
PENDING_PAYMENT (待支付)
   ├─ 支付成功 → PENDING_SHIPMENT (待发货)
   │              ├─ 发货 → SHIPPED (已发货)
   │              │         └─ 收货 → COMPLETED (已完成)
   │              └─ 取消 → CANCELLED (已取消)
   │
   └─ 支付失败/超时 → CANCELLED (已取消)
```

### 支付状态流转

```
创建支付订单
   ↓
PENDING (待支付)
   ├─ 支付成功 → SUCCESS (支付成功)
   │              └─ 触发订单状态更新
   │
   └─ 支付失败/超时 → FAILED (支付失败)
```

---

## 服务间调用关系

```
┌──────────────────────────────────────────────────────────────┐
│                    Gateway (API网关)                         │
│                      :8080                                   │
└──────────────────────────────────────────────────────────────┘
                            │
        ┌───────────────────┼───────────────────┐
        ▼                   ▼                   ▼
┌──────────────────┐ ┌──────────────────┐ ┌──────────────────┐
│ order-service    │ │payment-service   │ │product-service   │
│    :8083         │ │    :8082         │ │    :8081         │
│                  │ │                  │ │                  │
│ ┌──────────────┐ │ │ ┌──────────────┐ │ │ ┌──────────────┐ │
│ │OrderService  │ │ │ │PaymentService│ │ │ │ProductService│ │
│ │              │ │ │ │              │ │ │ │              │ │
│ │ 创建订单      │ │ │ │ 创建支付     │ │ │ │ 查询商品     │ │
│ │ 查询订单      │◄─┼─┤ 执行支付     │ │ │ │ 检查库存     │ │
│ │ 更新订单状态  │ │ │ 支付成功回调 ├─┼─┤ │ 清空购物车   │ │
│ │ 取消订单      │ │ │              │ │ │ │              │ │
│ └──────────────┘ │ │ └──────────────┘ │ │ └──────────────┘ │
└──────────────────┘ └──────────────────┘ └──────────────────┘
```

---

## 测试场景

### 场景1：完整支付流程（成功）

```bash
# 1. 创建订单
curl -X POST http://localhost:8080/api/v1/orders \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer {token}" \
  -d '{
    "userId": 2,
    "items": [
      {
        "productId": 1,
        "productName": "iPhone 15 Pro",
        "productImage": "...",
        "unitPrice": 7999.00,
        "quantity": 1
      }
    ],
    "recipientName": "张三",
    "recipientPhone": "13800138001",
    "province": "广东省",
    "city": "深圳市",
    "district": "南山区",
    "detailAddress": "科技园南路88号"
  }'

# 响应: orderNumber=ORD20251205000001, totalAmount=7999.00

# 2. 创建支付订单
curl -X POST "http://localhost:8080/api/v1/payments?amount=7999.00" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer {token}" \
  -d '{
    "orderNumber": "ORD20251205000001",
    "paymentMethod": "MOCK"
  }'

# 响应: paymentNumber=PAY20251205100001, status=PENDING

# 3. 执行支付（强制成功）
curl -X POST "http://localhost:8080/api/v1/payments/PAY20251205100001/pay?forceSuccess=true" \
  -H "Authorization: Bearer {token}"

# 响应: status=SUCCESS, payTime=2025-12-05T10:00:00

# 4. 查询订单详情（验证状态已更新）
curl -X GET "http://localhost:8080/api/v1/orders/ORD20251205000001" \
  -H "Authorization: Bearer {token}"

# 响应: status=PENDING_SHIPMENT, payTime=2025-12-05T10:00:00
```

### 场景2：支付失败

```bash
# 执行支付（强制失败）
curl -X POST "http://localhost:8080/api/v1/payments/PAY20251205100001/pay?forceSuccess=false" \
  -H "Authorization: Bearer {token}"

# 响应: status=FAILED

# 查询订单详情（订单状态仍为待支付）
curl -X GET "http://localhost:8080/api/v1/orders/ORD20251205000001" \
  -H "Authorization: Bearer {token}"

# 响应: status=PENDING_PAYMENT
```

---

## 关键实现细节

### 1. 支付成功回调

**位置**：`payment-service/PaymentService.handlePaymentSuccess()`

**流程**：
```java
支付成功 → 调用 orderFeignClient.updateOrderStatus()
        → 订单状态: PENDING_PAYMENT → PENDING_SHIPMENT
        → 异常处理：记录日志，不影响支付结果
```

### 2. OpenFeign服务调用

**定义**：`payment-service/feign/OrderFeignClient.java`

**特性**：
- 自动服务发现（从Nacos获取order-service地址）
- 负载均衡（多实例时自动轮询）
- 降级处理（服务不可用时返回兜底数据）

### 3. 事务管理

**支付处理**：`@Transactional`
- 支付订单更新
- 支付记录创建
- 异常时自动回滚

**订单更新**：由order-service独立处理
- 通过Feign调用，不在同一事务中
- 支付成功后异步更新，提高可用性

---

## 后续扩展

### 1. 清空购物车

```java
// 支付成功后清空购物车
Result<Void> clearResult = productFeignClient.clearCartItems(userId, itemIds);
```

### 2. 消息队列异步处理

```java
// 支付成功后发送消息
rabbitTemplate.convertAndSend("payment.success", paymentOrder);
```

### 3. 真实支付网关集成

```java
// 替换模拟支付为真实支付
PaymentGateway gateway = new AlipayGateway();
boolean success = gateway.pay(paymentOrder);
```

---

## 故障排查

### 问题1：支付成功但订单状态未更新

**原因**：order-service不可用或网络超时

**解决**：
1. 检查order-service是否正常运行
2. 查看payment-service日志中的异常信息
3. 手动调用order-service更新订单状态

### 问题2：支付订单创建失败

**原因**：订单号不存在或已支付

**解决**：
1. 确认订单已创建
2. 检查订单状态是否为PENDING_PAYMENT

### 问题3：Feign调用超时

**原因**：网络延迟或服务响应慢

**解决**：
1. 增加Feign超时时间配置
2. 检查服务性能
3. 查看服务日志

---

## 总结

✅ **已实现**：
- 订单创建和库存预扣
- 支付订单创建和模拟支付
- 支付成功回调更新订单状态
- OpenFeign服务间调用
- 异常处理和降级

⏳ **可选扩展**：
- 清空购物车
- 消息队列异步处理
- 真实支付网关集成
- 分布式事务处理
