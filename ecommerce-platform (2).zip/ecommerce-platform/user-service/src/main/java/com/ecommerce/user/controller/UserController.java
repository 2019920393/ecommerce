package com.ecommerce.user.controller;

import com.ecommerce.common.result.Result;
import com.ecommerce.user.dto.*;
import com.ecommerce.user.service.UserService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

/**
 * 用户控制器
 */
@Slf4j
@RestController
@RequestMapping("/api/v1/users")
@RequiredArgsConstructor
@Tag(name = "用户管理", description = "用户注册、登录、信息管理接口")
public class UserController {

    private final UserService userService;

    @PostMapping("/register")
    @Operation(summary = "用户注册", description = "新用户注册")
    public Result<UserRspVO> register(@Valid @RequestBody RegisterRequest request) {
        log.info("用户注册请求: username={}", request.getUsername());
        UserRspVO user = userService.register(request);
        return Result.success(user);
    }

    @PostMapping("/login")
    @Operation(summary = "用户登录", description = "用户名/手机号登录，返回JWT Token")
    public Result<LoginRspVO> login(@Valid @RequestBody LoginRequest request) {
        log.info("用户登录请求: username={}", request.getUsername());
        LoginRspVO loginRsp = userService.login(request);
        return Result.success(loginRsp);
    }

    @GetMapping("/list")
    @Operation(summary = "获取用户列表", description = "分页获取用户列表（管理员接口）")
    public Result<com.baomidou.mybatisplus.extension.plugins.pagination.Page<UserRspVO>> listUsers(
            @Parameter(name = "page", description = "页码") @RequestParam(name = "page", defaultValue = "1") Integer page,
            @Parameter(name = "size", description = "每页数量") @RequestParam(name = "size", defaultValue = "10") Integer size) {
        return Result.success(userService.listUsers(page, size));
    }

    @GetMapping("/{userId}")
    @Operation(summary = "获取用户信息", description = "根据用户ID获取用户信息")
    public Result<UserRspVO> getUserInfo(
            @Parameter(name = "userId", description = "用户ID", required = true)
            @PathVariable("userId") Long userId) {
        UserRspVO user = userService.getUserById(userId);
        return Result.success(user);
    }

    @PutMapping("/{userId}")
    @Operation(summary = "更新用户信息", description = "更新用户昵称、头像等信息")
    public Result<UserRspVO> updateUser(
            @Parameter(name = "userId", description = "用户ID", required = true)
            @PathVariable("userId") Long userId,
            @Parameter(name = "nickname", description = "昵称")
            @RequestParam(value = "nickname", required = false) String nickname,
            @Parameter(name = "avatar", description = "头像URL")
            @RequestParam(value = "avatar", required = false) String avatar) {
        UserRspVO user = userService.updateUser(userId, nickname, avatar);
        return Result.success(user);
    }

    @PutMapping("/{userId}/password")
    @Operation(summary = "修改密码", description = "修改用户密码")
    public Result<Void> changePassword(
            @Parameter(name = "userId", description = "用户ID", required = true)
            @PathVariable("userId") Long userId,
            @Parameter(name = "oldPassword", description = "原密码", required = true)
            @RequestParam("oldPassword") String oldPassword,
            @Parameter(name = "newPassword", description = "新密码", required = true)
            @RequestParam("newPassword") String newPassword) {
        userService.changePassword(userId, oldPassword, newPassword);
        return Result.success();
    }
}
