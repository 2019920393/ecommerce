package com.ecommerce.user.service;

import com.ecommerce.common.exception.AddressNotFoundException;
import com.ecommerce.common.exception.BusinessException;
import com.ecommerce.user.domain.entity.ShippingAddress;
import com.ecommerce.user.dto.AddressRequest;
import com.ecommerce.user.dto.AddressRspVO;
import com.ecommerce.user.mapper.ShippingAddressMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

/**
 * 收货地址服务
 * 对应文档：6.2.1类的属性和操作定义.md - ShippingAddress操作
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class AddressService {

    private final ShippingAddressMapper addressMapper;

    /**
     * 新增收货地址
     */
    @Transactional
    public AddressRspVO addAddress(AddressRequest request) {
        log.info("新增收货地址: userId={}", request.getUserId());

        // 如果设为默认，先取消其他默认地址
        if (Boolean.TRUE.equals(request.getIsDefault())) {
            addressMapper.cancelAllDefault(request.getUserId());
        }

        ShippingAddress address = new ShippingAddress();
        address.setUserId(request.getUserId());
        address.setRecipientName(request.getRecipientName());
        address.setPhone(request.getPhone());
        address.setProvince(request.getProvince());
        address.setCity(request.getCity());
        address.setDistrict(request.getDistrict());
        address.setDetailAddress(request.getDetailAddress());
        address.setPostalCode(request.getPostalCode());
        address.setIsDefault(request.getIsDefault());

        addressMapper.insert(address);
        log.info("收货地址新增成功: addressId={}", address.getAddressId());

        return convertToRspVO(address);
    }

    /**
     * 查询用户地址列表
     */
    public List<AddressRspVO> getAddressList(Long userId) {
        List<ShippingAddress> addresses = addressMapper.findByUserId(userId);
        return addresses.stream()
                .map(this::convertToRspVO)
                .collect(Collectors.toList());
    }

    /**
     * 查询地址详情
     */
    public AddressRspVO getAddressById(Long addressId) {
        ShippingAddress address = addressMapper.selectById(addressId);
        if (address == null) {
            throw new AddressNotFoundException("收货地址不存在");
        }
        return convertToRspVO(address);
    }

    /**
     * 更新收货地址
     */
    @Transactional
    public AddressRspVO updateAddress(Long addressId, AddressRequest request) {
        log.info("更新收货地址: addressId={}", addressId);

        ShippingAddress address = addressMapper.selectById(addressId);
        if (address == null) {
            throw new AddressNotFoundException("收货地址不存在");
        }

        // 验证地址归属
        if (!address.getUserId().equals(request.getUserId())) {
            throw new BusinessException(403, "无权修改此地址");
        }

        // 如果设为默认，先取消其他默认地址
        if (Boolean.TRUE.equals(request.getIsDefault()) && !Boolean.TRUE.equals(address.getIsDefault())) {
            addressMapper.cancelAllDefault(request.getUserId());
        }

        address.setRecipientName(request.getRecipientName());
        address.setPhone(request.getPhone());
        address.setProvince(request.getProvince());
        address.setCity(request.getCity());
        address.setDistrict(request.getDistrict());
        address.setDetailAddress(request.getDetailAddress());
        address.setPostalCode(request.getPostalCode());
        address.setIsDefault(request.getIsDefault());

        addressMapper.updateById(address);
        log.info("收货地址更新成功: addressId={}", addressId);

        return convertToRspVO(address);
    }

    /**
     * 删除收货地址
     */
    @Transactional
    public void deleteAddress(Long addressId, Long userId) {
        log.info("删除收货地址: addressId={}, userId={}", addressId, userId);

        ShippingAddress address = addressMapper.selectById(addressId);
        if (address == null) {
            throw new AddressNotFoundException("收货地址不存在");
        }

        // 验证地址归属
        if (!address.getUserId().equals(userId)) {
            throw new BusinessException(403, "无权删除此地址");
        }

        addressMapper.deleteById(addressId);
        log.info("收货地址删除成功: addressId={}", addressId);
    }

    /**
     * 设置默认地址
     */
    @Transactional
    public void setDefault(Long addressId, Long userId) {
        log.info("设置默认地址: addressId={}, userId={}", addressId, userId);

        ShippingAddress address = addressMapper.selectById(addressId);
        if (address == null) {
            throw new AddressNotFoundException("收货地址不存在");
        }

        // 验证地址归属
        if (!address.getUserId().equals(userId)) {
            throw new BusinessException(403, "无权操作此地址");
        }

        // 取消其他默认地址
        addressMapper.cancelAllDefault(userId);

        // 设置当前地址为默认
        address.setIsDefault(true);
        addressMapper.updateById(address);
        log.info("默认地址设置成功: addressId={}", addressId);
    }

    /**
     * 获取用户默认地址
     */
    public AddressRspVO getDefaultAddress(Long userId) {
        ShippingAddress address = addressMapper.findDefaultByUserId(userId);
        if (address == null) {
            return null;
        }
        return convertToRspVO(address);
    }

    private AddressRspVO convertToRspVO(ShippingAddress address) {
        return AddressRspVO.builder()
                .addressId(address.getAddressId())
                .userId(address.getUserId())
                .recipientName(address.getRecipientName())
                .phone(address.getPhone())
                .province(address.getProvince())
                .city(address.getCity())
                .district(address.getDistrict())
                .detailAddress(address.getDetailAddress())
                .fullAddress(address.getFullAddress())
                .postalCode(address.getPostalCode())
                .isDefault(address.getIsDefault())
                .createTime(address.getCreateTime())
                .build();
    }
}
