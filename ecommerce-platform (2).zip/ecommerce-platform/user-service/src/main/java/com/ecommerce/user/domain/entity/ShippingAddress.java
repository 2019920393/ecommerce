package com.ecommerce.user.domain.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * 收货地址实体
 * 对应文档：6.2.1类的属性和操作定义.md - ShippingAddress
 */
@Data
@TableName("shipping_address")
public class ShippingAddress {

    /**
     * 地址ID，主键
     */
    @TableId(type = IdType.AUTO)
    private Long addressId;

    /**
     * 用户ID，外键
     */
    private Long userId;

    /**
     * 收货人姓名，最长20字符
     */
    private String recipientName;

    /**
     * 联系电话，11位手机号
     */
    private String phone;

    /**
     * 省
     */
    private String province;

    /**
     * 市
     */
    private String city;

    /**
     * 区/县
     */
    private String district;

    /**
     * 详细地址，最长100字符
     */
    private String detailAddress;

    /**
     * 邮政编码，6位，可选
     */
    private String postalCode;

    /**
     * 是否默认地址
     */
    private Boolean isDefault;

    /**
     * 创建时间
     */
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;

    /**
     * 更新时间
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;

    /**
     * 获取完整地址字符串
     */
    public String getFullAddress() {
        StringBuilder sb = new StringBuilder();
        if (province != null) sb.append(province);
        if (city != null) sb.append(city);
        if (district != null) sb.append(district);
        if (detailAddress != null) sb.append(detailAddress);
        return sb.toString();
    }
}
