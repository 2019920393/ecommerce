package com.ecommerce.user.domain.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * 用户实体
 * 对应文档：6.2.1类的属性和操作定义.md - User
 */
@Data
@TableName("user")
public class User {

    /**
     * 用户ID，主键
     */
    @TableId(type = IdType.AUTO)
    private Long userId;

    /**
     * 用户名，长度4-20个字符，唯一
     */
    private String username;

    /**
     * 密码（加密），BCrypt加密
     */
    private String password;

    /**
     * 手机号，11位，用于登录
     */
    private String phone;

    /**
     * 邮箱，用于登录和通知
     */
    private String email;

    /**
     * 昵称，最长50字符
     */
    private String nickname;

    /**
     * 头像URL
     */
    private String avatar;

    /**
     * 角色：USER/ADMIN
     */
    private String role;

    /**
     * 用户状态：NORMAL/FROZEN/DELETED
     */
    private String status;

    /**
     * 创建时间
     */
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;

    /**
     * 更新时间
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;

    /**
     * 判断是否为管理员
     */
    public boolean isAdmin() {
        return "ADMIN".equals(role);
    }

    /**
     * 判断账户是否激活
     */
    public boolean isActive() {
        return "NORMAL".equals(status);
    }
}
