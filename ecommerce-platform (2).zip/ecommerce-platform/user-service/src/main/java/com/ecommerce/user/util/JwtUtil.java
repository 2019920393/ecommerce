package com.ecommerce.user.util;

import cn.hutool.jwt.JWT;
import cn.hutool.jwt.JWTUtil;
import cn.hutool.jwt.signers.JWTSignerUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * JWT工具类
 */
@Slf4j
@Component
public class JwtUtil {

    @Value("${jwt.secret:ecommerce-platform-secret-key-2025}")
    private String secret;

    @Value("${jwt.expiration:7200}")
    private Long expiration; // 默认2小时

    /**
     * 生成JWT Token
     */
    public String generateToken(Long userId, String username, String role) {
        Map<String, Object> payload = new HashMap<>();
        payload.put("userId", userId);
        payload.put("username", username);
        payload.put("role", role);
        payload.put("iat", System.currentTimeMillis());
        payload.put("exp", System.currentTimeMillis() + expiration * 1000);

        return JWTUtil.createToken(payload, secret.getBytes());
    }

    /**
     * 验证Token
     */
    public boolean validateToken(String token) {
        try {
            JWT jwt = JWTUtil.parseToken(token);
            return jwt.setKey(secret.getBytes()).verify() && !isTokenExpired(jwt);
        } catch (Exception e) {
            log.error("Token验证失败: {}", e.getMessage());
            return false;
        }
    }

    /**
     * 从Token中获取用户ID
     */
    public Long getUserIdFromToken(String token) {
        try {
            JWT jwt = JWTUtil.parseToken(token);
            Object userId = jwt.getPayload("userId");
            return userId != null ? Long.valueOf(userId.toString()) : null;
        } catch (Exception e) {
            log.error("获取用户ID失败: {}", e.getMessage());
            return null;
        }
    }

    /**
     * 从Token中获取用户名
     */
    public String getUsernameFromToken(String token) {
        try {
            JWT jwt = JWTUtil.parseToken(token);
            Object username = jwt.getPayload("username");
            return username != null ? username.toString() : null;
        } catch (Exception e) {
            log.error("获取用户名失败: {}", e.getMessage());
            return null;
        }
    }

    /**
     * 从Token中获取角色
     */
    public String getRoleFromToken(String token) {
        try {
            JWT jwt = JWTUtil.parseToken(token);
            Object role = jwt.getPayload("role");
            return role != null ? role.toString() : null;
        } catch (Exception e) {
            log.error("获取角色失败: {}", e.getMessage());
            return null;
        }
    }

    /**
     * 判断Token是否过期
     */
    private boolean isTokenExpired(JWT jwt) {
        Object exp = jwt.getPayload("exp");
        if (exp == null) {
            return true;
        }
        long expTime = Long.parseLong(exp.toString());
        return expTime < System.currentTimeMillis();
    }

    /**
     * 获取过期时间（秒）
     */
    public Long getExpiration() {
        return expiration;
    }
}
