package com.ecommerce.user.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ecommerce.user.domain.entity.ShippingAddress;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

/**
 * 收货地址数据访问层
 */
@Mapper
public interface ShippingAddressMapper extends BaseMapper<ShippingAddress> {

    /**
     * 根据用户ID查询地址列表
     */
    @Select("SELECT * FROM shipping_address WHERE user_id = #{userId} ORDER BY is_default DESC, create_time DESC")
    List<ShippingAddress> findByUserId(@Param("userId") Long userId);

    /**
     * 查询用户默认地址
     */
    @Select("SELECT * FROM shipping_address WHERE user_id = #{userId} AND is_default = 1 LIMIT 1")
    ShippingAddress findDefaultByUserId(@Param("userId") Long userId);

    /**
     * 取消用户所有默认地址
     */
    @Update("UPDATE shipping_address SET is_default = 0 WHERE user_id = #{userId}")
    int cancelAllDefault(@Param("userId") Long userId);
}
