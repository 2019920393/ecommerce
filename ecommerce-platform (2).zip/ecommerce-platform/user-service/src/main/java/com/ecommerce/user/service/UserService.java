package com.ecommerce.user.service;

import cn.hutool.crypto.digest.BCrypt;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ecommerce.common.exception.BusinessException;
import com.ecommerce.user.domain.entity.User;
import com.ecommerce.user.dto.*;
import com.ecommerce.user.mapper.UserMapper;
import com.ecommerce.user.util.JwtUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * 用户服务
 * 对应文档：6.2.1类的属性和操作定义.md - User操作
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class UserService {

    private final UserMapper userMapper;
    private final JwtUtil jwtUtil;

    /**
     * 用户注册
     */
    @Transactional
    public UserRspVO register(RegisterRequest request) {
        log.info("用户注册: username={}", request.getUsername());

        // 检查用户名是否已存在
        if (userMapper.findByUsername(request.getUsername()) != null) {
            throw new BusinessException(400, "用户名已存在");
        }

        // 检查手机号是否已存在
        if (userMapper.findByPhone(request.getPhone()) != null) {
            throw new BusinessException(400, "手机号已被注册");
        }

        // 创建用户
        User user = new User();
        user.setUsername(request.getUsername());
        user.setPassword(BCrypt.hashpw(request.getPassword()));
        user.setPhone(request.getPhone());
        user.setEmail(request.getEmail());
        user.setNickname(request.getNickname() != null ? request.getNickname() : request.getUsername());
        user.setRole("USER");
        user.setStatus("NORMAL");

        userMapper.insert(user);
        log.info("用户注册成功: userId={}", user.getUserId());

        return convertToRspVO(user);
    }

    /**
     * 用户登录
     */
    public LoginRspVO login(LoginRequest request) {
        log.info("用户登录: username={}", request.getUsername());

        // 根据用户名或手机号查询用户
        User user = userMapper.findByUsername(request.getUsername());
        if (user == null) {
            user = userMapper.findByPhone(request.getUsername());
        }

        if (user == null) {
            throw new BusinessException(400, "用户名或密码错误");
        }

        // 验证密码
        if (!BCrypt.checkpw(request.getPassword(), user.getPassword())) {
            throw new BusinessException(400, "用户名或密码错误");
        }

        // 检查用户状态
        if (!user.isActive()) {
            throw new BusinessException(400, "账户已被冻结，请联系客服");
        }

        // 生成JWT Token
        String token = jwtUtil.generateToken(user.getUserId(), user.getUsername(), user.getRole());

        log.info("用户登录成功: userId={}", user.getUserId());

        return LoginRspVO.builder()
                .user(convertToRspVO(user))
                .token(token)
                .expiresIn(jwtUtil.getExpiration())
                .build();
    }

    /**
     * 获取用户列表（分页）
     */
    public Page<UserRspVO> listUsers(Integer pageNum, Integer pageSize) {
        Page<User> page = new Page<>(pageNum, pageSize);
        Page<User> userPage = userMapper.selectPage(page, null);
        
        Page<UserRspVO> result = new Page<>(pageNum, pageSize);
        result.setTotal(userPage.getTotal());
        result.setRecords(userPage.getRecords().stream().map(this::convertToRspVO).toList());
        return result;
    }

    /**
     * 获取用户信息
     */
    public UserRspVO getUserById(Long userId) {
        User user = userMapper.selectById(userId);
        if (user == null) {
            throw new BusinessException(404, "用户不存在");
        }
        return convertToRspVO(user);
    }

    /**
     * 更新用户信息
     */
    @Transactional
    public UserRspVO updateUser(Long userId, String nickname, String avatar) {
        User user = userMapper.selectById(userId);
        if (user == null) {
            throw new BusinessException(404, "用户不存在");
        }

        if (nickname != null) {
            user.setNickname(nickname);
        }
        if (avatar != null) {
            user.setAvatar(avatar);
        }

        userMapper.updateById(user);
        log.info("用户信息更新成功: userId={}", userId);

        return convertToRspVO(user);
    }

    /**
     * 修改密码
     */
    @Transactional
    public void changePassword(Long userId, String oldPassword, String newPassword) {
        User user = userMapper.selectById(userId);
        if (user == null) {
            throw new BusinessException(404, "用户不存在");
        }

        // 验证旧密码
        if (!BCrypt.checkpw(oldPassword, user.getPassword())) {
            throw new BusinessException(400, "原密码错误");
        }

        // 更新密码
        user.setPassword(BCrypt.hashpw(newPassword));
        userMapper.updateById(user);
        log.info("密码修改成功: userId={}", userId);
    }

    private UserRspVO convertToRspVO(User user) {
        return UserRspVO.builder()
                .userId(user.getUserId())
                .username(user.getUsername())
                .phone(user.getPhone())
                .email(user.getEmail())
                .nickname(user.getNickname())
                .avatar(user.getAvatar())
                .role(user.getRole())
                .status(user.getStatus())
                .createTime(user.getCreateTime())
                .build();
    }
}
