package com.ecommerce.user;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

/**
 * 用户服务启动类
 * 提供用户注册、登录、JWT认证、收货地址管理功能
 */
@SpringBootApplication(scanBasePackages = {"com.ecommerce.user", "com.ecommerce.common"})
@MapperScan("com.ecommerce.user.mapper")
@EnableDiscoveryClient
public class UserServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(UserServiceApplication.class, args);
    }
}
