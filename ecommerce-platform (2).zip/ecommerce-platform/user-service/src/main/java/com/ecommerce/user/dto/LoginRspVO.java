package com.ecommerce.user.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 登录响应VO
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "登录响应")
public class LoginRspVO {

    @Schema(description = "用户信息")
    private UserRspVO user;

    @Schema(description = "JWT Token")
    private String token;

    @Schema(description = "Token过期时间（秒）")
    private Long expiresIn;
}
