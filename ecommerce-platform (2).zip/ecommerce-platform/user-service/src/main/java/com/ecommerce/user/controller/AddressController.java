package com.ecommerce.user.controller;

import com.ecommerce.common.result.Result;
import com.ecommerce.user.dto.AddressRequest;
import com.ecommerce.user.dto.AddressRspVO;
import com.ecommerce.user.service.AddressService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 收货地址控制器
 */
@Slf4j
@RestController
@RequestMapping("/api/v1/addresses")
@RequiredArgsConstructor
@Tag(name = "收货地址管理", description = "收货地址的增删改查接口")
public class AddressController {

    private final AddressService addressService;

    @PostMapping
    @Operation(summary = "新增收货地址", description = "新增用户收货地址")
    public Result<AddressRspVO> addAddress(@Valid @RequestBody AddressRequest request) {
        log.info("新增收货地址请求: userId={}", request.getUserId());
        AddressRspVO address = addressService.addAddress(request);
        return Result.success(address);
    }

    @GetMapping("/user/{userId}")
    @Operation(summary = "查询用户地址列表", description = "查询用户的所有收货地址")
    public Result<List<AddressRspVO>> getAddressList(
            @Parameter(name = "userId", description = "用户ID", required = true)
            @PathVariable("userId") Long userId) {
        List<AddressRspVO> addresses = addressService.getAddressList(userId);
        return Result.success(addresses);
    }

    @GetMapping("/{addressId}")
    @Operation(summary = "查询地址详情", description = "根据地址ID查询地址详情")
    public Result<AddressRspVO> getAddress(
            @Parameter(name = "addressId", description = "地址ID", required = true)
            @PathVariable("addressId") Long addressId) {
        AddressRspVO address = addressService.getAddressById(addressId);
        return Result.success(address);
    }

    @GetMapping("/user/{userId}/default")
    @Operation(summary = "查询默认地址", description = "查询用户的默认收货地址")
    public Result<AddressRspVO> getDefaultAddress(
            @Parameter(name = "userId", description = "用户ID", required = true)
            @PathVariable("userId") Long userId) {
        AddressRspVO address = addressService.getDefaultAddress(userId);
        return Result.success(address);
    }

    @PutMapping("/{addressId}")
    @Operation(summary = "更新收货地址", description = "更新收货地址信息")
    public Result<AddressRspVO> updateAddress(
            @Parameter(name = "addressId", description = "地址ID", required = true)
            @PathVariable("addressId") Long addressId,
            @Valid @RequestBody AddressRequest request) {
        log.info("更新收货地址请求: addressId={}", addressId);
        AddressRspVO address = addressService.updateAddress(addressId, request);
        return Result.success(address);
    }

    @DeleteMapping("/{addressId}")
    @Operation(summary = "删除收货地址", description = "删除指定收货地址")
    public Result<Void> deleteAddress(
            @Parameter(name = "addressId", description = "地址ID", required = true)
            @PathVariable("addressId") Long addressId,
            @Parameter(name = "userId", description = "用户ID", required = true)
            @RequestParam("userId") Long userId) {
        log.info("删除收货地址请求: addressId={}, userId={}", addressId, userId);
        addressService.deleteAddress(addressId, userId);
        return Result.success();
    }

    @PutMapping("/{addressId}/default")
    @Operation(summary = "设置默认地址", description = "将指定地址设为默认地址")
    public Result<Void> setDefault(
            @Parameter(name = "addressId", description = "地址ID", required = true)
            @PathVariable("addressId") Long addressId,
            @Parameter(name = "userId", description = "用户ID", required = true)
            @RequestParam("userId") Long userId) {
        log.info("设置默认地址请求: addressId={}, userId={}", addressId, userId);
        addressService.setDefault(addressId, userId);
        return Result.success();
    }
}
