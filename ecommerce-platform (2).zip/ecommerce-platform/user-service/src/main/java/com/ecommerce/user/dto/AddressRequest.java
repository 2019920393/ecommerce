package com.ecommerce.user.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.Data;

/**
 * 收货地址请求DTO
 */
@Data
@Schema(description = "收货地址请求")
public class AddressRequest {

    @Schema(description = "用户ID", example = "1", required = true)
    @NotNull(message = "用户ID不能为空")
    private Long userId;

    @Schema(description = "收货人姓名", example = "张三", required = true)
    @NotBlank(message = "收货人姓名不能为空")
    private String recipientName;

    @Schema(description = "联系电话", example = "13800138000", required = true)
    @NotBlank(message = "联系电话不能为空")
    @Pattern(regexp = "^1[3-9]\\d{9}$", message = "手机号格式不正确")
    private String phone;

    @Schema(description = "省", example = "广东省", required = true)
    @NotBlank(message = "省不能为空")
    private String province;

    @Schema(description = "市", example = "深圳市", required = true)
    @NotBlank(message = "市不能为空")
    private String city;

    @Schema(description = "区", example = "南山区", required = true)
    @NotBlank(message = "区不能为空")
    private String district;

    @Schema(description = "详细地址", example = "科技园南路88号", required = true)
    @NotBlank(message = "详细地址不能为空")
    private String detailAddress;

    @Schema(description = "邮政编码", example = "518000")
    private String postalCode;

    @Schema(description = "是否设为默认地址", example = "false")
    private Boolean isDefault = false;
}
