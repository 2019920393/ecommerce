-- 用户服务数据库初始化脚本
-- 数据库：user_db

-- 创建数据库（如果不存在）
CREATE DATABASE IF NOT EXISTS user_db DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE user_db;

-- 用户表
DROP TABLE IF EXISTS user;
CREATE TABLE user (
    user_id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '用户ID',
    username VARCHAR(20) NOT NULL UNIQUE COMMENT '用户名',
    password VARCHAR(100) NOT NULL COMMENT '密码（BCrypt加密）',
    phone VARCHAR(11) UNIQUE COMMENT '手机号',
    email VARCHAR(50) COMMENT '邮箱',
    nickname VARCHAR(50) COMMENT '昵称',
    avatar VARCHAR(255) COMMENT '头像URL',
    role VARCHAR(10) NOT NULL DEFAULT 'USER' COMMENT '角色：USER/ADMIN',
    status VARCHAR(10) NOT NULL DEFAULT 'NORMAL' COMMENT '状态：NORMAL/FROZEN/DELETED',
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    update_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    INDEX idx_phone (phone),
    INDEX idx_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户表';

-- 收货地址表
DROP TABLE IF EXISTS shipping_address;
CREATE TABLE shipping_address (
    address_id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '地址ID',
    user_id BIGINT NOT NULL COMMENT '用户ID',
    recipient_name VARCHAR(20) NOT NULL COMMENT '收货人姓名',
    phone VARCHAR(11) NOT NULL COMMENT '联系电话',
    province VARCHAR(20) NOT NULL COMMENT '省',
    city VARCHAR(20) NOT NULL COMMENT '市',
    district VARCHAR(20) NOT NULL COMMENT '区/县',
    detail_address VARCHAR(100) NOT NULL COMMENT '详细地址',
    postal_code VARCHAR(6) COMMENT '邮政编码',
    is_default TINYINT(1) DEFAULT 0 COMMENT '是否默认地址',
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    update_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    INDEX idx_user_id (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='收货地址表';

-- 插入测试用户（密码：123456，BCrypt加密）
INSERT INTO user (username, password, phone, email, nickname, role, status) VALUES
('admin', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iAt6Z5EH', '13800000000', 'admin@example.com', '管理员', 'ADMIN', 'NORMAL'),
('zhangsan', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iAt6Z5EH', '13800138001', 'zhangsan@example.com', '张三', 'USER', 'NORMAL'),
('lisi', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iAt6Z5EH', '13800138002', 'lisi@example.com', '李四', 'USER', 'NORMAL');

-- 插入测试收货地址
INSERT INTO shipping_address (user_id, recipient_name, phone, province, city, district, detail_address, is_default) VALUES
(2, '张三', '13800138001', '广东省', '深圳市', '南山区', '科技园南路88号', 1),
(2, '张三', '13800138001', '广东省', '广州市', '天河区', '天河路100号', 0),
(3, '李四', '13800138002', '北京市', '北京市', '朝阳区', '建国路99号', 1);
