package com.ecommerce.user.service;

import com.ecommerce.common.exception.BusinessException;
import com.ecommerce.user.domain.entity.User;
import com.ecommerce.user.dto.*;
import com.ecommerce.user.mapper.UserMapper;
import com.ecommerce.user.util.JwtUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;
import cn.hutool.crypto.digest.BCrypt;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * UserService 单元测试
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("UserService 单元测试")
class UserServiceTest {

    @Mock
    private UserMapper userMapper;

    @Mock
    private JwtUtil jwtUtil;

    @InjectMocks
    private UserService userService;

    private User mockUser;
    private RegisterRequest registerRequest;
    private LoginRequest loginRequest;

    @BeforeEach
    void setUp() {
        mockUser = new User();
        mockUser.setUserId(1L);
        mockUser.setUsername("testuser");
        mockUser.setPassword(BCrypt.hashpw("123456"));
        mockUser.setPhone("13800138000");
        mockUser.setEmail("test@example.com");
        mockUser.setNickname("测试用户");
        mockUser.setStatus("NORMAL");
        mockUser.setRole("USER");

        registerRequest = new RegisterRequest();
        registerRequest.setUsername("newuser");
        registerRequest.setPassword("123456");
        registerRequest.setPhone("13900139000");
        registerRequest.setEmail("new@example.com");
        registerRequest.setNickname("新用户");

        loginRequest = new LoginRequest();
        loginRequest.setUsername("testuser");
        loginRequest.setPassword("123456");
    }

    @Nested
    @DisplayName("用户注册测试")
    class RegisterTests {

        @Test
        @DisplayName("正常注册新用户")
        void testRegister_Success() {
            when(userMapper.findByUsername("newuser")).thenReturn(null);
            when(userMapper.findByPhone("13900139000")).thenReturn(null);
            when(userMapper.insert(any(User.class))).thenReturn(1);

            UserRspVO result = userService.register(registerRequest);

            assertNotNull(result, "注册结果不应为空");
            assertEquals("newuser", result.getUsername(), "用户名应匹配");
            verify(userMapper, times(1)).insert(any(User.class));
        }

        @Test
        @DisplayName("用户名已存在时注册失败")
        void testRegister_UsernameExists() {
            when(userMapper.findByUsername("newuser")).thenReturn(mockUser);

            assertThrows(BusinessException.class, () -> {
                userService.register(registerRequest);
            }, "用户名已存在时应抛出异常");

            verify(userMapper, never()).insert(any(User.class));
        }

        @Test
        @DisplayName("手机号已存在时注册失败")
        void testRegister_PhoneExists() {
            when(userMapper.findByUsername("newuser")).thenReturn(null);
            when(userMapper.findByPhone("13900139000")).thenReturn(mockUser);

            assertThrows(BusinessException.class, () -> {
                userService.register(registerRequest);
            }, "手机号已存在时应抛出异常");
        }
    }

    @Nested
    @DisplayName("用户登录测试")
    class LoginTests {

        @Test
        @DisplayName("正常登录成功")
        void testLogin_Success() {
            // 使用明确知道的密码哈希
            String plainPassword = "123456";
            String hashedPassword = BCrypt.hashpw(plainPassword);
            mockUser.setPassword(hashedPassword);
            
            when(userMapper.findByUsername("testuser")).thenReturn(mockUser);
            when(jwtUtil.generateToken(1L, "testuser", "USER")).thenReturn("mock.jwt.token");
            when(jwtUtil.getExpiration()).thenReturn(86400L);

            loginRequest.setPassword(plainPassword);
            LoginRspVO result = userService.login(loginRequest);

            assertNotNull(result, "登录结果不应为空");
            assertNotNull(result.getToken(), "Token不应为空");
            assertEquals("mock.jwt.token", result.getToken(), "Token应匹配");
        }

        @Test
        @DisplayName("用户不存在时登录失败")
        void testLogin_UserNotFound() {
            when(userMapper.findByUsername("testuser")).thenReturn(null);
            when(userMapper.findByPhone("testuser")).thenReturn(null);

            assertThrows(BusinessException.class, () -> {
                userService.login(loginRequest);
            }, "用户不存在时应抛出异常");
        }

        @Test
        @DisplayName("密码错误时登录失败")
        void testLogin_WrongPassword() {
            when(userMapper.findByUsername("testuser")).thenReturn(mockUser);
            loginRequest.setPassword("wrongpassword");

            assertThrows(BusinessException.class, () -> {
                userService.login(loginRequest);
            }, "密码错误时应抛出异常");
        }

        @Test
        @DisplayName("账号被禁用时登录失败")
        void testLogin_AccountDisabled() {
            String plainPassword = "123456";
            mockUser.setPassword(BCrypt.hashpw(plainPassword));
            mockUser.setStatus("FROZEN");
            when(userMapper.findByUsername("testuser")).thenReturn(mockUser);
            loginRequest.setPassword(plainPassword);

            assertThrows(BusinessException.class, () -> {
                userService.login(loginRequest);
            }, "账号被禁用时应抛出异常");
        }
    }

    @Nested
    @DisplayName("用户信息查询测试")
    class GetUserTests {

        @Test
        @DisplayName("根据ID查询用户信息")
        void testGetUserById_Success() {
            when(userMapper.selectById(1L)).thenReturn(mockUser);

            UserRspVO result = userService.getUserById(1L);

            assertNotNull(result, "用户信息不应为空");
            assertEquals(1L, result.getUserId(), "用户ID应匹配");
            assertEquals("testuser", result.getUsername(), "用户名应匹配");
        }

        @Test
        @DisplayName("查询不存在的用户")
        void testGetUserById_NotFound() {
            when(userMapper.selectById(999L)).thenReturn(null);

            assertThrows(BusinessException.class, () -> {
                userService.getUserById(999L);
            }, "用户不存在时应抛出异常");
        }
    }

    @Nested
    @DisplayName("修改密码测试")
    class ChangePasswordTests {

        @Test
        @DisplayName("正常修改密码")
        void testChangePassword_Success() {
            String oldPassword = "123456";
            mockUser.setPassword(BCrypt.hashpw(oldPassword));
            when(userMapper.selectById(1L)).thenReturn(mockUser);
            when(userMapper.updateById(any(User.class))).thenReturn(1);

            assertDoesNotThrow(() -> {
                userService.changePassword(1L, oldPassword, "newPassword");
            });

            verify(userMapper, times(1)).updateById(any(User.class));
        }

        @Test
        @DisplayName("旧密码错误时修改失败")
        void testChangePassword_WrongOldPassword() {
            mockUser.setPassword(BCrypt.hashpw("correctPassword"));
            when(userMapper.selectById(1L)).thenReturn(mockUser);

            assertThrows(BusinessException.class, () -> {
                userService.changePassword(1L, "wrongPassword", "newPassword");
            }, "旧密码错误时应抛出异常");
        }
    }
}
