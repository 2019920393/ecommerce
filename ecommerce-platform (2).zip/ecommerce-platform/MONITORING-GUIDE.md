# 云原生微服务电商平台 - 监控指南

## 监控架构

```
┌─────────────────────────────────────────────────────────────┐
│                      Grafana (3000)                         │
│                      监控可视化面板                          │
└─────────────────────────────────────────────────────────────┘
                              ↑
                              │ 查询指标
                              ↓
┌─────────────────────────────────────────────────────────────┐
│                    Prometheus (9090)                        │
│                      指标收集存储                            │
└─────────────────────────────────────────────────────────────┘
                              ↑
                              │ 抓取 /actuator/prometheus
                              ↓
┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐
│ Gateway  │ │ Product  │ │ Payment  │ │  Order   │ │   User   │
│  :8080   │ │  :8081   │ │  :8082   │ │  :8083   │ │  :8084   │
└──────────┘ └──────────┘ └──────────┘ └──────────┘ └──────────┘
```

## 访问地址

| 服务 | 地址 | 用户名/密码 |
|-----|------|------------|
| Grafana | http://localhost:3000 | admin / admin123 |
| Prometheus | http://localhost:9090 | - |

## 监控面板

启动后Grafana会自动加载预配置的监控面板：

### 电商平台监控面板
- 服务总数/健康服务数
- 平均响应时间
- 请求速率(QPS)
- JVM堆内存使用率
- HTTP请求速率
- 服务健康状态

## 常用PromQL查询

```promql
# 服务健康状态
up{job=~".*-service"}

# HTTP请求总数
http_server_requests_seconds_count

# 请求速率(每秒)
rate(http_server_requests_seconds_count[1m])

# 平均响应时间
http_server_requests_seconds_sum / http_server_requests_seconds_count

# JVM内存使用
jvm_memory_used_bytes{area="heap"}

# JVM线程数
jvm_threads_live_threads

# 数据库连接池
hikaricp_connections_active
```

## 告警配置（可选）

在 `docker/prometheus/alert_rules.yml` 中配置告警规则：

```yaml
groups:
  - name: ecommerce-alerts
    rules:
      - alert: ServiceDown
        expr: up == 0
        for: 1m
        labels:
          severity: critical
        annotations:
          summary: "服务 {{ $labels.job }} 已下线"
          
      - alert: HighResponseTime
        expr: http_server_requests_seconds_sum / http_server_requests_seconds_count > 1
        for: 5m
        labels:
          severity: warning
        annotations:
          summary: "服务 {{ $labels.application }} 响应时间过高"
```

## 快速启动

```bash
# 启动所有服务（包含监控）
docker-compose up -d

# 仅启动监控组件
docker-compose up -d prometheus grafana

# 查看Prometheus目标状态
curl http://localhost:9090/api/v1/targets
```
