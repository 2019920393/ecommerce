# 云原生微服务电商平台 - Docker部署指南

## 快速开始

### 1. 前置条件
- JDK 17+
- Maven 3.8+
- Docker 20.10+
- Docker Compose 2.0+

### 2. 构建项目

**Windows:**
```bash
build.bat
```

**Linux/Mac:**
```bash
chmod +x build.sh
./build.sh
```

### 3. 启动服务

```bash
docker-compose up -d
```

### 4. 验证服务

等待约60秒后，访问以下地址验证服务是否正常：

| 服务 | Swagger地址 | 端口 |
|------|------------|------|
| 商品服务 | http://localhost:8081/swagger-ui.html | 8081 |
| 支付服务 | http://localhost:8082/swagger-ui.html | 8082 |
| 订单服务 | http://localhost:8083/swagger-ui.html | 8083 |
| 用户服务 | http://localhost:8084/swagger-ui.html | 8084 |

### 5. 查看日志

```bash
# 查看所有服务日志
docker-compose logs -f

# 查看单个服务日志
docker-compose logs -f order-service
```

### 6. 停止服务

```bash
docker-compose down
```

### 7. 清理数据（重新初始化）

```bash
docker-compose down -v
docker-compose up -d
```

## 服务架构

```
┌─────────────────────────────────────────────────────────────┐
│                      Docker Network                          │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐    │
│  │ product  │  │ payment  │  │  order   │  │   user   │    │
│  │ service  │  │ service  │  │ service  │  │ service  │    │
│  │  :8081   │  │  :8082   │  │  :8083   │  │  :8084   │    │
│  └────┬─────┘  └────┬─────┘  └────┬─────┘  └────┬─────┘    │
│       │             │             │             │           │
│       └─────────────┴──────┬──────┴─────────────┘           │
│                            │                                 │
│                    ┌───────┴───────┐                        │
│                    │     MySQL     │                        │
│                    │    :3306      │                        │
│                    └───────────────┘                        │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

## 数据库信息

| 数据库 | 服务 | 说明 |
|--------|------|------|
| order_db | order-service | 订单、库存 |
| user_db | user-service | 用户、地址 |
| product_db | product-service | 商品、分类、购物车 |
| payment_db | payment-service | 支付订单、支付记录 |

## 测试账号

| 用户名 | 密码 | 角色 |
|--------|------|------|
| admin | 123456 | 管理员 |
| zhangsan | 123456 | 普通用户 |
| lisi | 123456 | 普通用户 |

## 常见问题

### Q: 服务启动失败，提示连接MySQL失败
A: MySQL需要约30秒初始化，请等待后重试，或查看MySQL日志：
```bash
docker-compose logs mysql
```

### Q: 如何修改数据库密码
A: 修改 `.env` 文件中的 `MYSQL_ROOT_PASSWORD`，然后重新启动：
```bash
docker-compose down -v
docker-compose up -d
```

### Q: 如何单独重启某个服务
A: 
```bash
docker-compose restart order-service
```
