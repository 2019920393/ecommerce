package com.ecommerce.order.service;

import com.ecommerce.common.enums.OrderStatus;
import com.ecommerce.common.exception.BusinessException;
import com.ecommerce.common.exception.OrderNotFoundException;
import com.ecommerce.common.exception.StockLockFailedException;
import com.ecommerce.order.domain.entity.Order;
import com.ecommerce.order.domain.entity.OrderItem;
import com.ecommerce.order.mapper.OrderItemMapper;
import com.ecommerce.order.mapper.OrderMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * OrderService 单元测试
 */
@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
@DisplayName("OrderService 单元测试")
class OrderServiceTest {

    @Mock
    private OrderMapper orderMapper;

    @Mock
    private OrderItemMapper orderItemMapper;

    @Mock
    private InventoryService inventoryService;

    @InjectMocks
    private OrderService orderService;

    private Order mockOrder;
    private List<OrderItem> mockOrderItems;

    @BeforeEach
    void setUp() {
        mockOrder = new Order();
        mockOrder.setOrderId(1L);
        mockOrder.setOrderNumber("ORD20251227001");
        mockOrder.setUserId(1L);
        mockOrder.setTotalAmount(new BigDecimal("15998.00"));
        mockOrder.setProductAmount(new BigDecimal("15998.00"));
        mockOrder.setShippingFee(BigDecimal.ZERO);
        mockOrder.setDiscount(BigDecimal.ZERO);
        mockOrder.setStatus("PENDING_PAYMENT");
        mockOrder.setRecipientName("张三");
        mockOrder.setRecipientPhone("13800138000");
        mockOrder.setProvince("广东省");
        mockOrder.setCity("深圳市");
        mockOrder.setDistrict("南山区");
        mockOrder.setDetailAddress("科技园南路88号");
        mockOrder.setShippingAddress("广东省深圳市南山区科技园南路88号");
        mockOrder.setCreateTime(LocalDateTime.now());
        mockOrder.setExpireTime(LocalDateTime.now().plusMinutes(30));

        OrderItem item = new OrderItem();
        item.setItemId(1L);
        item.setOrderId(1L);
        item.setOrderNumber("ORD20251227001");
        item.setProductId(1L);
        item.setProductName("iPhone 15 Pro");
        item.setUnitPrice(new BigDecimal("7999.00"));
        item.setQuantity(2);
        item.setSubtotal(new BigDecimal("15998.00"));
        mockOrderItems = Arrays.asList(item);
    }

    @Nested
    @DisplayName("创建订单测试")
    class CreateOrderTests {

        @Test
        @DisplayName("TC-UC9-001: 正常创建订单 - 主成功场景")
        void testCreateOrder_Success() {
            when(inventoryService.lockStock(anyString(), anyList())).thenReturn(true);
            when(orderMapper.insert(any(Order.class))).thenReturn(1);
            when(orderItemMapper.insert(any(OrderItem.class))).thenReturn(1);

            Order result = orderService.createOrder(
                    1L, mockOrderItems, "张三", "13800138000",
                    "广东省深圳市南山区科技园南路88号",
                    "广东省", "深圳市", "南山区", "科技园南路88号", "备注"
            );

            assertNotNull(result, "订单不应为空");
            assertNotNull(result.getOrderNumber(), "订单号不应为空");
            assertTrue(result.getOrderNumber().startsWith("ORD"), "订单号应以ORD开头");
            assertEquals("PENDING_PAYMENT", result.getStatus(), "订单状态应为待支付");

            verify(inventoryService, times(1)).lockStock(anyString(), anyList());
            verify(orderMapper, times(1)).insert(any(Order.class));
        }

        @Test
        @DisplayName("TC-UC9-002: 库存锁定失败时创建订单失败")
        void testCreateOrder_LockStockFailed() {
            when(inventoryService.lockStock(anyString(), anyList())).thenReturn(false);

            assertThrows(StockLockFailedException.class, () -> {
                orderService.createOrder(
                        1L, mockOrderItems, "张三", "13800138000",
                        "地址", "省", "市", "区", "详细地址", null
                );
            });

            verify(orderMapper, never()).insert(any(Order.class));
        }

        @Test
        @DisplayName("TC-UC9-005: 订单明细为空时创建失败")
        void testCreateOrder_EmptyItems() {
            assertThrows(Exception.class, () -> {
                orderService.createOrder(
                        1L, Collections.emptyList(), "张三", "13800138000",
                        "地址", "省", "市", "区", "详细地址", null
                );
            });
        }
    }

    @Nested
    @DisplayName("查询订单测试")
    class QueryOrderTests {

        @Test
        @DisplayName("根据订单号查询订单详情")
        void testGetOrderDetail_Success() {
            mockOrder.setItems(mockOrderItems);
            when(orderMapper.findByOrderNumber("ORD20251227001")).thenReturn(mockOrder);
            when(orderItemMapper.findByOrderNumber("ORD20251227001")).thenReturn(mockOrderItems);

            Order result = orderService.getOrderDetail("ORD20251227001");

            assertNotNull(result, "订单不应为空");
            assertEquals("ORD20251227001", result.getOrderNumber());
            assertEquals(1L, result.getUserId());
        }

        @Test
        @DisplayName("查询不存在的订单应抛出异常")
        void testGetOrderDetail_NotFound() {
            when(orderMapper.findByOrderNumber("INVALID")).thenReturn(null);

            assertThrows(OrderNotFoundException.class, () -> {
                orderService.getOrderDetail("INVALID");
            });
        }
    }

    @Nested
    @DisplayName("取消订单测试")
    class CancelOrderTests {

        @Test
        @DisplayName("正常取消待支付订单")
        void testCancelOrder_Success() {
            mockOrder.setStatus("PENDING_PAYMENT");
            when(orderMapper.findByOrderNumber("ORD20251227001")).thenReturn(mockOrder);
            when(orderMapper.updateById(any(Order.class))).thenReturn(1);
            when(orderItemMapper.findByOrderNumber(anyString())).thenReturn(mockOrderItems);
            when(inventoryService.releaseStock(anyString(), anyList())).thenReturn(true);

            assertDoesNotThrow(() -> {
                orderService.cancelOrder("ORD20251227001");
            });

            verify(inventoryService, times(1)).releaseStock(anyString(), anyList());
        }

        @Test
        @DisplayName("已发货订单不能取消")
        void testCancelOrder_AlreadyShipped() {
            mockOrder.setStatus("PENDING_RECEIPT");
            when(orderMapper.findByOrderNumber("ORD20251227001")).thenReturn(mockOrder);

            assertThrows(Exception.class, () -> {
                orderService.cancelOrder("ORD20251227001");
            });
        }
    }

    @Nested
    @DisplayName("订单状态更新测试")
    class UpdateStatusTests {

        @Test
        @DisplayName("支付成功更新订单状态为待发货")
        void testUpdateOrderStatus_PaymentSuccess() {
            mockOrder.setStatus("PENDING_PAYMENT");
            when(orderMapper.findByOrderNumber("ORD20251227001")).thenReturn(mockOrder);
            when(orderMapper.updateById(any(Order.class))).thenReturn(1);

            assertDoesNotThrow(() -> {
                orderService.updateOrderStatus("ORD20251227001", OrderStatus.PENDING_SHIPMENT);
            });

            verify(orderMapper, times(1)).updateById(any(Order.class));
        }
    }
}
