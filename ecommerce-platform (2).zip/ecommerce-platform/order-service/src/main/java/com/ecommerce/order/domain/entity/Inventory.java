package com.ecommerce.order.domain.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 库存实体类
 * <p>
 * 对应数据库表：inventory
 * 管理商品库存，支持库存预扣和乐观锁机制
 * </p>
 * 
 * <p>
 * 库存设计说明：
 * 1. total_stock：总库存 = available_stock + locked_stock
 * 2. available_stock：可用库存，用户可以下单的库存
 * 3. locked_stock：锁定库存，已下单但未支付的库存
 * 4. version：乐观锁版本号，防止并发扣减库存时的超卖问题
 * </p>
 * 
 * <p>
 * 库存操作流程：
 * 1. 创建订单：available_stock减少，locked_stock增加（预扣库存）
 * 2. 支付成功：locked_stock减少，total_stock减少（实际扣减）
 * 3. 订单取消：locked_stock减少，available_stock增加（释放库存）
 * 4. 订单超时：locked_stock减少，available_stock增加（自动释放）
 * </p>
 *
 * @author ecommerce-platform
 * @since 1.0.0
 */
@Data
@TableName("inventory")
public class Inventory implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 库存ID，主键，自增
     */
    @TableId(value = "inventory_id", type = IdType.AUTO)
    private Long inventoryId;

    /**
     * 商品ID
     * 关联商品表的product_id
     * 唯一索引，一个商品只有一条库存记录
     */
    @TableField("product_id")
    private Long productId;

    // ==================== 库存数量 ====================

    /**
     * 总库存数量
     * 总库存 = 可用库存 + 锁定库存
     */
    @TableField("total_stock")
    private Integer totalStock;

    /**
     * 可用库存
     * 用户可以下单的库存数量
     */
    @TableField("available_stock")
    private Integer availableStock;

    /**
     * 锁定库存（预扣库存）
     * 已下单但未支付的库存数量
     */
    @TableField("locked_stock")
    private Integer lockedStock;

    // ==================== 乐观锁 ====================

    /**
     * 版本号，乐观锁
     * 使用@Version注解，MyBatis-Plus会自动处理
     * 每次更新时version会自动+1
     */
    @Version
    @TableField("version")
    private Integer version;

    // ==================== 时间信息 ====================

    /**
     * 更新时间
     * 自动填充
     */
    @TableField(value = "update_time", fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;

    /**
     * 创建时间
     * 自动填充
     */
    @TableField(value = "create_time", fill = FieldFill.INSERT)
    private LocalDateTime createTime;

    // ==================== 业务方法 ====================

    /**
     * 检查库存是否充足
     *
     * @param quantity 需要的数量
     * @return true-库存充足，false-库存不足
     */
    public boolean isStockSufficient(Integer quantity) {
        if (quantity == null || quantity <= 0) {
            return false;
        }
        return availableStock != null && availableStock >= quantity;
    }

    /**
     * 锁定库存（预扣库存）
     * 创建订单时调用
     * 
     * @param quantity 锁定数量
     * @return true-锁定成功，false-锁定失败（库存不足）
     */
    public boolean lockStock(Integer quantity) {
        if (!isStockSufficient(quantity)) {
            return false;
        }
        
        this.availableStock -= quantity;
        this.lockedStock += quantity;
        return true;
    }

    /**
     * 扣减库存（实际扣减）
     * 支付成功时调用
     * 
     * @param quantity 扣减数量
     * @return true-扣减成功，false-扣减失败（锁定库存不足）
     */
    public boolean deductStock(Integer quantity) {
        if (lockedStock == null || lockedStock < quantity) {
            return false;
        }
        
        this.lockedStock -= quantity;
        this.totalStock -= quantity;
        return true;
    }

    /**
     * 释放库存
     * 订单取消或超时时调用
     * 
     * @param quantity 释放数量
     * @return true-释放成功，false-释放失败（锁定库存不足）
     */
    public boolean releaseStock(Integer quantity) {
        if (lockedStock == null || lockedStock < quantity) {
            return false;
        }
        
        this.lockedStock -= quantity;
        this.availableStock += quantity;
        return true;
    }

    /**
     * 增加库存
     * 商品入库时调用
     * 
     * @param quantity 增加数量
     */
    public void addStock(Integer quantity) {
        if (quantity == null || quantity <= 0) {
            return;
        }
        
        this.totalStock = (this.totalStock == null ? 0 : this.totalStock) + quantity;
        this.availableStock = (this.availableStock == null ? 0 : this.availableStock) + quantity;
    }

    /**
     * 验证库存数据一致性
     * 检查：total_stock = available_stock + locked_stock
     *
     * @return true-一致，false-不一致
     */
    public boolean isConsistent() {
        if (totalStock == null || availableStock == null || lockedStock == null) {
            return false;
        }
        return totalStock.equals(availableStock + lockedStock);
    }

    /**
     * 判断是否缺货
     * 可用库存为0视为缺货
     *
     * @return true-缺货，false-有货
     */
    public boolean isOutOfStock() {
        return availableStock == null || availableStock <= 0;
    }

    /**
     * 判断是否低库存
     * 可用库存小于等于指定阈值视为低库存
     *
     * @param threshold 阈值
     * @return true-低库存，false-库存充足
     */
    public boolean isLowStock(Integer threshold) {
        if (threshold == null || threshold < 0) {
            return false;
        }
        return availableStock != null && availableStock <= threshold;
    }

    /**
     * 获取库存状态描述
     *
     * @return 库存状态描述
     */
    public String getStockStatusDescription() {
        if (isOutOfStock()) {
            return "缺货";
        } else if (isLowStock(10)) {
            return "库存紧张";
        } else {
            return "库存充足";
        }
    }
}