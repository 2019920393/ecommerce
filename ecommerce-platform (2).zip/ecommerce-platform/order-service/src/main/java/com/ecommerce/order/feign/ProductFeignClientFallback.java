package com.ecommerce.order.feign;

import com.ecommerce.common.result.Result;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.openfeign.FallbackFactory;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * 商品服务Feign降级处理
 * 
 * @author ecommerce-team
 * @since 1.0.0
 */
@Slf4j
@Component
public class ProductFeignClientFallback implements FallbackFactory<ProductFeignClient> {

    @Override
    public ProductFeignClient create(Throwable cause) {
        log.error("商品服务调用失败: {}", cause.getMessage());
        
        return new ProductFeignClient() {
            @Override
            public Result<Map<String, Object>> getProduct(Long productId) {
                log.error("获取商品详情降级: productId={}", productId);
                return Result.error("商品服务暂不可用");
            }

            @Override
            public Result<List<Map<String, Object>>> batchGetProducts(List<Long> productIds) {
                log.error("批量获取商品降级: productIds={}", productIds);
                return Result.error("商品服务暂不可用");
            }

            @Override
            public Result<Boolean> checkStock(Long productId, Integer quantity) {
                log.error("检查库存降级: productId={}, quantity={}", productId, quantity);
                return Result.error("商品服务暂不可用");
            }

            @Override
            public Result<List<Map<String, Object>>> getCartItemsByIds(Long userId, List<Long> itemIds) {
                log.error("获取购物车项降级: userId={}, itemIds={}", userId, itemIds);
                return Result.error("商品服务暂不可用");
            }

            @Override
            public Result<Void> clearCartItems(Long userId, List<Long> itemIds) {
                log.error("清空购物车降级: userId={}, itemIds={}", userId, itemIds);
                return Result.error("商品服务暂不可用");
            }
        };
    }
}
