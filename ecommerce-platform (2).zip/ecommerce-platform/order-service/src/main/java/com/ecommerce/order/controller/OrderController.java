package com.ecommerce.order.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ecommerce.common.enums.OrderStatus;
import com.ecommerce.common.result.Result;
import com.ecommerce.order.dto.CreateOrderRequest;
import com.ecommerce.order.dto.CreateOrderRspVO;
import com.ecommerce.order.dto.OrderDetailRspVO;
import com.ecommerce.order.dto.OrderItemRspVO;
import com.ecommerce.order.dto.ShippingAddressRspVO;
import com.ecommerce.order.domain.entity.Order;
import com.ecommerce.order.domain.entity.OrderItem;
import com.ecommerce.order.service.OrderService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

/**
 * 订单控制器
 * 
 * <p>处理订单相关的HTTP请求</p>
 * 
 * <p>设计依据：</p>
 * <ul>
 *   <li>15.接口设计文档.md - 4.1.1 OrderController（表示层接口）</li>
 *   <li>6.2.1类的属性和操作定义.md - OrderService定义</li>
 * </ul>
 * 
 * <p>RESTful API设计规范：</p>
 * <ul>
 *   <li>基础路径：/api/v1/orders</li>
 *   <li>使用统一响应格式：Result&lt;T&gt;</li>
 *   <li>参数验证：使用@Valid注解</li>
 *   <li>异常处理：由GlobalExceptionHandler统一处理</li>
 * </ul>
 * 
 * @author Kiro
 * @since 2025-11-21
 */
@Slf4j
@RestController
@RequestMapping("/api/v1/orders")
@Tag(name = "订单管理", description = "订单的创建、查询、取消等操作接口")
public class OrderController {

    @Autowired
    private OrderService orderService;

    /**
     * 创建订单
     * 
     * <p>UC9创建订单的核心接口</p>
     * 
     * <p>业务流程：</p>
     * <ol>
     *   <li>校验请求参数</li>
     *   <li>校验库存是否充足</li>
     *   <li>生成订单号</li>
     *   <li>创建订单和订单明细</li>
     *   <li>预扣库存（乐观锁）</li>
     *   <li>返回订单创建结果</li>
     * </ol>
     * 
     * @param request 创建订单请求
     * @return 订单创建结果
     */
    @Operation(summary = "创建订单", description = "根据购物车商品和收货地址创建新订单，自动校验库存并预扣库存")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "订单创建成功"),
        @ApiResponse(responseCode = "400", description = "请求参数错误"),
        @ApiResponse(responseCode = "500", description = "库存不足或系统错误")
    })
    @PostMapping("")
    public Result<CreateOrderRspVO> createOrder(
            @Parameter(description = "创建订单请求体", required = true)
            @RequestBody @Valid CreateOrderRequest request) {
        log.info("接收创建订单请求, userId={}, itemCount={}", 
                 request.getUserId(), request.getItems().size());

        // 将请求中的订单明细转换为实体对象
        List<OrderItem> orderItems = request.getItems().stream()
            .map(item -> {
                OrderItem orderItem = new OrderItem();
                orderItem.setProductId(item.getProductId());
                orderItem.setProductName(item.getProductName());
                orderItem.setProductImage(item.getProductImage());
                orderItem.setSpecification(item.getSpecification());
                orderItem.setUnitPrice(item.getUnitPrice());
                orderItem.setQuantity(item.getQuantity());
                return orderItem;
            })
            .collect(Collectors.toList());

        // 构建完整收货地址
        String shippingAddress = (request.getProvince() != null ? request.getProvince() : "") +
                                 (request.getCity() != null ? request.getCity() : "") +
                                 (request.getDistrict() != null ? request.getDistrict() : "") +
                                 (request.getDetailAddress() != null ? request.getDetailAddress() : "");

        // 调用Service层创建订单
        Order order = orderService.createOrder(
            request.getUserId(),
            orderItems,
            request.getRecipientName(),
            request.getRecipientPhone(),
            shippingAddress,
            request.getProvince(),
            request.getCity(),
            request.getDistrict(),
            request.getDetailAddress(),
            request.getRemark()
        );

        // 构建响应DTO
        CreateOrderRspVO response = CreateOrderRspVO.builder()
            .orderNumber(order.getOrderNumber())
            .totalAmount(order.getTotalAmount())
            .createTime(order.getCreateTime())
            .expireTime(order.getExpireTime())
            .status(order.getStatus())
            .build();

        log.info("订单创建成功, orderNumber={}, totalAmount={}", 
                 order.getOrderNumber(), order.getTotalAmount());

        return Result.success(response);
    }

    /**
     * 查询订单详情
     * 
     * <p>根据订单号查询订单的完整信息</p>
     * 
     * @param orderNumber 订单号
     * @return 订单详情
     */
    @Operation(summary = "查询订单详情", description = "根据订单号查询订单的完整信息，包括订单明细和收货地址")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "查询成功"),
        @ApiResponse(responseCode = "404", description = "订单不存在")
    })
    @GetMapping("/{orderNumber}")
    public Result<OrderDetailRspVO> getOrderDetail(
            @Parameter(description = "订单号", required = true, example = "ORD20251130123456")
            @PathVariable(name = "orderNumber") String orderNumber) {
        log.info("查询订单详情, orderNumber={}", orderNumber);

        // 调用Service层查询订单
        Order order = orderService.getOrderDetail(orderNumber);

        // 构建收货地址DTO
        ShippingAddressRspVO shippingAddress = ShippingAddressRspVO.builder()
            .recipientName(order.getRecipientName())
            .recipientPhone(order.getRecipientPhone())
            .province(order.getProvince())
            .city(order.getCity())
            .district(order.getDistrict())
            .detailAddress(order.getDetailAddress())
            .fullAddress(order.getShippingAddress())
            .build();

        // 构建订单明细DTO列表
        List<OrderItemRspVO> items = order.getItems().stream()
            .map(this::convertToOrderItemRspVO)
            .collect(Collectors.toList());

        // 构建响应DTO
        OrderDetailRspVO response = OrderDetailRspVO.builder()
            .orderNumber(order.getOrderNumber())
            .userId(order.getUserId())
            .totalAmount(order.getTotalAmount())
            .productAmount(order.getProductAmount())
            .shippingFee(order.getShippingFee())
            .discount(order.getDiscount())
            .status(order.getStatus())
            .statusDescription(OrderStatus.valueOf(order.getStatus()).getDescription())
            .createTime(order.getCreateTime())
            .payTime(order.getPayTime())
            .expireTime(order.getExpireTime())
            .cancelTime(order.getCancelTime())
            .remark(order.getRemark())
            .shippingAddress(shippingAddress)
            .items(items)
            .isPaid(order.isPaid())
            .isExpired(order.isExpired())
            .canCancel(order.canCancel())
            .build();

        log.info("订单详情查询成功, orderNumber={}, status={}", 
                 orderNumber, order.getStatus());

        return Result.success(response);
    }

    /**
     * 取消订单
     * 
     * <p>用户主动取消订单</p>
     * 
     * <p>业务流程：</p>
     * <ol>
     *   <li>校验订单状态（只有待支付状态可以取消）</li>
     *   <li>更新订单状态为CANCELLED</li>
     *   <li>释放预扣库存</li>
     * </ol>
     * 
     * @param orderNumber 订单号
     * @return 取消结果
     */
    @Operation(summary = "取消订单", description = "用户主动取消订单，仅待支付状态的订单可取消，取消后自动释放预扣库存")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "取消成功"),
        @ApiResponse(responseCode = "400", description = "订单状态不允许取消"),
        @ApiResponse(responseCode = "404", description = "订单不存在")
    })
    @PutMapping("/{orderNumber}/cancel")
    public Result<Void> cancelOrder(
            @Parameter(description = "订单号", required = true, example = "ORD20251130123456")
            @PathVariable(name = "orderNumber") String orderNumber) {
        log.info("接收取消订单请求, orderNumber={}", orderNumber);

        // 调用Service层取消订单
        orderService.cancelOrder(orderNumber);

        log.info("订单取消成功, orderNumber={}", orderNumber);

        return Result.success();
    }

    /**
     * 查询所有订单列表（管理员接口）
     */
    @Operation(summary = "查询所有订单列表", description = "管理员分页查询所有订单，支持按状态筛选")
    @GetMapping("/list")
    public Result<Page<OrderDetailRspVO>> queryAllOrders(
            @Parameter(description = "订单状态筛选") @RequestParam(name = "status", required = false) String status,
            @Parameter(description = "页码") @RequestParam(name = "page", defaultValue = "1") Integer page,
            @Parameter(description = "每页数量") @RequestParam(name = "size", defaultValue = "10") Integer size) {
        
        log.info("查询所有订单列表, status={}, page={}, size={}", status, page, size);
        Page<Order> orderPage = orderService.queryAllOrders(status, page, size);
        
        Page<OrderDetailRspVO> result = new Page<>(page, size);
        result.setTotal(orderPage.getTotal());
        result.setRecords(orderPage.getRecords().stream().map(this::convertToOrderDetailRspVO).collect(Collectors.toList()));
        return Result.success(result);
    }

    /**
     * 查询用户订单列表
     * 
     * <p>分页查询用户的订单列表，支持按状态筛选</p>
     * 
     * @param userId 用户ID
     * @param status 订单状态（可选）
     * @param pageNum 页码，默认1
     * @param pageSize 每页大小，默认10
     * @return 订单列表
     */
    @Operation(summary = "查询用户订单列表", description = "分页查询指定用户的订单列表，支持按订单状态筛选")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "查询成功")
    })
    @GetMapping("/user/{userId}")
    public Result<List<OrderDetailRspVO>> queryUserOrders(
            @Parameter(description = "用户ID", required = true, example = "1001")
            @PathVariable(name = "userId") Long userId,
            @Parameter(description = "订单状态筛选：PENDING_PAYMENT/PENDING_SHIPMENT/SHIPPED/COMPLETED/CANCELLED")
            @RequestParam(required = false) String status,
            @Parameter(description = "页码，从1开始", example = "1")
            @RequestParam(defaultValue = "1") Integer pageNum,
            @Parameter(description = "每页记录数", example = "10")
            @RequestParam(defaultValue = "10") Integer pageSize) {
        
        log.info("查询用户订单列表, userId={}, status={}, pageNum={}, pageSize={}",
                 userId, status, pageNum, pageSize);

        // 调用Service层查询订单列表（返回分页对象）
        Page<Order> page = orderService.queryUserOrders(userId, status, pageNum, pageSize);

        // 转换为DTO列表
        List<OrderDetailRspVO> responses = page.getRecords().stream()
            .map(this::convertToOrderDetailRspVO)
            .collect(Collectors.toList());

        log.info("用户订单列表查询成功, userId={}, count={}, total={}",
                 userId, responses.size(), page.getTotal());

        return Result.success(responses);
    }

    /**
     * 更新订单状态
     * 
     * <p>内部接口，用于支付成功后更新订单状态</p>
     * 
     * @param orderNumber 订单号
     * @param status 新状态
     * @return 更新结果
     */
    @Operation(summary = "更新订单状态", description = "内部接口，用于支付成功后更新订单状态为已支付等")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "更新成功"),
        @ApiResponse(responseCode = "400", description = "状态转换不合法"),
        @ApiResponse(responseCode = "404", description = "订单不存在")
    })
    @PutMapping("/{orderNumber}/status")
    public Result<Void> updateOrderStatus(
            @Parameter(description = "订单号", required = true, example = "ORD20251130123456")
            @PathVariable(name = "orderNumber") String orderNumber,
            @Parameter(description = "新状态：PENDING_PAYMENT/PENDING_SHIPMENT/SHIPPED/COMPLETED/CANCELLED", required = true)
            @RequestParam(name = "status") String status) {
        
        log.info("更新订单状态: orderNumber={}, status={}", orderNumber, status);

        // 转换状态枚举
        OrderStatus orderStatus = OrderStatus.valueOf(status);

        // 调用Service层更新状态
        orderService.updateOrderStatus(orderNumber, orderStatus);

        log.info("订单状态更新成功: orderNumber={}, newStatus={}", orderNumber, status);

        return Result.success();
    }

    /**
     * 将Order实体转换为OrderDetailResponse DTO
     * 
     * @param order 订单实体
     * @return 订单详情DTO
     */
    private OrderDetailRspVO convertToOrderDetailRspVO(Order order) {
        // 构建收货地址DTO
        ShippingAddressRspVO shippingAddress = ShippingAddressRspVO.builder()
            .recipientName(order.getRecipientName())
            .recipientPhone(order.getRecipientPhone())
            .province(order.getProvince())
            .city(order.getCity())
            .district(order.getDistrict())
            .detailAddress(order.getDetailAddress())
            .fullAddress(order.getShippingAddress())
            .build();

        // 构建订单明细DTO列表
        List<OrderItemRspVO> items = order.getItems() != null 
            ? order.getItems().stream()
                .map(this::convertToOrderItemRspVO)
                .collect(Collectors.toList())
            : null;

        // 构建响应DTO
        return OrderDetailRspVO.builder()
            .orderNumber(order.getOrderNumber())
            .userId(order.getUserId())
            .totalAmount(order.getTotalAmount())
            .productAmount(order.getProductAmount())
            .shippingFee(order.getShippingFee())
            .discount(order.getDiscount())
            .status(order.getStatus())
            .statusDescription(OrderStatus.valueOf(order.getStatus()).getDescription())
            .createTime(order.getCreateTime())
            .payTime(order.getPayTime())
            .expireTime(order.getExpireTime())
            .cancelTime(order.getCancelTime())
            .remark(order.getRemark())
            .shippingAddress(shippingAddress)
            .items(items)
            .isPaid(order.isPaid())
            .isExpired(order.isExpired())
            .canCancel(order.canCancel())
            .build();
    }

    /**
     * 将OrderItem实体转换为OrderItemDTO
     * 
     * @param item 订单明细实体
     * @return 订单明细DTO
     */
    private OrderItemRspVO convertToOrderItemRspVO(OrderItem item) {
        return OrderItemRspVO.builder()
            .itemId(item.getItemId())
            .orderId(item.getOrderId())
            .orderNumber(item.getOrderNumber())
            .productId(item.getProductId())
            .productName(item.getProductName())
            .productImage(item.getProductImage())
            .specification(item.getSpecification())
            .unitPrice(item.getUnitPrice())
            .quantity(item.getQuantity())
            .subtotal(item.getSubtotal())
            .build();
    }
}
