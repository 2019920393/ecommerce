package com.ecommerce.order.task;

import com.ecommerce.order.service.OrderService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * 订单超时定时任务
 * 
 * <p>每分钟检查超时未支付的订单，自动取消并释放库存</p>
 * 
 * @author ecommerce-platform
 * @since 1.0.0
 */
@Slf4j
@Component
public class OrderTimeoutTask {

    @Autowired
    private OrderService orderService;

    /**
     * 检查超时订单
     * 每分钟执行一次
     */
    @Scheduled(fixedRate = 60000)
    public void checkTimeoutOrders() {
        log.info("=== 定时任务：检查超时订单 ===");
        try {
            orderService.checkTimeout();
        } catch (Exception e) {
            log.error("检查超时订单任务执行失败", e);
        }
    }
}
