package com.ecommerce.order.domain.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

/**
 * 订单实体类
 * <p>
 * 对应数据库表：orders
 * 存储订单的基本信息，包括收货地址、金额、状态等
 * </p>
 *
 * @author ecommerce-platform
 * @since 1.0.0
 */
@Data
@TableName("orders")
public class Order implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 订单ID，主键，自增
     */
    @TableId(value = "order_id", type = IdType.AUTO)
    private Long orderId;

    /**
     * 订单号，业务主键
     * 格式：ORD + yyyyMMdd + 6位序列号
     * 例如：ORD20240115000001
     */
    @TableField("order_number")
    private String orderNumber;

    /**
     * 用户ID
     */
    @TableField("user_id")
    private Long userId;

    // ==================== 收货信息 ====================

    /**
     * 收货人姓名
     */
    @TableField("recipient_name")
    private String recipientName;

    /**
     * 收货人电话
     */
    @TableField("recipient_phone")
    private String recipientPhone;

    /**
     * 完整收货地址（用于显示）
     */
    @TableField("shipping_address")
    private String shippingAddress;

    /**
     * 省
     */
    @TableField("province")
    private String province;

    /**
     * 市
     */
    @TableField("city")
    private String city;

    /**
     * 区
     */
    @TableField("district")
    private String district;

    /**
     * 详细地址
     */
    @TableField("detail_address")
    private String detailAddress;

    // ==================== 金额信息 ====================

    /**
     * 订单总金额
     * 计算公式：total_amount = product_amount + shipping_fee - discount
     */
    @TableField("total_amount")
    private BigDecimal totalAmount;

    /**
     * 商品总价（所有订单明细的小计之和）
     */
    @TableField("product_amount")
    private BigDecimal productAmount;

    /**
     * 运费
     * 默认0.00，满99元免运费
     */
    @TableField("shipping_fee")
    private BigDecimal shippingFee;

    /**
     * 优惠金额
     * 默认0.00
     */
    @TableField("discount")
    private BigDecimal discount;

    // ==================== 状态和时间 ====================

    /**
     * 订单状态
     * 可选值：
     * - PENDING_PAYMENT：待支付
     * - PENDING_SHIPMENT：待发货
     * - SHIPPED：已发货
     * - COMPLETED：已完成
     * - CANCELLED：已取消
     */
    @TableField("status")
    private String status;

    /**
     * 创建时间
     * 自动填充
     */
    @TableField(value = "create_time", fill = FieldFill.INSERT)
    private LocalDateTime createTime;

    /**
     * 支付时间
     * 支付成功后更新
     */
    @TableField("pay_time")
    private LocalDateTime payTime;

    /**
     * 超时时间
     * 创建订单时设置为：创建时间 + 30分钟
     * 超过此时间未支付，订单自动取消
     */
    @TableField("expire_time")
    private LocalDateTime expireTime;

    /**
     * 取消时间
     * 订单取消时更新
     */
    @TableField("cancel_time")
    private LocalDateTime cancelTime;

    // ==================== 其他 ====================

    /**
     * 订单备注
     * 用户下单时填写，最大500字符
     */
    @TableField("remark")
    private String remark;

    /**
     * 更新时间
     * 自动填充
     */
    @TableField(value = "update_time", fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;

    /**
     * 逻辑删除标记
     * 0-未删除，1-已删除
     * 使用@TableLogic注解实现逻辑删除
     */
    @TableLogic
    @TableField("is_deleted")
    private Integer isDeleted;

    // ==================== 非数据库字段 ====================

    /**
     * 订单明细列表
     * 非数据库字段，用于关联查询
     */
    @TableField(exist = false)
    private List<OrderItem> items;

    // ==================== 业务方法 ====================

    /**
     * 判断订单是否已过期
     *
     * @return true-已过期，false-未过期
     */
    public boolean isExpired() {
        return expireTime != null && LocalDateTime.now().isAfter(expireTime);
    }

    /**
     * 判断订单是否可以取消
     * 只有待支付状态的订单可以取消
     *
     * @return true-可以取消，false-不可以取消
     */
    public boolean canCancel() {
        return "PENDING_PAYMENT".equals(status);
    }

    /**
     * 判断订单是否可以支付
     * 只有待支付状态且未过期的订单可以支付
     *
     * @return true-可以支付，false-不可以支付
     */
    public boolean canPay() {
        return "PENDING_PAYMENT".equals(status) && !isExpired();
    }

    /**
     * 判断订单是否已支付
     *
     * @return true-已支付，false-未支付
     */
    public boolean isPaid() {
        return payTime != null && !"PENDING_PAYMENT".equals(status) && !"CANCELLED".equals(status);
    }

    /**
     * 计算订单总金额
     * 公式：总金额 = 商品总价 + 运费 - 优惠金额
     *
     * @return 订单总金额
     */
    public BigDecimal calculateTotalAmount() {
        BigDecimal total = productAmount != null ? productAmount : BigDecimal.ZERO;
        total = total.add(shippingFee != null ? shippingFee : BigDecimal.ZERO);
        total = total.subtract(discount != null ? discount : BigDecimal.ZERO);
        return total;
    }

    /**
     * 设置订单超时时间
     * 默认为创建时间 + 30分钟
     */
    public void setExpireTimeFromCreateTime() {
        if (createTime != null) {
            this.expireTime = createTime.plusMinutes(com.ecommerce.common.constant.Constants.ORDER_TIMEOUT_MINUTES);
        }
    }
}