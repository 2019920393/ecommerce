package com.ecommerce.order;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * 订单服务启动类
 * 
 * <p>云原生微服务电商平台 - 订单服务</p>
 * 
 * @author Kilo Code
 * @since 2025-11-21
 */
@SpringBootApplication
@ComponentScan(basePackages = {"com.ecommerce"})
@EnableScheduling
@EnableDiscoveryClient
@EnableFeignClients(basePackages = "com.ecommerce.order.feign")
@org.mybatis.spring.annotation.MapperScan("com.ecommerce.order.mapper")
public class OrderServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(OrderServiceApplication.class, args);
    }
}
