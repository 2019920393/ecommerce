package com.ecommerce.order.feign;

import com.ecommerce.common.result.Result;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.openfeign.FallbackFactory;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * 用户服务Feign降级处理
 * 
 * @author ecommerce-team
 * @since 1.0.0
 */
@Slf4j
@Component
public class UserFeignClientFallback implements FallbackFactory<UserFeignClient> {

    @Override
    public UserFeignClient create(Throwable cause) {
        log.error("用户服务调用失败: {}", cause.getMessage());
        
        return new UserFeignClient() {
            @Override
            public Result<Map<String, Object>> getUser(Long userId) {
                log.error("获取用户信息降级: userId={}", userId);
                return Result.error("用户服务暂不可用");
            }

            @Override
            public Result<Map<String, Object>> getAddress(Long addressId) {
                log.error("获取地址详情降级: addressId={}", addressId);
                return Result.error("用户服务暂不可用");
            }

            @Override
            public Result<Map<String, Object>> getDefaultAddress(Long userId) {
                log.error("获取默认地址降级: userId={}", userId);
                return Result.error("用户服务暂不可用");
            }
        };
    }
}
