package com.ecommerce.order.message;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * 支付失败消息
 * 对应文档：15.接口设计文档.md - 3.6.2 支付失败消息
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PaymentFailedMessage implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 支付流水号
     */
    private String paymentNumber;

    /**
     * 订单号
     */
    private String orderNumber;

    /**
     * 用户ID
     */
    private Long userId;

    /**
     * 支付金额
     */
    private BigDecimal amount;

    /**
     * 支付方式
     */
    private String paymentMethod;

    /**
     * 支付状态
     */
    private String status;

    /**
     * 失败原因
     */
    private String failReason;

    /**
     * 消息时间戳
     */
    private Long timestamp;
}
