package com.ecommerce.order.message;

import com.ecommerce.common.enums.OrderStatus;
import com.ecommerce.order.config.RabbitMQConfig;
import com.ecommerce.order.service.OrderService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

import java.util.concurrent.TimeUnit;

/**
 * 支付消息消费者
 * 对应文档：15.接口设计文档.md - 3.6 消息队列接口
 * 对应文档：11.体系结构决策描述文档.md - 决策8：UC10支付成功后采用消息队列实现最终一致性
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class PaymentMessageConsumer {

    private final OrderService orderService;
    private final StringRedisTemplate redisTemplate;

    // Redis幂等键前缀
    private static final String IDEMPOTENT_KEY_PREFIX = "payment:processed:";
    // 幂等键过期时间（24小时）
    private static final long IDEMPOTENT_EXPIRE_HOURS = 24;

    /**
     * 处理支付成功消息
     * 
     * <p>对应文档：11.体系结构决策描述文档.md - 订单服务：使用paymentNumber作为幂等键，Redis记录已处理的消息</p>
     * 
     * @param message 支付成功消息
     */
    @RabbitListener(queues = RabbitMQConfig.PAYMENT_SUCCESS_QUEUE)
    public void handlePaymentSuccess(PaymentSuccessMessage message) {
        log.info("收到支付成功消息: paymentNumber={}, orderNumber={}", 
                message.getPaymentNumber(), message.getOrderNumber());

        // 幂等校验：使用paymentNumber作为幂等键
        String idempotentKey = IDEMPOTENT_KEY_PREFIX + message.getPaymentNumber();
        Boolean isNew = redisTemplate.opsForValue().setIfAbsent(
                idempotentKey, 
                "processed", 
                IDEMPOTENT_EXPIRE_HOURS, 
                TimeUnit.HOURS
        );

        if (Boolean.FALSE.equals(isNew)) {
            log.warn("重复消息，跳过处理: paymentNumber={}", message.getPaymentNumber());
            return;
        }

        try {
            // 更新订单状态为待发货
            orderService.updateOrderStatus(message.getOrderNumber(), OrderStatus.PENDING_SHIPMENT);
            log.info("订单状态更新成功（MQ消费）: orderNumber={}, newStatus=PENDING_SHIPMENT", 
                    message.getOrderNumber());

        } catch (Exception e) {
            log.error("处理支付成功消息失败: paymentNumber={}, orderNumber={}", 
                    message.getPaymentNumber(), message.getOrderNumber(), e);
            // 删除幂等键，允许重试
            redisTemplate.delete(idempotentKey);
            throw e; // 抛出异常，触发消息重试
        }
    }

    /**
     * 处理支付失败消息
     * 
     * @param message 支付失败消息
     */
    @RabbitListener(queues = RabbitMQConfig.PAYMENT_FAILED_QUEUE)
    public void handlePaymentFailed(PaymentFailedMessage message) {
        log.info("收到支付失败消息: paymentNumber={}, orderNumber={}, reason={}", 
                message.getPaymentNumber(), message.getOrderNumber(), message.getFailReason());

        // 幂等校验
        String idempotentKey = IDEMPOTENT_KEY_PREFIX + "failed:" + message.getPaymentNumber();
        Boolean isNew = redisTemplate.opsForValue().setIfAbsent(
                idempotentKey, 
                "processed", 
                IDEMPOTENT_EXPIRE_HOURS, 
                TimeUnit.HOURS
        );

        if (Boolean.FALSE.equals(isNew)) {
            log.warn("重复的失败消息，跳过处理: paymentNumber={}", message.getPaymentNumber());
            return;
        }

        try {
            // 释放预扣库存
            orderService.releaseInventoryByOrderNumber(message.getOrderNumber());
            log.info("库存释放成功（支付失败）: orderNumber={}", message.getOrderNumber());

        } catch (Exception e) {
            log.error("处理支付失败消息异常: paymentNumber={}, orderNumber={}", 
                    message.getPaymentNumber(), message.getOrderNumber(), e);
            // 删除幂等键，允许重试
            redisTemplate.delete(idempotentKey);
            throw e;
        }
    }
}
