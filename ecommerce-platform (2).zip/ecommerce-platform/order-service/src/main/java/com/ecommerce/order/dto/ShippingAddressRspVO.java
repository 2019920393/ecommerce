package com.ecommerce.order.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 收货地址DTO
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "收货地址信息")
public class ShippingAddressRspVO {

    @Schema(description = "收货人姓名", example = "张三")
    private String recipientName;

    @Schema(description = "收货人电话", example = "13800138000")
    private String recipientPhone;

    @Schema(description = "省", example = "广东省")
    private String province;

    @Schema(description = "市", example = "深圳市")
    private String city;

    @Schema(description = "区/县", example = "南山区")
    private String district;

    @Schema(description = "详细地址", example = "科技园南路88号")
    private String detailAddress;

    @Schema(description = "完整地址", example = "广东省深圳市南山区科技园南路88号")
    private String fullAddress;

    public String getFullAddress() {
        if (fullAddress != null) {
            return fullAddress;
        }
        return province + city + district + detailAddress;
    }
}