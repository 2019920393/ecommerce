package com.ecommerce.order.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ecommerce.order.domain.entity.Order;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 订单Mapper接口
 * <p>
 * 继承MyBatis-Plus的BaseMapper接口，提供基本的CRUD操作
 * 自定义方法使用@Select、@Update等注解实现
 * </p>
 * 
 * <p>
 * BaseMapper提供的方法：
 * - insert(Order order) - 插入订单
 * - selectById(Long id) - 根据ID查询
 * - updateById(Order order) - 根据ID更新
 * - deleteById(Long id) - 根据ID删除（逻辑删除）
 * - selectList(Wrapper) - 条件查询列表
 * - selectPage(IPage, Wrapper) - 分页查询
 * </p>
 *
 * @author ecommerce-platform
 * @since 1.0.0
 */
@Mapper
public interface OrderMapper extends BaseMapper<Order> {

    /**
     * 根据订单号查询订单
     * <p>
     * 订单号是业务主键，查询频率高，使用唯一索引uk_order_number
     * </p>
     *
     * @param orderNumber 订单号
     * @return 订单对象，不存在返回null
     */
    @Select("SELECT * FROM orders WHERE order_number = #{orderNumber} AND is_deleted = 0")
    Order findByOrderNumber(@Param("orderNumber") String orderNumber);

    /**
     * 根据用户ID查询订单列表
     * <p>
     * 按创建时间倒序排列，最新的订单在前面
     * 使用索引idx_user_id
     * </p>
     *
     * @param userId 用户ID
     * @return 订单列表
     */
    @Select("SELECT * FROM orders WHERE user_id = #{userId} AND is_deleted = 0 ORDER BY create_time DESC")
    List<Order> findByUserId(@Param("userId") Long userId);

    /**
     * 根据用户ID和订单状态查询订单列表
     * <p>
     * 用于用户查看特定状态的订单（如待支付、待发货等）
     * 使用复合索引idx_user_id和idx_status
     * </p>
     *
     * @param userId 用户ID
     * @param status 订单状态
     * @return 订单列表
     */
    @Select("SELECT * FROM orders WHERE user_id = #{userId} AND status = #{status} AND is_deleted = 0 ORDER BY create_time DESC")
    List<Order> findByUserIdAndStatus(@Param("userId") Long userId, @Param("status") String status);

    /**
     * 分页查询用户订单
     * <p>
     * 支持按状态筛选（可选）
     * </p>
     *
     * @param page   分页参数
     * @param userId 用户ID
     * @param status 订单状态（可选，为null时查询所有状态）
     * @return 分页结果
     */
    @Select("<script>" +
            "SELECT * FROM orders " +
            "WHERE user_id = #{userId} AND is_deleted = 0 " +
            "<if test=\"status != null and status != ''\">" +
            "AND status = #{status} " +
            "</if>" +
            "ORDER BY create_time DESC" +
            "</script>")
    Page<Order> findByUserIdWithPage(IPage<Order> page, @Param("userId") Long userId, @Param("status") String status);

    /**
     * 分页查询所有订单（管理员接口）
     */
    @Select("<script>" +
            "SELECT * FROM orders WHERE is_deleted = 0 " +
            "<if test=\"status != null and status != ''\">" +
            "AND status = #{status} " +
            "</if>" +
            "ORDER BY create_time DESC" +
            "</script>")
    Page<Order> findAllWithPage(IPage<Order> page, @Param("status") String status);

    /**
     * 查询超时未支付的订单
     * <p>
     * 定时任务使用，查询状态为PENDING_PAYMENT且已过期的订单
     * 使用索引idx_status和idx_expire_time
     * </p>
     *
     * @return 超时订单列表
     */
    @Select("SELECT * FROM orders WHERE status = 'PENDING_PAYMENT' AND expire_time < NOW() AND is_deleted = 0")
    List<Order> findExpiredOrders();

    /**
     * 查询指定时间范围内的订单
     * <p>
     * 用于统计分析和报表
     * 使用索引idx_create_time
     * </p>
     *
     * @param startTime 开始时间
     * @param endTime   结束时间
     * @return 订单列表
     */
    @Select("SELECT * FROM orders WHERE create_time >= #{startTime} AND create_time < #{endTime} AND is_deleted = 0 ORDER BY create_time DESC")
    List<Order> findByCreateTimeRange(@Param("startTime") LocalDateTime startTime, @Param("endTime") LocalDateTime endTime);

    /**
     * 查询指定时间范围内指定状态的订单
     * <p>
     * 用于统计分析，如查询某天的已完成订单
     * </p>
     *
     * @param startTime 开始时间
     * @param endTime   结束时间
     * @param status    订单状态
     * @return 订单列表
     */
    @Select("SELECT * FROM orders WHERE create_time >= #{startTime} AND create_time < #{endTime} AND status = #{status} AND is_deleted = 0 ORDER BY create_time DESC")
    List<Order> findByCreateTimeRangeAndStatus(
            @Param("startTime") LocalDateTime startTime,
            @Param("endTime") LocalDateTime endTime,
            @Param("status") String status
    );

    /**
     * 更新订单状态
     * <p>
     * 只更新状态字段，不影响其他字段
     * </p>
     *
     * @param orderNumber 订单号
     * @param newStatus   新状态
     * @return 影响的行数
     */
    @Update("UPDATE orders SET status = #{newStatus}, update_time = NOW() WHERE order_number = #{orderNumber} AND is_deleted = 0")
    int updateStatus(@Param("orderNumber") String orderNumber, @Param("newStatus") String newStatus);

    /**
     * 更新订单支付时间和状态
     * <p>
     * 支付成功时调用，同时更新支付时间和订单状态
     * </p>
     *
     * @param orderNumber 订单号
     * @param payTime     支付时间
     * @param newStatus   新状态（通常为PENDING_SHIPMENT）
     * @return 影响的行数
     */
    @Update("UPDATE orders SET pay_time = #{payTime}, status = #{newStatus}, update_time = NOW() WHERE order_number = #{orderNumber} AND is_deleted = 0")
    int updatePayTimeAndStatus(
            @Param("orderNumber") String orderNumber,
            @Param("payTime") LocalDateTime payTime,
            @Param("newStatus") String newStatus
    );

    /**
     * 取消订单
     * <p>
     * 更新订单状态为CANCELLED，并记录取消时间
     * </p>
     *
     * @param orderNumber 订单号
     * @param cancelTime  取消时间
     * @return 影响的行数
     */
    @Update("UPDATE orders SET status = 'CANCELLED', cancel_time = #{cancelTime}, update_time = NOW() WHERE order_number = #{orderNumber} AND is_deleted = 0")
    int cancelOrder(@Param("orderNumber") String orderNumber, @Param("cancelTime") LocalDateTime cancelTime);

    /**
     * 统计用户订单数量
     * <p>
     * 可选按状态统计
     * </p>
     *
     * @param userId 用户ID
     * @param status 订单状态（可选）
     * @return 订单数量
     */
    @Select("<script>" +
            "SELECT COUNT(*) FROM orders " +
            "WHERE user_id = #{userId} AND is_deleted = 0 " +
            "<if test=\"status != null and status != ''\">" +
            "AND status = #{status} " +
            "</if>" +
            "</script>")
    int countByUserId(@Param("userId") Long userId, @Param("status") String status);

    /**
     * 统计指定时间范围内的订单数量
     * <p>
     * 用于统计分析
     * </p>
     *
     * @param startTime 开始时间
     * @param endTime   结束时间
     * @return 订单数量
     */
    @Select("SELECT COUNT(*) FROM orders WHERE create_time >= #{startTime} AND create_time < #{endTime} AND is_deleted = 0")
    int countByCreateTimeRange(@Param("startTime") LocalDateTime startTime, @Param("endTime") LocalDateTime endTime);

    /**
     * 检查订单号是否存在
     * <p>
     * 用于验证订单号的唯一性
     * </p>
     *
     * @param orderNumber 订单号
     * @return true-存在，false-不存在
     */
    @Select("SELECT COUNT(*) > 0 FROM orders WHERE order_number = #{orderNumber} AND is_deleted = 0")
    boolean existsByOrderNumber(@Param("orderNumber") String orderNumber);
}