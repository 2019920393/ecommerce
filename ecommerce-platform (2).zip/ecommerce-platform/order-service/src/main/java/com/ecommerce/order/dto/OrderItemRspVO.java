package com.ecommerce.order.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

/**
 * 订单明细DTO
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "订单明细信息")
public class OrderItemRspVO {

    @Schema(description = "明细ID", example = "1")
    private Long itemId;

    @Schema(description = "订单ID", example = "100")
    private Long orderId;

    @Schema(description = "订单号", example = "ORD20251130000001")
    private String orderNumber;

    @Schema(description = "商品ID", example = "1001")
    private Long productId;

    @Schema(description = "商品名称", example = "iPhone 15 Pro")
    private String productName;

    @Schema(description = "商品图片URL", example = "https://example.com/image.jpg")
    private String productImage;

    @Schema(description = "商品规格", example = "黑色/256GB")
    private String specification;

    @Schema(description = "单价", example = "7999.00")
    private BigDecimal unitPrice;

    @Schema(description = "购买数量", example = "1")
    private Integer quantity;

    @Schema(description = "小计金额", example = "7999.00")
    private BigDecimal subtotal;
}