package com.ecommerce.order.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * OpenAPI (Swagger 3.0) 配置类
 * 
 * <p>配置 API 文档信息</p>
 * 
 * @author Kilo Code
 * @since 2025-11-21
 */
@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI customOpenAPI() {
        return new OpenAPI()
            .info(new Info()
                .title("订单服务 API")
                .version("1.0.0")
                .description("云原生微服务电商平台 - 订单服务 API 文档\n\n" +
                    "主要功能：\n" +
                    "- 创建订单 (UC9)\n" +
                    "- 查询订单详情\n" +
                    "- 查询用户订单列表\n" +
                    "- 取消订单\n" +
                    "- 更新订单状态")
                .contact(new Contact()
                    .name("开发团队")
                    .email("dev@ecommerce.com"))
                .license(new License()
                    .name("Apache 2.0")
                    .url("https://www.apache.org/licenses/LICENSE-2.0.html")));
    }
}
