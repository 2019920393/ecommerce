package com.ecommerce.order.feign;

import com.ecommerce.common.result.Result;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.Map;

/**
 * 用户服务Feign客户端
 * 
 * <p>用于订单服务调用用户服务</p>
 * 
 * @author ecommerce-team
 * @since 1.0.0
 */
@FeignClient(name = "user-service", fallbackFactory = UserFeignClientFallback.class)
public interface UserFeignClient {

    /**
     * 获取用户信息
     */
    @GetMapping("/api/v1/users/{userId}")
    Result<Map<String, Object>> getUser(@PathVariable("userId") Long userId);

    /**
     * 获取收货地址详情
     */
    @GetMapping("/api/v1/addresses/{addressId}")
    Result<Map<String, Object>> getAddress(@PathVariable("addressId") Long addressId);

    /**
     * 获取用户默认地址
     */
    @GetMapping("/api/v1/addresses/user/{userId}/default")
    Result<Map<String, Object>> getDefaultAddress(@PathVariable("userId") Long userId);
}
