package com.ecommerce.order.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 创建订单响应DTO
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "创建订单响应")
public class CreateOrderRspVO {

    @Schema(description = "订单号", example = "ORD20251130000001")
    private String orderNumber;

    @Schema(description = "订单总金额", example = "7999.00")
    private BigDecimal totalAmount;

    @Schema(description = "创建时间", example = "2025-11-30 12:00:00")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private LocalDateTime createTime;

    @Schema(description = "过期时间（创建后30分钟）", example = "2025-11-30 12:30:00")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private LocalDateTime expireTime;

    @Schema(description = "订单状态", example = "PENDING_PAYMENT")
    private String status;
}