package com.ecommerce.order.feign;

import com.ecommerce.common.result.Result;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * 商品服务Feign客户端
 * 
 * <p>用于订单服务调用商品服务</p>
 * 
 * @author ecommerce-team
 * @since 1.0.0
 */
@FeignClient(name = "product-service", fallbackFactory = ProductFeignClientFallback.class)
public interface ProductFeignClient {

    /**
     * 获取商品详情
     */
    @GetMapping("/api/v1/products/{productId}")
    Result<Map<String, Object>> getProduct(@PathVariable("productId") Long productId);

    /**
     * 批量获取商品信息
     */
    @PostMapping("/api/v1/products/batch")
    Result<List<Map<String, Object>>> batchGetProducts(@RequestBody List<Long> productIds);

    /**
     * 检查库存是否充足
     */
    @GetMapping("/api/v1/products/{productId}/stock/check")
    Result<Boolean> checkStock(@PathVariable("productId") Long productId, 
                               @RequestParam("quantity") Integer quantity);

    /**
     * 根据ID列表查询购物车项
     */
    @GetMapping("/api/v1/cart/{userId}/items")
    Result<List<Map<String, Object>>> getCartItemsByIds(@PathVariable("userId") Long userId,
                                                        @RequestParam("itemIds") List<Long> itemIds);

    /**
     * 清空购物车中已下单的商品
     */
    @DeleteMapping("/api/v1/cart/{userId}/items")
    Result<Void> clearCartItems(@PathVariable("userId") Long userId,
                                @RequestParam("itemIds") List<Long> itemIds);
}
