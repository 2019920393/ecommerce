# 订单服务启动指南

## 前置条件

1. **Java 17+** - 已安装
2. **Maven 3.8+** - 已安装
3. **MySQL 8.0+** - 已启动，默认地址 `localhost:3306`
4. **Redis 7.0+** - 已启动，默认地址 `localhost:6379`（可选）

## 数据库初始化

在启动服务前，需要初始化数据库：

```bash
# 创建订单数据库
mysql -u root -p < ../sql/order_db_init.sql
```

## 修改配置

编辑 `src/main/resources/application.yml`，根据实际环境修改：

```yaml
spring:
  datasource:
    url: jdbc:mysql://localhost:3306/order_db?useUnicode=true&characterEncoding=utf-8&useSSL=false&serverTimezone=Asia/Shanghai
    username: root
    password: root
```

## 启动服务

### 方式一：使用 Maven 启动

```bash
# 进入订单服务目录
cd order-service

# 编译并启动
mvn spring-boot:run
```

### 方式二：使用 IDE 启动

1. 在 IDE 中打开项目
2. 找到 `OrderServiceApplication` 类
3. 右键选择 "Run" 或 "Debug"

### 方式三：打包后启动

```bash
# 编译打包
mvn clean package

# 启动 JAR
java -jar target/order-service.jar
```

## 验证启动

启动成功后，会看到类似输出：

```
2025-11-21 10:30:45 - Started OrderServiceApplication in 5.123 seconds
```

## 访问 Swagger 文档

启动成功后，访问以下地址查看 API 文档：

```
http://localhost:8083/swagger-ui.html
```

或者访问 OpenAPI JSON：

```
http://localhost:8083/v3/api-docs
```

## 常见问题

### 1. 数据库连接失败

**错误信息**：`Connection refused`

**解决方案**：
- 检查 MySQL 是否启动
- 检查数据库地址和端口是否正确
- 检查用户名和密码是否正确

### 2. 端口被占用

**错误信息**：`Address already in use`

**解决方案**：
- 修改 `application.yml` 中的 `server.port`
- 或者关闭占用该端口的其他应用

### 3. 缺少依赖

**错误信息**：`Cannot find symbol`

**解决方案**：
```bash
# 清理并重新编译
mvn clean compile
```

## 调试 API

### 使用 Swagger UI

1. 打开 http://localhost:8083/swagger-ui.html
2. 找到 `OrderController` 下的接口
3. 点击 "Try it out" 按钮
4. 填写参数并点击 "Execute"

### 使用 curl 命令

```bash
# 创建订单
curl -X POST http://localhost:8083/api/v1/orders \
  -H "Content-Type: application/json" \
  -d '{
    "userId": 1,
    "cartItemIds": [1, 2],
    "addressId": 1,
    "remark": "请尽快发货"
  }'

# 查询订单详情
curl -X GET http://localhost:8083/api/v1/orders/ORD20251121000001

# 查询用户订单列表
curl -X GET "http://localhost:8083/api/v1/orders/user/1?pageNum=1&pageSize=10"

# 取消订单
curl -X PUT http://localhost:8083/api/v1/orders/ORD20251121000001/cancel
```

### 使用 Postman

1. 导入 Swagger 文档：`http://localhost:8083/v3/api-docs`
2. 在 Postman 中创建请求
3. 设置请求方法、URL 和参数
4. 点击 "Send" 发送请求

## 日志查看

日志文件位置：`logs/order-service.log`

查看实时日志：

```bash
tail -f logs/order-service.log
```

## 停止服务

按 `Ctrl + C` 停止服务

## 更多信息

- 项目文档：参见根目录的 `*.md` 文件
- API 文档：启动后访问 Swagger UI
- 源代码：`src/main/java/com/ecommerce/order/`
