# CI/CD流水线使用指南

## 概述

本项目支持三种CI/CD方案：

1. **Gitee Go**（推荐）- Gitee官方CI/CD，国内访问快
2. **GitHub Actions** - GitHub官方CI/CD
3. **Jenkins** - 功能强大，需要自行部署

## Gitee Go方案（推荐）

### 优势

✅ 国内访问速度快  
✅ 无需部署服务器  
✅ 与Gitee无缝集成  
✅ 支持阿里云镜像仓库  
✅ 中文界面友好  

### 配置文件位置

```
.gitee/pipelines/pipeline.yml
```

### 配置步骤

#### 第1步：开通Gitee Go

1. 进入Gitee仓库
2. 点击"流水线" → "开通Gitee Go"
3. 选择免费版或付费版

#### 第2步：配置Secrets

在Gitee仓库设置中添加以下变量：

**阿里云镜像仓库凭证**：
- `ALIYUN_DOCKER_USERNAME` - 阿里云镜像仓库用户名
- `ALIYUN_DOCKER_PASSWORD` - 阿里云镜像仓库密码

**开发环境凭证**：
- `DEV_HOST` - 开发服务器IP
- `DEV_USER` - SSH用户名
- `DEV_SSH_KEY` - SSH私钥

**生产环境凭证**：
- `PROD_HOST` - 生产服务器IP
- `PROD_USER` - SSH用户名
- `PROD_SSH_KEY` - SSH私钥

#### 第3步：创建阿里云镜像仓库

1. 登录阿里云容器镜像服务
2. 创建命名空间：`ecommerce`
3. 创建镜像仓库：
   - order-service
   - user-service
   - product-service
   - payment-service
   - gateway-service

#### 第4步：触发流水线

- Push代码到`develop`分支 → 部署到开发环境
- Push代码到`main`分支 → 部署到生产环境

### 流水线流程

```
代码提交到Gitee
    ↓
Gitee Go自动触发
    ↓
编译构建 → 单元测试 → 打包
    ↓
并行构建5个Docker镜像
    ↓
推送到阿里云镜像仓库
    ↓
SSH部署到服务器
    ↓
✅ 部署完成
```

---

## GitHub Actions方案

### 优势

✅ 无需部署服务器  
✅ 免费且功能完整  
✅ 与GitHub无缝集成  
✅ 自动触发，无需手动操作  
✅ 支持多环境部署  

### 工作流程

```
代码提交到GitHub
    ↓
GitHub Actions自动触发
    ↓
┌─────────────────────────────────────┐
│ Job 1: 编译和测试                    │
│ - 检出代码                          │
│ - 设置Java环境                      │
│ - 编译项目                          │
│ - 运行单元测试                      │
│ - 打包项目                          │
└─────────────────────────────────────┘
    ↓
┌─────────────────────────────────────┐
│ Job 2: 构建Docker镜像                │
│ - 并行构建5个服务镜像                │
│ - 推送到Docker仓库                  │
└─────────────────────────────────────┘
    ↓
┌─────────────────────────────────────┐
│ Job 3: 部署到开发环境（develop分支）  │
│ - SSH连接到开发服务器                │
│ - 执行部署脚本                      │
└─────────────────────────────────────┘
    ↓
┌─────────────────────────────────────┐
│ Job 4: 部署到生产环境（main分支）    │
│ - SSH连接到生产服务器                │
│ - 执行部署脚本                      │
└─────────────────────────────────────┘
    ↓
✅ 流水线完成
```

### 配置步骤

#### 第1步：配置GitHub Secrets

在GitHub仓库设置中添加以下Secrets：

**Docker仓库凭证**：
- `DOCKER_USERNAME` - Docker Hub用户名
- `DOCKER_PASSWORD` - Docker Hub密码或Token

**开发环境凭证**：
- `DEV_HOST` - 开发服务器IP或域名
- `DEV_USER` - SSH用户名
- `DEV_SSH_KEY` - SSH私钥

**生产环境凭证**：
- `PROD_HOST` - 生产服务器IP或域名
- `PROD_USER` - SSH用户名
- `PROD_SSH_KEY` - SSH私钥

**可选**：
- `SLACK_WEBHOOK` - Slack通知Webhook

#### 第2步：配置分支保护规则

在GitHub仓库设置中配置分支保护：

1. 进入 Settings → Branches
2. 添加分支保护规则：
   - `main` 分支：要求CI/CD通过后才能合并
   - `develop` 分支：要求CI/CD通过后才能合并

#### 第3步：配置部署服务器

在开发和生产服务器上：

```bash
# 1. 创建部署目录
mkdir -p /opt/ecommerce-platform
cd /opt/ecommerce-platform

# 2. 克隆项目
git clone https://github.com/your-username/ecommerce-platform.git .

# 3. 给部署脚本执行权限
chmod +x deploy.sh

# 4. 安装Docker和Docker Compose
# 参考Docker官方文档

# 5. 配置环境变量
cat > .env << EOF
MYSQL_ROOT_PASSWORD=your-secure-password
JWT_SECRET=your-jwt-secret
DOCKER_REGISTRY=docker.io
DOCKER_NAMESPACE=ecommerce
EOF
```

### 触发流水线

#### 自动触发

流水线在以下情况自动触发：

1. **Push到develop分支** → 部署到开发环境
2. **Push到main分支** → 部署到生产环境
3. **创建Pull Request** → 运行编译和测试

#### 手动触发

在GitHub Actions页面点击"Run workflow"手动触发

### 监控流水线

1. 进入GitHub仓库 → Actions标签
2. 查看流水线执行状态
3. 点击具体流水线查看详细日志

### 故障排查

#### 问题1：Docker镜像推送失败

**原因**：Docker凭证错误

**解决**：
1. 检查`DOCKER_USERNAME`和`DOCKER_PASSWORD`是否正确
2. 确保Docker Hub账户有推送权限
3. 如果使用Token，确保Token未过期

#### 问题2：部署失败

**原因**：SSH连接失败或部署脚本错误

**解决**：
1. 检查`DEV_HOST`/`PROD_HOST`是否正确
2. 检查SSH密钥是否正确
3. 确保部署服务器已安装Docker和Docker Compose
4. 查看部署脚本日志

#### 问题3：单元测试失败

**原因**：代码问题

**解决**：
1. 查看GitHub Actions日志中的测试失败信息
2. 本地运行`mvn test`重现问题
3. 修复代码后重新提交

---

## Jenkins方案

### 优势

✅ 功能最强大  
✅ 支持复杂的流水线逻辑  
✅ 可自定义程度高  
✅ 支持分布式构建  

### 劣势

❌ 需要部署Jenkins服务器  
❌ 需要维护和管理  
❌ 学习曲线陡峭  

### 部署Jenkins

#### 使用Docker部署

```bash
# 1. 创建Jenkins数据目录
mkdir -p /opt/jenkins_home
chmod 777 /opt/jenkins_home

# 2. 启动Jenkins容器
docker run -d \
  --name jenkins \
  -p 8888:8080 \
  -p 50000:50000 \
  -v /opt/jenkins_home:/var/jenkins_home \
  -v /var/run/docker.sock:/var/run/docker.sock \
  jenkins/jenkins:lts

# 3. 查看初始密码
docker logs jenkins | grep "Please use the following password"

# 4. 访问Jenkins
# http://localhost:8888
```

#### 配置Jenkins

1. **安装插件**：
   - Pipeline
   - Git
   - Docker
   - Email Extension

2. **配置凭证**：
   - GitHub凭证
   - Docker凭证
   - SSH凭证

3. **创建流水线任务**：
   - 选择"Pipeline"类型
   - 配置Git仓库
   - 选择"Pipeline script from SCM"
   - 指定Jenkinsfile路径

### 使用Jenkinsfile

项目根目录的`Jenkinsfile`定义了完整的流水线：

```groovy
pipeline {
    agent any
    
    stages {
        stage('准备') { ... }
        stage('编译') { ... }
        stage('单元测试') { ... }
        stage('打包') { ... }
        stage('构建镜像') { ... }
        stage('推送镜像') { ... }
        stage('部署') { ... }
        stage('验证') { ... }
    }
}
```

---

## 对比总结

| 特性 | GitHub Actions | Jenkins |
|------|----------------|---------|
| 部署难度 | ⭐ 简单 | ⭐⭐⭐ 复杂 |
| 功能完整性 | ⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ |
| 成本 | 免费 | 需要服务器 |
| 学习曲线 | ⭐ 平缓 | ⭐⭐⭐ 陡峭 |
| 集成度 | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ |
| 推荐指数 | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ |

---

## 最佳实践

### 1. 分支策略

```
main分支（生产）
  ↑
  ├─ 只接受来自release分支的PR
  ├─ 需要CI/CD通过
  └─ 需要代码审查

develop分支（开发）
  ↑
  ├─ 接受来自feature分支的PR
  ├─ 需要CI/CD通过
  └─ 自动部署到开发环境

feature分支（功能开发）
  ├─ feature/user-auth
  ├─ feature/payment-integration
  └─ feature/order-management
```

### 2. 提交规范

```
feat: 新功能
fix: 修复bug
docs: 文档更新
style: 代码风格
refactor: 代码重构
test: 测试相关
chore: 构建/依赖更新
```

### 3. 版本管理

使用Git标签标记版本：

```bash
# 创建版本标签
git tag -a v1.0.0 -m "Release version 1.0.0"

# 推送标签
git push origin v1.0.0
```

---

## 常见问题

### Q: 如何跳过CI/CD流水线？

A: 在提交信息中添加`[skip ci]`：

```bash
git commit -m "Update README [skip ci]"
```

### Q: 如何手动触发流水线？

A: 在GitHub Actions页面点击"Run workflow"

### Q: 如何查看流水线日志？

A: 进入GitHub Actions → 选择流水线 → 查看详细日志

### Q: 如何修改流水线配置？

A: 编辑`.github/workflows/ci-cd.yml`文件并提交

---

## 总结

✅ **推荐使用GitHub Actions**：
- 无需部署
- 开箱即用
- 功能完整
- 适合大多数项目

⏳ **如需更强大的功能**：
- 可选择部署Jenkins
- 支持更复杂的流水线逻辑
- 支持分布式构建
