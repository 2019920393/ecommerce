# 云原生电商平台前端

基于 Vue3 + Element Plus + Vite 构建的电商平台前端。

## 技术栈

- Vue 3.4
- Vue Router 4
- Pinia（状态管理）
- Element Plus（UI组件库）
- Axios（HTTP请求）
- Vite（构建工具）

## 页面功能

| 页面 | 路由 | 功能 |
|-----|------|------|
| 首页 | / | 商品推荐展示 |
| 商品列表 | /products | 分类筛选、搜索 |
| 商品详情 | /product/:id | 查看详情、加入购物车 |
| 购物车 | /cart | 管理购物车商品 |
| 订单确认 | /checkout | 选择地址、提交订单 |
| 支付 | /payment/:orderNumber | 模拟支付 |
| 我的订单 | /orders | 查看订单列表 |
| 个人中心 | /profile | 个人信息、地址管理 |
| 登录 | /login | 用户登录 |
| 注册 | /register | 用户注册 |

## 快速开始

```bash
# 安装依赖
npm install

# 启动开发服务器
npm run dev

# 构建生产版本
npm run build
```

## 接口代理

开发环境下，`/api` 请求会代理到 `http://localhost:8080`（Gateway网关）。

## 目录结构

```
src/
├── api/          # API接口
├── layouts/      # 布局组件
├── router/       # 路由配置
├── stores/       # Pinia状态管理
└── views/        # 页面组件
```
