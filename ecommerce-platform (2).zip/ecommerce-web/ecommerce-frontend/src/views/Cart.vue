<template>
  <div class="cart-page">
    <h1 class="page-title">Shopping Cart</h1>

    <div class="cart-content" v-if="cartItems.length">
      <!-- 购物车列表 -->
      <div class="cart-items">
        <div v-for="item in cartItems" :key="item.cartItemId" class="cart-item">
          <img :src="item.productImage || `https://picsum.photos/100/100?random=${item.productId}`" class="item-image" @click="goDetail(item.productId)" />
          <div class="item-info">
            <h3 class="item-name" @click="goDetail(item.productId)">{{ item.productName }}</h3>
            <p class="item-sku">{{ item.skuInfo || 'Default' }}</p>
          </div>
          <div class="item-price">${{ item.price }}</div>
          <div class="item-quantity">
            <el-input-number v-model="item.quantity" :min="1" :max="99" size="small" @change="(val) => updateQuantity(item, val)" />
          </div>
          <div class="item-total">${{ (item.price * item.quantity).toFixed(2) }}</div>
          <button class="item-remove" @click="removeItem(item)">
            <el-icon><Close /></el-icon>
          </button>
        </div>
      </div>

      <!-- 订单摘要 -->
      <div class="cart-summary">
        <h2>Order Summary</h2>
        <div class="summary-row">
          <span>Subtotal ({{ totalCount }} items)</span>
          <span>${{ totalPrice.toFixed(2) }}</span>
        </div>
        <div class="summary-row">
          <span>Shipping</span>
          <span>FREE</span>
        </div>
        <div class="summary-row total">
          <span>Total</span>
          <span>${{ totalPrice.toFixed(2) }}</span>
        </div>
        <button class="checkout-btn" @click="goCheckout">CHECKOUT</button>
      </div>
    </div>

    <!-- 空购物车 -->
    <div class="cart-empty" v-else>
      <el-empty description="Your cart is empty">
        <button class="shop-btn" @click="$router.push('/')">START SHOPPING</button>
      </el-empty>
    </div>
  </div>
</template>

<script setup>
import { computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { useCartStore } from '@/stores/cart'
import { ElMessage, ElMessageBox } from 'element-plus'

const router = useRouter()
const cartStore = useCartStore()

const cartItems = computed(() => cartStore.cartItems)
const totalCount = computed(() => cartStore.totalCount)
const totalPrice = computed(() => cartStore.totalPrice)

const goDetail = (id) => router.push(`/product/${id}`)

const updateQuantity = async (item, quantity) => {
  await cartStore.updateQuantity(item.cartItemId, quantity)
}

const removeItem = async (item) => {
  await ElMessageBox.confirm('Remove this item?', 'Confirm', { type: 'warning' })
  await cartStore.removeFromCart(item.cartItemId)
  ElMessage.success('Item removed')
}

const goCheckout = () => {
  router.push('/checkout')
}

onMounted(() => {
  cartStore.fetchCart()
})
</script>

<style scoped>
.cart-page {
  max-width: 1200px;
  margin: 0 auto;
  padding: 32px 24px;
  min-height: 60vh;
}

.page-title {
  font-size: 28px;
  font-weight: 400;
  color: #333;
  margin: 0 0 32px;
}

.cart-content {
  display: grid;
  grid-template-columns: 1fr 320px;
  gap: 32px;
}

.cart-items {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.cart-item {
  display: grid;
  grid-template-columns: 80px 1fr 100px 120px 100px 40px;
  align-items: center;
  gap: 16px;
  padding: 16px;
  background: #fff;
  border: 1px solid #eee;
}

.item-image {
  width: 80px;
  height: 80px;
  object-fit: cover;
  cursor: pointer;
}

.item-info {
  min-width: 0;
}

.item-name {
  font-size: 14px;
  font-weight: 500;
  color: #333;
  margin: 0 0 4px;
  cursor: pointer;
  text-transform: uppercase;
}

.item-name:hover {
  color: #E91E63;
}

.item-sku {
  font-size: 12px;
  color: #999;
  margin: 0;
}

.item-price, .item-total {
  font-size: 14px;
  color: #333;
  text-align: center;
}

.item-total {
  font-weight: 500;
  color: #E91E63;
}

.item-remove {
  background: none;
  border: none;
  cursor: pointer;
  color: #999;
  padding: 8px;
  transition: color 0.2s;
}

.item-remove:hover {
  color: #E91E63;
}

.cart-summary {
  background: #f9f9f9;
  padding: 24px;
  height: fit-content;
  position: sticky;
  top: 80px;
}

.cart-summary h2 {
  font-size: 18px;
  font-weight: 500;
  margin: 0 0 24px;
  color: #333;
}

.summary-row {
  display: flex;
  justify-content: space-between;
  font-size: 14px;
  color: #666;
  margin-bottom: 12px;
}

.summary-row.total {
  font-size: 18px;
  font-weight: 500;
  color: #333;
  padding-top: 16px;
  border-top: 1px solid #ddd;
  margin-top: 16px;
}

.checkout-btn {
  width: 100%;
  padding: 14px;
  background: #E91E63;
  color: #fff;
  border: none;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  margin-top: 24px;
  transition: background 0.2s;
}

.checkout-btn:hover {
  background: #c2185b;
}

.cart-empty {
  padding: 80px 0;
}

.shop-btn {
  padding: 14px 32px;
  background: #E91E63;
  color: #fff;
  border: none;
  font-size: 14px;
  cursor: pointer;
}

@media (max-width: 900px) {
  .cart-content {
    grid-template-columns: 1fr;
  }
  .cart-item {
    grid-template-columns: 60px 1fr auto;
    grid-template-rows: auto auto;
  }
  .item-price, .item-quantity, .item-total {
    grid-column: 2 / -1;
    text-align: left;
    justify-self: start;
  }
}
</style>
