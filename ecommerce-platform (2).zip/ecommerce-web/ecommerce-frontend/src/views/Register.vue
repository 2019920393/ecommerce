<template>
  <div class="register-page">
    <div class="register-card">
      <h1 class="register-title">Create Account</h1>
      
      <el-form ref="formRef" :model="form" :rules="rules" label-position="top">
        <el-form-item label="Username" prop="username">
          <el-input v-model="form.username" placeholder="Choose a username" size="large" />
        </el-form-item>
        <el-form-item label="Phone" prop="phone">
          <el-input v-model="form.phone" placeholder="Enter your phone number" size="large" />
        </el-form-item>
        <el-form-item label="Password" prop="password">
          <el-input v-model="form.password" type="password" placeholder="Create a password" size="large" show-password />
        </el-form-item>
        <el-form-item label="Confirm Password" prop="confirmPassword">
          <el-input v-model="form.confirmPassword" type="password" placeholder="Confirm your password" size="large" show-password />
        </el-form-item>
        <el-form-item>
          <button type="button" class="register-btn" :disabled="loading" @click="handleRegister">
            {{ loading ? 'Creating...' : 'CREATE ACCOUNT' }}
          </button>
        </el-form-item>
      </el-form>

      <div class="register-footer">
        <span>Already have an account?</span>
        <router-link to="/login">Login</router-link>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive } from 'vue'
import { useRouter } from 'vue-router'
import { userApi } from '@/api'
import { ElMessage } from 'element-plus'

const router = useRouter()

const formRef = ref(null)
const loading = ref(false)

const form = reactive({
  username: '',
  phone: '',
  password: '',
  confirmPassword: ''
})

const validatePass = (rule, value, callback) => {
  if (value !== form.password) callback(new Error('Passwords do not match'))
  else callback()
}

const rules = {
  username: [{ required: true, message: 'Username is required', trigger: 'blur' }],
  phone: [{ required: true, message: 'Phone is required', trigger: 'blur' }],
  password: [{ required: true, message: 'Password is required', trigger: 'blur' }, { min: 6, message: 'At least 6 characters', trigger: 'blur' }],
  confirmPassword: [{ required: true, message: 'Please confirm password', trigger: 'blur' }, { validator: validatePass, trigger: 'blur' }]
}

const handleRegister = async () => {
  const valid = await formRef.value?.validate().catch(() => false)
  if (!valid) return

  loading.value = true
  try {
    await userApi.register({ username: form.username, password: form.password, phone: form.phone })
    ElMessage.success('Registration successful')
    router.push('/login')
  } catch (error) {
    ElMessage.error(error.message || 'Registration failed')
  } finally {
    loading.value = false
  }
}
</script>

<style scoped>
.register-page {
  min-height: calc(100vh - 56px);
  display: flex;
  align-items: center;
  justify-content: center;
  background: #f5f5f5;
  padding: 24px;
}

.register-card {
  width: 400px;
  max-width: 100%;
  background: #fff;
  padding: 48px 40px;
  box-shadow: 0 2px 12px rgba(0,0,0,0.1);
}

.register-title {
  font-size: 24px;
  font-weight: 400;
  color: #333;
  margin: 0 0 32px;
  text-align: center;
}

.register-btn {
  width: 100%;
  padding: 14px;
  background: #E91E63;
  color: #fff;
  border: none;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  transition: background 0.2s;
}

.register-btn:hover {
  background: #c2185b;
}

.register-btn:disabled {
  background: #ccc;
  cursor: not-allowed;
}

.register-footer {
  text-align: center;
  margin-top: 24px;
  font-size: 14px;
  color: #666;
}

.register-footer a {
  color: #E91E63;
  text-decoration: none;
  margin-left: 8px;
}
</style>
