<template>
  <div class="payment-page">
    <div class="payment-card" v-if="!paymentSuccess">
      <h1 class="page-title">Complete Payment</h1>

      <div class="order-info">
        <p>Order #{{ orderNumber }}</p>
        <div class="amount">${{ amount }}</div>
      </div>

      <div class="payment-methods">
        <h3>Select Payment Method</h3>
        <div class="methods-list">
          <div class="method-item" :class="{ active: method === 'card' }" @click="method = 'card'">
            <el-icon><CreditCard /></el-icon>
            <span>Credit Card</span>
          </div>
          <div class="method-item" :class="{ active: method === 'paypal' }" @click="method = 'paypal'">
            <el-icon><Wallet /></el-icon>
            <span>PayPal</span>
          </div>
        </div>
      </div>

      <button class="pay-btn" :disabled="paying" @click="handlePay">
        {{ paying ? 'Processing...' : `PAY $${amount}` }}
      </button>
    </div>

    <!-- 支付成功 -->
    <div class="success-card" v-else>
      <el-icon :size="64" color="#4caf50"><CircleCheck /></el-icon>
      <h2>Payment Successful!</h2>
      <p>Thank you for your purchase.</p>
      <div class="success-actions">
        <button class="action-btn" @click="$router.push('/orders')">View Orders</button>
        <button class="action-btn primary" @click="$router.push('/')">Continue Shopping</button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useUserStore } from '@/stores/user'
import { orderApi, paymentApi } from '@/api'
import { ElMessage } from 'element-plus'

const route = useRoute()
const router = useRouter()
const userStore = useUserStore()

const orderNumber = ref('')
const amount = ref('0.00')
const method = ref('card')
const paying = ref(false)
const paymentSuccess = ref(false)
const paymentNumber = ref('')

const fetchOrder = async () => {
  orderNumber.value = route.query.orderNumber
  if (!orderNumber.value) {
    ElMessage.warning('Invalid order')
    return router.push('/orders')
  }
  try {
    const res = await orderApi.detail(orderNumber.value)
    amount.value = res.data?.totalAmount || '0.00'
  } catch (e) {
    ElMessage.error('Failed to load order')
  }
}

const handlePay = async () => {
  paying.value = true
  try {
    // 1. 创建支付订单
    const paymentData = {
      orderNumber: orderNumber.value,
      userId: userStore.userId,
      paymentMethod: method.value === 'card' ? 'MOCK' : 'MOCK'
    }
    const createRes = await paymentApi.create(paymentData, amount.value)
    paymentNumber.value = createRes.data?.paymentNumber
    
    if (paymentNumber.value) {
      // 2. 模拟支付延迟
      await new Promise(resolve => setTimeout(resolve, 1000))
      
      // 3. 执行支付
      await paymentApi.pay(paymentNumber.value)
    }
    
    paymentSuccess.value = true
  } catch (e) {
    ElMessage.error('Payment failed')
  } finally {
    paying.value = false
  }
}

onMounted(fetchOrder)
</script>

<style scoped>
.payment-page {
  min-height: calc(100vh - 56px);
  display: flex;
  align-items: center;
  justify-content: center;
  background: #f5f5f5;
  padding: 24px;
}

.payment-card, .success-card {
  width: 450px;
  max-width: 100%;
  background: #fff;
  padding: 48px 40px;
  text-align: center;
  box-shadow: 0 2px 12px rgba(0,0,0,0.1);
}

.page-title {
  font-size: 24px;
  font-weight: 400;
  color: #333;
  margin: 0 0 32px;
}

.order-info {
  margin-bottom: 32px;
}

.order-info p {
  font-size: 14px;
  color: #999;
  margin: 0 0 8px;
}

.amount {
  font-size: 40px;
  font-weight: 500;
  color: #E91E63;
}

.payment-methods h3 {
  font-size: 14px;
  font-weight: 500;
  color: #333;
  margin: 0 0 16px;
}

.methods-list {
  display: flex;
  gap: 16px;
  margin-bottom: 32px;
}

.method-item {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
  padding: 20px;
  border: 2px solid #eee;
  cursor: pointer;
  transition: all 0.2s;
}

.method-item:hover {
  border-color: #ccc;
}

.method-item.active {
  border-color: #E91E63;
  color: #E91E63;
}

.method-item span {
  font-size: 13px;
}

.pay-btn {
  width: 100%;
  padding: 16px;
  background: #E91E63;
  color: #fff;
  border: none;
  font-size: 16px;
  font-weight: 500;
  cursor: pointer;
  transition: background 0.2s;
}

.pay-btn:hover {
  background: #c2185b;
}

.pay-btn:disabled {
  background: #ccc;
}

.success-card h2 {
  font-size: 24px;
  font-weight: 400;
  color: #333;
  margin: 24px 0 8px;
}

.success-card p {
  font-size: 14px;
  color: #666;
  margin: 0 0 32px;
}

.success-actions {
  display: flex;
  gap: 16px;
}

.action-btn {
  flex: 1;
  padding: 12px;
  border: 1px solid #ddd;
  background: #fff;
  font-size: 14px;
  cursor: pointer;
  transition: all 0.2s;
}

.action-btn:hover {
  border-color: #E91E63;
  color: #E91E63;
}

.action-btn.primary {
  background: #E91E63;
  border-color: #E91E63;
  color: #fff;
}

.action-btn.primary:hover {
  background: #c2185b;
}
</style>
