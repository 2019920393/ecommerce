<template>
  <div class="checkout-page">
    <h1 class="page-title">Checkout</h1>

    <div class="checkout-content" v-loading="loading">
      <div class="checkout-form">
        <!-- 配送地址 -->
        <section class="section">
          <h2>Shipping Address</h2>
          <el-form label-position="top">
            <div class="form-row">
              <el-form-item label="Full Name">
                <el-input v-model="address.name" placeholder="Enter your name" />
              </el-form-item>
              <el-form-item label="Phone">
                <el-input v-model="address.phone" placeholder="Enter phone number" />
              </el-form-item>
            </div>
            <el-form-item label="Address">
              <el-input v-model="address.detail" placeholder="Street address" />
            </el-form-item>
            <div class="form-row">
              <el-form-item label="City">
                <el-input v-model="address.city" placeholder="City" />
              </el-form-item>
              <el-form-item label="Postal Code">
                <el-input v-model="address.postalCode" placeholder="Postal code" />
              </el-form-item>
            </div>
          </el-form>
        </section>

        <!-- 订单备注 -->
        <section class="section">
          <h2>Order Notes</h2>
          <el-input v-model="remark" type="textarea" :rows="3" placeholder="Special instructions (optional)" />
        </section>
      </div>

      <!-- 订单摘要 -->
      <div class="order-summary">
        <h2>Order Summary</h2>
        <div class="summary-items">
          <div v-for="item in cartItems" :key="item.cartItemId" class="summary-item">
            <img :src="item.productImage || `https://picsum.photos/60/60?random=${item.productId}`" />
            <div class="item-info">
              <span class="item-name">{{ item.productName }}</span>
              <span class="item-qty">Qty: {{ item.quantity }}</span>
            </div>
            <span class="item-price">${{ (item.price * item.quantity).toFixed(2) }}</span>
          </div>
        </div>
        <div class="summary-totals">
          <div class="total-row"><span>Subtotal</span><span>${{ totalPrice.toFixed(2) }}</span></div>
          <div class="total-row"><span>Shipping</span><span>FREE</span></div>
          <div class="total-row final"><span>Total</span><span>${{ totalPrice.toFixed(2) }}</span></div>
        </div>
        <button class="place-order-btn" :disabled="submitting" @click="placeOrder">
          {{ submitting ? 'Processing...' : 'PLACE ORDER' }}
        </button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { useCartStore } from '@/stores/cart'
import { useUserStore } from '@/stores/user'
import { orderApi } from '@/api'
import { ElMessage } from 'element-plus'

const router = useRouter()
const cartStore = useCartStore()
const userStore = useUserStore()

const loading = ref(false)
const submitting = ref(false)
const remark = ref('')

const address = reactive({
  name: '',
  phone: '',
  detail: '',
  city: '',
  postalCode: ''
})

const cartItems = computed(() => cartStore.cartItems)
const totalPrice = computed(() => cartStore.totalPrice)

const placeOrder = async () => {
  if (!userStore.isLoggedIn) {
    ElMessage.warning('Please login first')
    return router.push('/login')
  }
  if (!address.name || !address.phone || !address.detail) {
    return ElMessage.warning('Please fill in shipping address')
  }
  if (!cartItems.value.length) {
    return ElMessage.warning('Your cart is empty')
  }

  submitting.value = true
  try {
    const orderData = {
      userId: userStore.userId,
      recipientName: address.name,
      recipientPhone: address.phone,
      province: '',
      city: address.city,
      district: '',
      detailAddress: address.detail,
      remark: remark.value,
      items: cartItems.value.map(item => ({
        productId: item.productId,
        productName: item.productName,
        productImage: item.productImage,
        specification: item.specification || '',
        unitPrice: item.price,
        quantity: item.quantity
      }))
    }
    const res = await orderApi.create(orderData)
    const orderNumber = res.data?.orderNumber
    ElMessage.success('Order placed successfully')
    await cartStore.clearCart()
    router.push({ path: '/payment', query: { orderNumber } })
  } catch (error) {
    ElMessage.error(error.message || 'Failed to place order')
  } finally {
    submitting.value = false
  }
}

onMounted(() => {
  if (!userStore.isLoggedIn) {
    ElMessage.warning('Please login first')
    router.push('/login')
    return
  }
  if (!cartItems.value.length) {
    cartStore.fetchCart()
  }
})
</script>

<style scoped>
.checkout-page {
  max-width: 1200px;
  margin: 0 auto;
  padding: 32px 24px;
}

.page-title {
  font-size: 28px;
  font-weight: 400;
  color: #333;
  margin: 0 0 32px;
}

.checkout-content {
  display: grid;
  grid-template-columns: 1fr 380px;
  gap: 32px;
}

.section {
  background: #fff;
  padding: 24px;
  margin-bottom: 24px;
  border: 1px solid #eee;
}

.section h2 {
  font-size: 18px;
  font-weight: 500;
  color: #333;
  margin: 0 0 20px;
}

.form-row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 16px;
}

.order-summary {
  background: #f9f9f9;
  padding: 24px;
  height: fit-content;
  position: sticky;
  top: 80px;
}

.order-summary h2 {
  font-size: 18px;
  font-weight: 500;
  margin: 0 0 20px;
}

.summary-items {
  max-height: 300px;
  overflow-y: auto;
  margin-bottom: 20px;
}

.summary-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 12px 0;
  border-bottom: 1px solid #eee;
}

.summary-item img {
  width: 50px;
  height: 50px;
  object-fit: cover;
}

.summary-item .item-info {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.item-name {
  font-size: 13px;
  color: #333;
}

.item-qty {
  font-size: 12px;
  color: #999;
}

.item-price {
  font-size: 14px;
  color: #333;
}

.summary-totals {
  padding-top: 16px;
}

.total-row {
  display: flex;
  justify-content: space-between;
  font-size: 14px;
  color: #666;
  margin-bottom: 8px;
}

.total-row.final {
  font-size: 18px;
  font-weight: 500;
  color: #333;
  padding-top: 12px;
  border-top: 1px solid #ddd;
  margin-top: 12px;
}

.place-order-btn {
  width: 100%;
  padding: 14px;
  background: #E91E63;
  color: #fff;
  border: none;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  margin-top: 20px;
  transition: background 0.2s;
}

.place-order-btn:hover {
  background: #c2185b;
}

.place-order-btn:disabled {
  background: #ccc;
}

@media (max-width: 900px) {
  .checkout-content {
    grid-template-columns: 1fr;
  }
  .form-row {
    grid-template-columns: 1fr;
  }
}
</style>
