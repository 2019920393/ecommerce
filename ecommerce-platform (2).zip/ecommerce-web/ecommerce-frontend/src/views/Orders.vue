<template>
  <div class="orders-page">
    <h1 class="page-title">My Orders</h1>

    <div class="orders-list" v-loading="loading">
      <div v-for="order in orders" :key="order.orderId" class="order-card">
        <div class="order-header">
          <div class="order-info">
            <span class="order-no">Order #{{ order.orderNumber }}</span>
            <span class="order-date">{{ order.createTime }}</span>
          </div>
          <span class="order-status" :class="order.status?.toLowerCase()">{{ formatStatus(order.status) }}</span>
        </div>
        <div class="order-items">
          <div v-for="item in (order.items || []).slice(0, 3)" :key="item.productId" class="order-item">
            <img :src="item.productImage || `https://picsum.photos/60/60?random=${item.productId}`" />
            <div class="item-info">
              <span>{{ item.productName }}</span>
              <span class="item-qty">x{{ item.quantity }}</span>
            </div>
          </div>
          <div v-if="(order.items || []).length > 3" class="more-items">+{{ order.items.length - 3 }} more items</div>
        </div>
        <div class="order-footer">
          <span class="order-total">Total: <strong>${{ order.totalAmount }}</strong></span>
          <div class="order-actions">
            <button v-if="order.status === 'PENDING_PAYMENT'" class="action-btn primary" @click="payOrder(order)">PAY NOW</button>
            <button v-if="order.status === 'PENDING_PAYMENT'" class="action-btn" @click="cancelOrder(order)">Cancel</button>
          </div>
        </div>
      </div>

      <el-empty v-if="!loading && !orders.length" description="No orders yet">
        <button class="shop-btn" @click="$router.push('/')">START SHOPPING</button>
      </el-empty>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { orderApi } from '@/api'
import { useUserStore } from '@/stores/user'
import { ElMessage, ElMessageBox } from 'element-plus'

const router = useRouter()
const userStore = useUserStore()

const orders = ref([])
const loading = ref(false)

const statusMap = {
  PENDING_PAYMENT: 'Pending Payment',
  PENDING_SHIPMENT: 'Processing',
  SHIPPED: 'Shipped',
  COMPLETED: 'Completed',
  CANCELLED: 'Cancelled'
}

const formatStatus = (status) => statusMap[status] || status

const fetchOrders = async () => {
  if (!userStore.isLoggedIn) {
    router.push('/login')
    return
  }
  loading.value = true
  try {
    const res = await orderApi.list(userStore.userId, { page: 1, size: 20 })
    orders.value = res.data?.records || res.data || []
  } finally {
    loading.value = false
  }
}

const payOrder = (order) => {
  router.push({ path: '/payment', query: { orderNumber: order.orderNumber } })
}

const cancelOrder = async (order) => {
  await ElMessageBox.confirm('Cancel this order?', 'Confirm', { type: 'warning' })
  try {
    await orderApi.cancel(order.orderNumber)
    ElMessage.success('Order cancelled')
    fetchOrders()
  } catch (e) {
    ElMessage.error('Failed to cancel')
  }
}

onMounted(fetchOrders)
</script>

<style scoped>
.orders-page {
  max-width: 900px;
  margin: 0 auto;
  padding: 32px 24px;
  min-height: 60vh;
}

.page-title {
  font-size: 28px;
  font-weight: 400;
  color: #333;
  margin: 0 0 32px;
}

.orders-list {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.order-card {
  background: #fff;
  border: 1px solid #eee;
  padding: 20px;
}

.order-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding-bottom: 16px;
  border-bottom: 1px solid #eee;
}

.order-info {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.order-no {
  font-size: 14px;
  font-weight: 500;
  color: #333;
}

.order-date {
  font-size: 12px;
  color: #999;
}

.order-status {
  font-size: 12px;
  font-weight: 500;
  padding: 4px 12px;
  border-radius: 2px;
  text-transform: uppercase;
}

.order-status.pending_payment { background: #fff3e0; color: #f57c00; }
.order-status.pending_shipment { background: #e3f2fd; color: #1976d2; }
.order-status.shipped { background: #e8f5e9; color: #388e3c; }
.order-status.completed { background: #f5f5f5; color: #666; }
.order-status.cancelled { background: #ffebee; color: #d32f2f; }

.order-items {
  display: flex;
  gap: 16px;
  padding: 16px 0;
  flex-wrap: wrap;
}

.order-item {
  display: flex;
  align-items: center;
  gap: 12px;
}

.order-item img {
  width: 50px;
  height: 50px;
  object-fit: cover;
}

.order-item .item-info {
  display: flex;
  flex-direction: column;
  font-size: 13px;
}

.item-qty {
  color: #999;
}

.more-items {
  font-size: 13px;
  color: #999;
  display: flex;
  align-items: center;
}

.order-footer {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding-top: 16px;
  border-top: 1px solid #eee;
}

.order-total {
  font-size: 14px;
  color: #666;
}

.order-total strong {
  color: #E91E63;
  font-size: 18px;
}

.order-actions {
  display: flex;
  gap: 12px;
}

.action-btn {
  padding: 8px 20px;
  border: 1px solid #ddd;
  background: #fff;
  font-size: 13px;
  cursor: pointer;
  transition: all 0.2s;
}

.action-btn:hover {
  border-color: #E91E63;
  color: #E91E63;
}

.action-btn.primary {
  background: #E91E63;
  border-color: #E91E63;
  color: #fff;
}

.action-btn.primary:hover {
  background: #c2185b;
}

.shop-btn {
  padding: 14px 32px;
  background: #E91E63;
  color: #fff;
  border: none;
  cursor: pointer;
}
</style>
