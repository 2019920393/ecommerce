<template>
  <div class="login-page">
    <div class="login-card">
      <h1 class="login-title">Login</h1>
      
      <el-form ref="formRef" :model="form" :rules="rules" label-position="top">
        <el-form-item label="Username" prop="username">
          <el-input v-model="form.username" placeholder="Enter your username" size="large" />
        </el-form-item>
        <el-form-item label="Password" prop="password">
          <el-input v-model="form.password" type="password" placeholder="Enter your password" size="large" show-password @keyup.enter="handleLogin" />
        </el-form-item>
        <el-form-item>
          <button type="button" class="login-btn" :disabled="loading" @click="handleLogin">
            {{ loading ? 'Logging in...' : 'LOGIN' }}
          </button>
        </el-form-item>
      </el-form>

      <div class="login-footer">
        <span>Don't have an account?</span>
        <router-link to="/register">Register</router-link>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { useUserStore } from '@/stores/user'
import { ElMessage } from 'element-plus'

const router = useRouter()
const route = useRoute()
const userStore = useUserStore()

const formRef = ref(null)
const loading = ref(false)

const form = reactive({
  username: '',
  password: ''
})

const rules = {
  username: [{ required: true, message: 'Username is required', trigger: 'blur' }],
  password: [{ required: true, message: 'Password is required', trigger: 'blur' }]
}

const handleLogin = async () => {
  const valid = await formRef.value?.validate().catch(() => false)
  if (!valid) return

  loading.value = true
  try {
    await userStore.login(form.username, form.password)
    ElMessage.success('Login successful')
    router.push(route.query.redirect || '/')
  } catch (error) {
    ElMessage.error(error.message || 'Login failed')
  } finally {
    loading.value = false
  }
}
</script>

<style scoped>
.login-page {
  min-height: calc(100vh - 56px);
  display: flex;
  align-items: center;
  justify-content: center;
  background: #f5f5f5;
  padding: 24px;
}

.login-card {
  width: 400px;
  max-width: 100%;
  background: #fff;
  padding: 48px 40px;
  box-shadow: 0 2px 12px rgba(0,0,0,0.1);
}

.login-title {
  font-size: 24px;
  font-weight: 400;
  color: #333;
  margin: 0 0 32px;
  text-align: center;
}

.login-btn {
  width: 100%;
  padding: 14px;
  background: #E91E63;
  color: #fff;
  border: none;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  transition: background 0.2s;
}

.login-btn:hover {
  background: #c2185b;
}

.login-btn:disabled {
  background: #ccc;
  cursor: not-allowed;
}

.login-footer {
  text-align: center;
  margin-top: 24px;
  font-size: 14px;
  color: #666;
}

.login-footer a {
  color: #E91E63;
  text-decoration: none;
  margin-left: 8px;
}
</style>
