<template>
  <div class="profile-page">
    <h1 class="page-title">My Account</h1>

    <div class="profile-content">
      <!-- 用户信息 -->
      <section class="section">
        <h2>Account Information</h2>
        <div class="info-grid">
          <div class="info-item">
            <label>Username</label>
            <span>{{ userInfo.username }}</span>
          </div>
          <div class="info-item">
            <label>Phone</label>
            <span>{{ userInfo.phone || '-' }}</span>
          </div>
          <div class="info-item">
            <label>Email</label>
            <span>{{ userInfo.email || '-' }}</span>
          </div>
          <div class="info-item">
            <label>Member Since</label>
            <span>{{ userInfo.createTime || '-' }}</span>
          </div>
        </div>
      </section>

      <!-- 快捷入口 -->
      <section class="section">
        <h2>Quick Links</h2>
        <div class="quick-links">
          <div class="link-card" @click="$router.push('/orders')">
            <el-icon :size="32"><List /></el-icon>
            <span>My Orders</span>
          </div>
          <div class="link-card" @click="$router.push('/cart')">
            <el-icon :size="32"><ShoppingCart /></el-icon>
            <span>Shopping Cart</span>
          </div>
          <div class="link-card" @click="showAddressDialog = true">
            <el-icon :size="32"><Location /></el-icon>
            <span>Addresses</span>
          </div>
          <div class="link-card" @click="handleLogout">
            <el-icon :size="32"><SwitchButton /></el-icon>
            <span>Logout</span>
          </div>
        </div>
      </section>
    </div>

    <!-- 地址弹窗 -->
    <el-dialog v-model="showAddressDialog" title="Saved Addresses" width="500px">
      <div class="address-list">
        <div v-for="addr in addresses" :key="addr.id" class="address-item">
          <div class="addr-info">
            <strong>{{ addr.name }}</strong> - {{ addr.phone }}
            <p>{{ addr.detail }}, {{ addr.city }}</p>
          </div>
        </div>
        <el-empty v-if="!addresses.length" description="No saved addresses" />
      </div>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '@/stores/user'

const router = useRouter()
const userStore = useUserStore()

const userInfo = computed(() => userStore.userInfo || {})
const showAddressDialog = ref(false)

const addresses = ref([
  { id: 1, name: 'John Doe', phone: '138****8000', detail: '123 Main St', city: 'New York' }
])

const handleLogout = () => {
  userStore.logout()
  router.push('/')
}
</script>

<style scoped>
.profile-page {
  max-width: 800px;
  margin: 0 auto;
  padding: 32px 24px;
  min-height: 60vh;
}

.page-title {
  font-size: 28px;
  font-weight: 400;
  color: #333;
  margin: 0 0 32px;
}

.section {
  background: #fff;
  border: 1px solid #eee;
  padding: 24px;
  margin-bottom: 24px;
}

.section h2 {
  font-size: 18px;
  font-weight: 500;
  color: #333;
  margin: 0 0 20px;
}

.info-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 20px;
}

.info-item {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.info-item label {
  font-size: 12px;
  color: #999;
  text-transform: uppercase;
}

.info-item span {
  font-size: 14px;
  color: #333;
}

.quick-links {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 16px;
}

.link-card {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 12px;
  padding: 24px;
  background: #f9f9f9;
  cursor: pointer;
  transition: all 0.2s;
}

.link-card:hover {
  background: #f0f0f0;
  color: #E91E63;
}

.link-card span {
  font-size: 13px;
}

.address-list {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.address-item {
  padding: 16px;
  border: 1px solid #eee;
}

.addr-info strong {
  color: #333;
}

.addr-info p {
  margin: 8px 0 0;
  font-size: 14px;
  color: #666;
}

@media (max-width: 600px) {
  .info-grid { grid-template-columns: 1fr; }
  .quick-links { grid-template-columns: repeat(2, 1fr); }
}
</style>
