<template>
  <div class="detail-page" v-loading="loading">
    <!-- 面包屑导航 -->
    <div class="breadcrumb">
      <router-link to="/" class="crumb">Home</router-link>
      <span class="sep">/</span>
      <router-link to="/products" class="crumb">Products</router-link>
      <span class="sep">/</span>
      <span class="current">{{ product.productName || 'Product' }}</span>
    </div>

    <div class="detail-content" v-if="product.productId">
      <!-- 商品图片 -->
      <div class="product-gallery">
        <div class="main-image-wrapper">
          <img :src="currentImage" class="main-image" />
          <div v-if="product.stock === 0" class="out-of-stock-badge">OUT OF STOCK</div>
        </div>
        <div class="thumbnail-list" v-if="images.length > 1">
          <div 
            v-for="(img, idx) in images" 
            :key="idx"
            :class="['thumbnail', { active: currentImageIdx === idx }]"
            @click="currentImageIdx = idx"
          >
            <img :src="img" />
          </div>
        </div>
      </div>

      <!-- 商品信息 -->
      <div class="product-info">
        <h1 class="product-name">{{ product.productName }}</h1>
        
        <div class="price-section">
          <span class="current-price">${{ product.price }}</span>
          <span v-if="product.originalPrice && product.originalPrice > product.price" class="original-price">
            ${{ product.originalPrice }}
          </span>
          <span v-if="product.originalPrice && product.originalPrice > product.price" class="discount">
            {{ Math.round((1 - product.price / product.originalPrice) * 100) }}% OFF
          </span>
        </div>

        <p class="product-desc">{{ product.description || 'High quality product with premium materials. Designed for everyday use with exceptional durability and style.' }}</p>
        
        <!-- 库存状态 -->
        <div class="stock-status">
          <template v-if="product.stock > 10">
            <el-icon class="in-stock"><CircleCheck /></el-icon>
            <span class="in-stock">In Stock</span>
          </template>
          <template v-else-if="product.stock > 0">
            <el-icon class="low-stock"><Warning /></el-icon>
            <span class="low-stock">Only {{ product.stock }} left in stock</span>
          </template>
          <template v-else>
            <el-icon class="no-stock"><CircleClose /></el-icon>
            <span class="no-stock">Out of Stock</span>
          </template>
        </div>

        <div class="quantity-row" v-if="product.stock > 0">
          <label>Quantity</label>
          <el-input-number 
            v-model="quantity" 
            :min="1" 
            :max="product.stock" 
            @change="validateQuantity"
          />
          <span class="max-qty">Max: {{ product.stock }}</span>
        </div>

        <div class="action-buttons">
          <button 
            class="add-cart-btn" 
            @click="handleAddCart"
            :disabled="product.stock === 0 || adding"
          >
            <el-icon v-if="!adding"><ShoppingCart /></el-icon>
            <el-icon v-else class="is-loading"><Loading /></el-icon>
            {{ product.stock === 0 ? 'OUT OF STOCK' : 'ADD TO CART' }}
          </button>
          <button class="buy-now-btn" @click="handleBuyNow" :disabled="product.stock === 0">
            BUY NOW
          </button>
        </div>

        <div class="product-meta">
          <div class="meta-item">
            <span class="label">Category:</span>
            <span class="value">{{ product.categoryName || 'General' }}</span>
          </div>
          <div class="meta-item">
            <span class="label">Sales:</span>
            <span class="value">{{ product.sales || 0 }} sold</span>
          </div>
          <div class="meta-item">
            <span class="label">SKU:</span>
            <span class="value">SKU-{{ product.productId }}</span>
          </div>
        </div>

        <!-- 服务保障 -->
        <div class="service-list">
          <div class="service-item">
            <el-icon><Van /></el-icon>
            <span>Free Shipping</span>
          </div>
          <div class="service-item">
            <el-icon><RefreshRight /></el-icon>
            <span>30-Day Returns</span>
          </div>
          <div class="service-item">
            <el-icon><Shield /></el-icon>
            <span>Secure Payment</span>
          </div>
        </div>
      </div>
    </div>

    <!-- 商品详情Tab -->
    <div class="detail-tabs" v-if="product.productId">
      <el-tabs v-model="activeTab">
        <el-tab-pane label="Description" name="desc">
          <div class="tab-content">
            <h3>Product Description</h3>
            <p>{{ product.description || 'High quality product with premium materials. Designed for everyday use with exceptional durability and style.' }}</p>
            <p>Our products are made with the finest materials and crafted with attention to detail. Each item undergoes strict quality control to ensure customer satisfaction.</p>
          </div>
        </el-tab-pane>
        <el-tab-pane label="Specifications" name="specs">
          <div class="tab-content">
            <h3>Specifications</h3>
            <table class="specs-table">
              <tr><td>Product ID</td><td>{{ product.productId }}</td></tr>
              <tr><td>Category</td><td>{{ product.categoryName || 'General' }}</td></tr>
              <tr><td>Weight</td><td>0.5 kg</td></tr>
              <tr><td>Dimensions</td><td>20 x 15 x 10 cm</td></tr>
            </table>
          </div>
        </el-tab-pane>
        <el-tab-pane label="Reviews" name="reviews">
          <div class="tab-content">
            <h3>Customer Reviews</h3>
            <el-empty description="No reviews yet" />
          </div>
        </el-tab-pane>
      </el-tabs>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { productApi } from '@/api'
import { useCartStore } from '@/stores/cart'
import { useUserStore } from '@/stores/user'
import { ElMessage } from 'element-plus'
import { ShoppingCart, Loading, CircleCheck, Warning, CircleClose, Van, RefreshRight, Shield } from '@element-plus/icons-vue'

const route = useRoute()
const router = useRouter()
const cartStore = useCartStore()
const userStore = useUserStore()

const product = ref({})
const loading = ref(false)
const adding = ref(false)
const quantity = ref(1)
const currentImageIdx = ref(0)
const activeTab = ref('desc')

const images = computed(() => {
  const list = []
  if (product.value.mainImage) list.push(product.value.mainImage)
  if (product.value.images) {
    try {
      const parsed = JSON.parse(product.value.images)
      if (Array.isArray(parsed)) list.push(...parsed)
    } catch {}
  }
  if (list.length === 0) {
    list.push(`https://picsum.photos/500/500?random=${product.value.productId || 1}`)
  }
  return list
})

const currentImage = computed(() => images.value[currentImageIdx.value] || images.value[0])

const fetchProduct = async () => {
  loading.value = true
  try {
    const res = await productApi.detail(route.params.id)
    product.value = res.data || {}
  } finally {
    loading.value = false
  }
}

const validateQuantity = (val) => {
  if (val > product.value.stock) {
    quantity.value = product.value.stock
    ElMessage.warning(`Maximum quantity is ${product.value.stock}`)
  }
}

const handleAddCart = async () => {
  if (!userStore.isLoggedIn) {
    ElMessage.warning('Please login first')
    return router.push('/login')
  }
  if (product.value.stock === 0) {
    return ElMessage.error('Product is out of stock')
  }
  adding.value = true
  try {
    await cartStore.addToCart(product.value.productId, quantity.value)
    ElMessage.success(`Added ${quantity.value} item(s) to cart`)
  } catch (e) {
    ElMessage.error('Failed to add to cart')
  } finally {
    adding.value = false
  }
}

const handleBuyNow = async () => {
  if (!userStore.isLoggedIn) {
    ElMessage.warning('Please login first')
    return router.push('/login')
  }
  if (product.value.stock === 0) {
    return ElMessage.error('Product is out of stock')
  }
  adding.value = true
  try {
    await cartStore.addToCart(product.value.productId, quantity.value)
    router.push('/cart')
  } catch (e) {
    ElMessage.error('Failed to add to cart')
  } finally {
    adding.value = false
  }
}

onMounted(fetchProduct)
</script>

<style scoped>
.detail-page {
  max-width: 1200px;
  margin: 0 auto;
  padding: 24px;
  min-height: 60vh;
}

/* 面包屑 */
.breadcrumb {
  margin-bottom: 24px;
  font-size: 14px;
}

.crumb {
  color: #666;
  text-decoration: none;
}

.crumb:hover {
  color: #E91E63;
}

.sep {
  margin: 0 8px;
  color: #ccc;
}

.current {
  color: #333;
}

/* 内容区域 */
.detail-content {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 48px;
  margin-bottom: 48px;
}

/* 图片区域 */
.product-gallery {
  position: sticky;
  top: 80px;
}

.main-image-wrapper {
  position: relative;
  background: #f5f5f5;
  border-radius: 8px;
  overflow: hidden;
}

.main-image {
  width: 100%;
  aspect-ratio: 1;
  object-fit: cover;
}

.out-of-stock-badge {
  position: absolute;
  top: 16px;
  left: 16px;
  background: rgba(0,0,0,0.7);
  color: #fff;
  padding: 8px 16px;
  font-size: 12px;
  font-weight: 600;
  border-radius: 4px;
}

.thumbnail-list {
  display: flex;
  gap: 12px;
  margin-top: 16px;
}

.thumbnail {
  width: 80px;
  height: 80px;
  border-radius: 4px;
  overflow: hidden;
  cursor: pointer;
  border: 2px solid transparent;
  transition: border-color 0.2s;
}

.thumbnail.active {
  border-color: #E91E63;
}

.thumbnail img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

/* 商品信息 */
.product-info {
  padding: 0;
}

.product-name {
  font-size: 28px;
  font-weight: 500;
  color: #333;
  margin: 0 0 16px;
  line-height: 1.3;
}

.price-section {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 16px;
}

.current-price {
  font-size: 32px;
  color: #E91E63;
  font-weight: 600;
}

.original-price {
  font-size: 18px;
  color: #999;
  text-decoration: line-through;
}

.discount {
  background: #E91E63;
  color: #fff;
  font-size: 12px;
  padding: 4px 8px;
  border-radius: 4px;
  font-weight: 500;
}

.product-desc {
  font-size: 14px;
  color: #666;
  line-height: 1.7;
  margin-bottom: 20px;
}

/* 库存状态 */
.stock-status {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 20px;
  font-size: 14px;
}

.in-stock { color: #4caf50; }
.low-stock { color: #ff9800; }
.no-stock { color: #999; }

/* 数量选择 */
.quantity-row {
  display: flex;
  align-items: center;
  gap: 16px;
  margin-bottom: 24px;
}

.quantity-row label {
  font-size: 14px;
  color: #666;
  font-weight: 500;
}

.max-qty {
  font-size: 12px;
  color: #999;
}

/* 按钮 */
.action-buttons {
  display: flex;
  gap: 16px;
  margin-bottom: 32px;
}

.add-cart-btn,
.buy-now-btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  padding: 14px 32px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.2s;
  border-radius: 4px;
  flex: 1;
}

.add-cart-btn {
  background: #E91E63;
  color: #fff;
  border: none;
}

.add-cart-btn:hover:not(:disabled) {
  background: #c2185b;
}

.add-cart-btn:disabled {
  background: #ccc;
  cursor: not-allowed;
}

.buy-now-btn {
  background: #fff;
  color: #E91E63;
  border: 2px solid #E91E63;
}

.buy-now-btn:hover:not(:disabled) {
  background: #fce4ec;
}

.buy-now-btn:disabled {
  border-color: #ccc;
  color: #ccc;
  cursor: not-allowed;
}

/* 商品元信息 */
.product-meta {
  padding: 20px 0;
  border-top: 1px solid #eee;
  border-bottom: 1px solid #eee;
  margin-bottom: 20px;
}

.meta-item {
  display: flex;
  font-size: 14px;
  margin-bottom: 8px;
}

.meta-item:last-child {
  margin-bottom: 0;
}

.meta-item .label {
  color: #999;
  width: 100px;
}

.meta-item .value {
  color: #333;
}

/* 服务保障 */
.service-list {
  display: flex;
  gap: 24px;
}

.service-item {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 13px;
  color: #666;
}

.service-item .el-icon {
  color: #4caf50;
}

/* 详情Tab */
.detail-tabs {
  background: #fff;
  border-radius: 8px;
  padding: 24px;
}

.tab-content {
  padding: 20px 0;
}

.tab-content h3 {
  font-size: 18px;
  font-weight: 500;
  margin: 0 0 16px;
  color: #333;
}

.tab-content p {
  font-size: 14px;
  color: #666;
  line-height: 1.8;
  margin-bottom: 16px;
}

.specs-table {
  width: 100%;
  border-collapse: collapse;
}

.specs-table td {
  padding: 12px 16px;
  border-bottom: 1px solid #eee;
  font-size: 14px;
}

.specs-table td:first-child {
  color: #999;
  width: 150px;
}

/* 响应式 */
@media (max-width: 768px) {
  .detail-content {
    grid-template-columns: 1fr;
    gap: 24px;
  }
  
  .product-gallery {
    position: static;
  }
  
  .action-buttons {
    flex-direction: column;
  }
  
  .service-list {
    flex-wrap: wrap;
    gap: 16px;
  }
}
</style>
