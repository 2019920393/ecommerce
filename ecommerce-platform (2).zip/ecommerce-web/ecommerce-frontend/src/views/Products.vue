<template>
  <div class="products-page">
    <!-- Banner -->
    <section class="hero-banner">
      <img src="https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=1600&h=400&fit=crop" class="banner-bg" />
      <div class="banner-overlay">
        <h1 class="banner-title">ALL PRODUCTS</h1>
        <p class="banner-subtitle">Discover our collection</p>
      </div>
    </section>

    <div class="content-wrapper">
      <div class="main-content full-width">
        <!-- 筛选栏 -->
        <section class="filter-section">
          <div class="filter-group">
            <label>Category</label>
            <el-select v-model="filters.category" placeholder="All" clearable>
              <el-option label="All" value="" />
              <el-option v-for="c in categories" :key="c.categoryId" :label="c.categoryName" :value="c.categoryId" />
            </el-select>
          </div>
          <div class="filter-group">
            <label>Search</label>
            <el-input v-model="filters.keyword" placeholder="Search..." clearable @keyup.enter="applyFilters" />
          </div>
          <button class="apply-btn" @click="applyFilters">APPLY</button>
        </section>

        <!-- 分页信息 -->
        <section class="pagination-info">
          <span>Showing {{ products.length }} of {{ total }} products - Page {{ page }}</span>
          <div class="page-nav">
            <span v-if="page > 1" class="page-link" @click="prevPage">Previous</span>
            <span v-if="hasMore" class="page-link" @click="nextPage">Next</span>
          </div>
        </section>

        <!-- 商品网格 -->
        <section class="products-section" v-loading="loading">
          <div class="products-grid">
            <div v-for="product in products" :key="product.productId" class="product-card">
              <div class="product-image" @click="goDetail(product.productId)">
                <img :src="product.mainImage || `https://picsum.photos/300/300?random=${product.productId}`" />
                <div class="product-overlay">
                  <el-button 
                    type="primary" 
                    class="add-cart-btn"
                    @click.stop="addToCart(product)"
                    :loading="addingId === product.productId"
                  >
                    <el-icon><ShoppingCart /></el-icon>
                    ADD TO CART
                  </el-button>
                </div>
              </div>
              <div class="product-info" @click="goDetail(product.productId)">
                <h3 class="product-name">{{ product.productName }}</h3>
                <div class="product-meta">
                  <span class="product-price">${{ product.price }}</span>
                  <span v-if="product.stock <= 10 && product.stock > 0" class="stock-warning">
                    Only {{ product.stock }} left
                  </span>
                  <span v-if="product.stock === 0" class="out-of-stock">Out of stock</span>
                </div>
              </div>
            </div>
          </div>

          <el-empty v-if="!loading && !products.length" description="No products found" />
        </section>

        <!-- 底部分页 -->
        <section class="pagination-bottom" v-if="total > pageSize">
          <span v-if="page > 1" class="page-link" @click="prevPage">Previous</span>
          <span class="page-current">{{ page }}</span>
          <span v-if="hasMore" class="page-link" @click="nextPage">Next</span>
        </section>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, computed, onMounted, watch } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { productApi, categoryApi } from '@/api'
import { useCartStore } from '@/stores/cart'
import { useUserStore } from '@/stores/user'
import { ElMessage } from 'element-plus'
import { ShoppingCart, Search } from '@element-plus/icons-vue'

const router = useRouter()
const route = useRoute()
const cartStore = useCartStore()
const userStore = useUserStore()

const products = ref([])
const categories = ref([])
const loading = ref(false)
const addingId = ref(null)
const page = ref(1)
const pageSize = ref(12)
const total = ref(0)

const filters = reactive({
  category: '',
  keyword: '',
  sort: ''
})

const hasMore = computed(() => page.value * pageSize.value < total.value)

const fetchProducts = async () => {
  loading.value = true
  try {
    const params = { pageNum: page.value, pageSize: pageSize.value }
    if (filters.category) params.categoryId = filters.category
    if (filters.keyword) params.keyword = filters.keyword
    const res = await productApi.list(params)
    let list = res.data?.records || res.data || []
    
    // 前端排序
    if (filters.sort === 'price_asc') {
      list = [...list].sort((a, b) => a.price - b.price)
    } else if (filters.sort === 'price_desc') {
      list = [...list].sort((a, b) => b.price - a.price)
    } else if (filters.sort === 'sales') {
      list = [...list].sort((a, b) => (b.sales || 0) - (a.sales || 0))
    }
    
    products.value = list
    total.value = res.data?.total || products.value.length
  } finally {
    loading.value = false
  }
}

const fetchCategories = async () => {
  try {
    const res = await categoryApi.tree()
    const flat = []
    const flatten = (list) => list.forEach(item => { flat.push(item); item.children?.length && flatten(item.children) })
    flatten(res.data || [])
    categories.value = flat
  } catch (e) {}
}

const selectCategory = (categoryId) => {
  filters.category = categoryId || ''
  page.value = 1
  fetchProducts()
}

const applyFilters = () => {
  page.value = 1
  fetchProducts()
}

const clearFilters = () => {
  filters.category = ''
  filters.keyword = ''
  filters.sort = ''
  page.value = 1
  fetchProducts()
}

const nextPage = () => { page.value++; fetchProducts() }
const prevPage = () => { if (page.value > 1) { page.value--; fetchProducts() } }

const goDetail = (id) => router.push(`/product/${id}`)

const addToCart = async (product) => {
  if (!userStore.isLoggedIn) {
    ElMessage.warning('Please login first')
    router.push('/login')
    return
  }
  if (product.stock === 0) {
    ElMessage.warning('Product is out of stock')
    return
  }
  addingId.value = product.productId
  try {
    await cartStore.addToCart(product.productId, 1)
    ElMessage.success('Added to cart')
  } catch (e) {
    ElMessage.error('Failed to add to cart')
  } finally {
    addingId.value = null
  }
}

// 监听路由query变化
watch(() => route.query, (query) => {
  if (query.categoryId) filters.category = Number(query.categoryId)
  if (query.keyword) filters.keyword = query.keyword
  fetchProducts()
}, { immediate: true })

onMounted(fetchCategories)
</script>

<style scoped>
.products-page {
  background: #f5f5f5;
  min-height: 100%;
}

/* Banner */
.hero-banner {
  position: relative;
  height: 280px;
  overflow: hidden;
}

.banner-bg {
  width: 100%;
  height: 100%;
  object-fit: cover;
  filter: brightness(0.7);
}

.banner-overlay {
  position: absolute;
  inset: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  color: #fff;
}

.banner-title {
  font-size: 56px;
  font-weight: 300;
  letter-spacing: 6px;
  margin: 0;
  text-shadow: 0 2px 20px rgba(0,0,0,0.3);
}

.banner-subtitle {
  font-size: 16px;
  margin-top: 12px;
  opacity: 0.9;
}

/* 内容区域 */
.content-wrapper {
  max-width: 1400px;
  margin: 0 auto;
  padding: 24px;
  display: flex;
  gap: 32px;
}

/* 主内容 */
.main-content {
  flex: 1;
  min-width: 0;
}

.main-content.full-width {
  width: 100%;
}

/* 筛选栏 */
.filter-section {
  background: #fff;
  padding: 20px 24px;
  border-radius: 4px;
  display: flex;
  align-items: flex-end;
  gap: 24px;
  margin-bottom: 20px;
}

.filter-group {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.filter-group label {
  font-size: 14px;
  color: #666;
  font-weight: 500;
}

.filter-group .el-select,
.filter-group .el-input {
  width: 200px;
}

.filter-group :deep(.el-input__wrapper) {
  box-shadow: 0 0 0 1px #ddd inset;
  border-radius: 0;
}

.filter-group :deep(.el-input.is-focus .el-input__wrapper),
.filter-group :deep(.el-input__wrapper:hover) {
  box-shadow: 0 0 0 1px #E91E63 inset !important;
}

.apply-btn {
  padding: 10px 32px;
  border: 2px solid #E91E63;
  background: transparent;
  color: #E91E63;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.2s;
}

.apply-btn:hover {
  background: #E91E63;
  color: #fff;
}

/* 分页信息 */
.pagination-info {
  padding: 12px 0;
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 14px;
  color: #666;
}

.page-nav {
  display: flex;
  gap: 16px;
}

.page-link {
  color: #E91E63;
  cursor: pointer;
  transition: opacity 0.2s;
}

.page-link:hover {
  opacity: 0.7;
}

/* 商品网格 */
.products-section {
  min-height: 400px;
}

.products-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 20px;
}

.product-card {
  background: #fff;
  border-radius: 4px;
  overflow: hidden;
  transition: box-shadow 0.2s;
}

.product-card:hover {
  box-shadow: 0 4px 20px rgba(0,0,0,0.1);
}

.product-image {
  position: relative;
  aspect-ratio: 1;
  overflow: hidden;
  background: #f5f5f5;
  cursor: pointer;
}

.product-image img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  transition: transform 0.3s;
}

.product-card:hover .product-image img {
  transform: scale(1.05);
}

.product-overlay {
  position: absolute;
  inset: 0;
  background: rgba(0,0,0,0.4);
  display: flex;
  align-items: center;
  justify-content: center;
  opacity: 0;
  transition: opacity 0.2s;
}

.product-card:hover .product-overlay {
  opacity: 1;
}

.add-cart-btn {
  background: #E91E63;
  border-color: #E91E63;
  font-size: 13px;
  padding: 10px 20px;
}

.add-cart-btn:hover {
  background: #C2185B;
  border-color: #C2185B;
}

.product-info {
  padding: 16px;
  cursor: pointer;
}

.product-name {
  font-size: 14px;
  font-weight: 400;
  color: #333;
  margin: 0 0 8px 0;
  line-height: 1.4;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.product-meta {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
}

.product-price {
  font-size: 16px;
  color: #E91E63;
  font-weight: 600;
}

.stock-warning {
  font-size: 12px;
  color: #ff9800;
}

.out-of-stock {
  font-size: 12px;
  color: #999;
}

/* 底部分页 */
.pagination-bottom {
  padding: 24px;
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 24px;
}

.page-current {
  font-size: 16px;
  font-weight: 500;
  background: #E91E63;
  color: #fff;
  width: 32px;
  height: 32px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 4px;
}

/* 响应式 */
@media (max-width: 1200px) {
  .products-grid { grid-template-columns: repeat(3, 1fr); }
}

@media (max-width: 900px) {
  .filter-section { flex-wrap: wrap; }
  .banner-title { font-size: 40px; }
}

@media (max-width: 768px) {
  .products-grid { grid-template-columns: repeat(2, 1fr); gap: 12px; }
  .filter-right { flex-wrap: wrap; }
  .banner-title { font-size: 32px; }
  .hero-banner { height: 200px; }
  .content-wrapper { padding: 16px; }
}
</style>
