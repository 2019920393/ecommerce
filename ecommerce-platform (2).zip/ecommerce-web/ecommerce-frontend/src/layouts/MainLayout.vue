<template>
  <div class="layout">
    <!-- 顶部导航栏 -->
    <header class="header">
      <div class="header-inner">
        <router-link to="/" class="logo">
          <span class="logo-bracket">[</span>eShop<span class="logo-bracket">]</span>
          <span class="logo-sub">on containers</span>
        </router-link>
        
        <!-- 搜索框 -->
        <div class="search-box">
          <el-input
            v-model="searchKeyword"
            placeholder="Search products..."
            @keyup.enter="handleSearch"
            clearable
          >
            <template #prefix>
              <el-icon><Search /></el-icon>
            </template>
          </el-input>
        </div>
        
        <div class="header-right">
          <template v-if="userStore.isLoggedIn">
            <router-link to="/cart" class="header-link cart-link">
              <el-badge :value="cartStore.totalCount" :hidden="!cartStore.totalCount" :max="99">
                <el-icon :size="20"><ShoppingCart /></el-icon>
              </el-badge>
            </router-link>
            <el-dropdown trigger="click">
              <span class="header-link user-link">
                <el-icon :size="18"><User /></el-icon>
                {{ userStore.userInfo?.username || 'User' }}
                <el-icon><ArrowDown /></el-icon>
              </span>
              <template #dropdown>
                <el-dropdown-menu>
                  <el-dropdown-item @click="$router.push('/orders')">
                    <el-icon><List /></el-icon> My Orders
                  </el-dropdown-item>
                  <el-dropdown-item @click="$router.push('/profile')">
                    <el-icon><Setting /></el-icon> Profile
                  </el-dropdown-item>
                  <el-dropdown-item divided @click="handleLogout">
                    <el-icon><SwitchButton /></el-icon> Logout
                  </el-dropdown-item>
                </el-dropdown-menu>
              </template>
            </el-dropdown>
          </template>
          <template v-else>
            <router-link to="/login" class="header-link login-link">
              LOGIN <el-icon><User /></el-icon>
            </router-link>
          </template>
        </div>
      </div>
    </header>

    <!-- 主内容 -->
    <main class="main">
      <router-view />
    </main>

    <!-- Footer -->
    <footer class="footer">
      <div class="footer-inner">
        <div class="footer-links">
          <a href="#">About</a>
          <a href="#">Contact</a>
          <a href="#">Terms</a>
          <a href="#">Privacy</a>
        </div>
        <div class="footer-copy">
          © 2025 eShop. All rights reserved.
        </div>
      </div>
    </footer>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '@/stores/user'
import { useCartStore } from '@/stores/cart'
import { Search, ShoppingCart, User, ArrowDown, List, Setting, SwitchButton } from '@element-plus/icons-vue'

const router = useRouter()
const userStore = useUserStore()
const cartStore = useCartStore()

const searchKeyword = ref('')

onMounted(() => {
  if (userStore.isLoggedIn) {
    cartStore.fetchCart()
  }
})

const handleSearch = () => {
  if (searchKeyword.value.trim()) {
    router.push({ path: '/products', query: { keyword: searchKeyword.value.trim() } })
  }
}

const handleLogout = () => {
  userStore.logout()
  cartStore.cartItems = []
  router.push('/')
}
</script>

<style scoped>
.layout {
  min-height: 100vh;
  background: #fff;
  display: flex;
  flex-direction: column;
}

.header {
  background: #2a2a2a;
  height: 56px;
  position: sticky;
  top: 0;
  z-index: 100;
}

.header-inner {
  max-width: 1400px;
  margin: 0 auto;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 24px;
  gap: 32px;
}

.logo {
  text-decoration: none;
  color: #fff;
  font-size: 24px;
  font-weight: 300;
  display: flex;
  align-items: baseline;
  gap: 8px;
  flex-shrink: 0;
}

.logo-bracket {
  color: #E91E63;
}

.logo-sub {
  font-size: 12px;
  color: #999;
  font-weight: 400;
}

.search-box {
  flex: 1;
  max-width: 400px;
}

.search-box :deep(.el-input__wrapper) {
  background: #3a3a3a;
  box-shadow: none;
  border-radius: 4px;
}

.search-box :deep(.el-input__inner) {
  color: #fff;
}

.search-box :deep(.el-input__inner::placeholder) {
  color: #888;
}

.search-box :deep(.el-icon) {
  color: #888;
}

.search-box :deep(.el-input__wrapper:hover),
.search-box :deep(.el-input.is-focus .el-input__wrapper) {
  box-shadow: 0 0 0 1px #E91E63 inset;
}

.header-right {
  display: flex;
  align-items: center;
  gap: 20px;
  flex-shrink: 0;
}

.header-link {
  color: #fff;
  text-decoration: none;
  font-size: 14px;
  display: flex;
  align-items: center;
  gap: 6px;
  cursor: pointer;
  transition: color 0.2s;
}

.header-link:hover {
  color: #E91E63;
}

.cart-link :deep(.el-badge__content) {
  background: #E91E63;
  border: none;
}

.login-link {
  font-weight: 500;
}

.user-link {
  padding: 8px 0;
}

.main {
  flex: 1;
}

/* Footer */
.footer {
  background: #2a2a2a;
  color: #999;
  padding: 32px 24px;
  margin-top: auto;
}

.footer-inner {
  max-width: 1400px;
  margin: 0 auto;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.footer-links {
  display: flex;
  gap: 24px;
}

.footer-links a {
  color: #999;
  text-decoration: none;
  font-size: 14px;
  transition: color 0.2s;
}

.footer-links a:hover {
  color: #E91E63;
}

.footer-copy {
  font-size: 12px;
}

@media (max-width: 768px) {
  .search-box {
    display: none;
  }
  .footer-inner {
    flex-direction: column;
    gap: 16px;
  }
}
</style>
