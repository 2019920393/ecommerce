import axios from 'axios'
import { ElMessage } from 'element-plus'
import { useUserStore } from '@/stores/user'

const api = axios.create({
  baseURL: '/api/v1',
  timeout: 10000
})

// 请求拦截器
api.interceptors.request.use(
  config => {
    const userStore = useUserStore()
    if (userStore.token) {
      config.headers.Authorization = `Bearer ${userStore.token}`
    }
    return config
  },
  error => Promise.reject(error)
)

// 响应拦截器
api.interceptors.response.use(
  response => {
    const res = response.data
    if (res.code !== 200) {
      ElMessage.error(res.message || '请求失败')
      return Promise.reject(new Error(res.message))
    }
    return res
  },
  error => {
    if (error.response?.status === 401) {
      const userStore = useUserStore()
      userStore.logout()
      ElMessage.error('登录已过期，请重新登录')
    } else {
      ElMessage.error(error.message || '网络错误')
    }
    return Promise.reject(error)
  }
)

// 用户API
export const userApi = {
  register: data => api.post('/users/register', data),
  login: data => api.post('/users/login', data),
  getInfo: userId => api.get(`/users/${userId}`),
  updateInfo: (userId, data) => api.put(`/users/${userId}`, data)
}

// 地址API
export const addressApi = {
  list: userId => api.get(`/addresses/user/${userId}`),
  add: data => api.post('/addresses', data),
  update: (id, data) => api.put(`/addresses/${id}`, data),
  delete: id => api.delete(`/addresses/${id}`),
  setDefault: id => api.put(`/addresses/${id}/default`)
}

// 商品API
export const productApi = {
  list: params => api.get('/products', { params }),
  search: params => api.get('/products/search', { params }),
  detail: id => api.get(`/products/${id}`)
}

// 分类API
export const categoryApi = {
  tree: () => api.get('/categories/tree'),
  list: () => api.get('/categories')
}

// 购物车API
export const cartApi = {
  list: userId => api.get(`/cart/${userId}`),
  getByIds: (userId, cartItemIds) => api.get(`/cart/${userId}/items`, { params: { cartItemIds: cartItemIds.join(',') } }),
  add: data => api.post('/cart/items', data),
  update: (itemId, quantity) => api.put(`/cart/items/${itemId}`, null, { params: { quantity } }),
  delete: itemId => api.delete(`/cart/items/${itemId}`),
  clear: userId => api.delete(`/cart/${userId}`),
  total: userId => api.get(`/cart/${userId}/total`)
}

// 订单API
export const orderApi = {
  create: data => api.post('/orders', data),
  list: (userId, params) => api.get(`/orders/user/${userId}`, { params }),
  detail: orderNumber => api.get(`/orders/${orderNumber}`),
  cancel: orderNumber => api.put(`/orders/${orderNumber}/cancel`)
}

// 支付API
export const paymentApi = {
  create: (data, amount) => api.post('/payments', data, { params: { amount } }),
  pay: paymentNumber => api.post(`/payments/${paymentNumber}/pay`),
  status: paymentNumber => api.get(`/payments/${paymentNumber}`),
  getByOrder: orderNumber => api.get(`/payments/order/${orderNumber}`)
}

export default api
