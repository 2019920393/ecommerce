import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import { cartApi } from '@/api'
import { useUserStore } from './user'

export const useCartStore = defineStore('cart', () => {
  const cartItems = ref([])
  const loading = ref(false)

  const totalCount = computed(() => cartItems.value.reduce((sum, item) => sum + item.quantity, 0))
  const totalPrice = computed(() => cartItems.value.reduce((sum, item) => sum + item.price * item.quantity, 0))

  const fetchCart = async () => {
    const userStore = useUserStore()
    if (!userStore.isLoggedIn) return
    loading.value = true
    try {
      const res = await cartApi.list(userStore.userId)
      cartItems.value = res.data || []
    } finally {
      loading.value = false
    }
  }

  const addToCart = async (productId, quantity = 1) => {
    const userStore = useUserStore()
    await cartApi.add({ userId: userStore.userId, productId, quantity })
    await fetchCart()
  }

  const updateQuantity = async (itemId, quantity) => {
    await cartApi.update(itemId, quantity)
    await fetchCart()
  }

  const removeFromCart = async (itemId) => {
    await cartApi.delete(itemId)
    await fetchCart()
  }

  const clearCart = async () => {
    const userStore = useUserStore()
    await cartApi.clear(userStore.userId)
    cartItems.value = []
  }

  return { cartItems, loading, totalCount, totalPrice, fetchCart, addToCart, updateQuantity, removeFromCart, clearCart }
})
