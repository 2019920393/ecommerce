package com.ecommerce.order.repository;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ecommerce.order.domain.entity.OrderItem;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * 订单明细数据访问接口
 * <p>
 * 继承MyBatis-Plus的BaseMapper接口，提供基本的CRUD操作
 * 订单明细通常与订单一起查询，很少单独操作
 * </p>
 * 
 * <p>
 * BaseMapper提供的方法：
 * - insert(OrderItem item) - 插入订单明细
 * - insertBatch(List items) - 批量插入
 * - selectById(Long id) - 根据ID查询
 * - updateById(OrderItem item) - 根据ID更新
 * - deleteById(Long id) - 根据ID删除
 * - selectList(Wrapper) - 条件查询列表
 * </p>
 *
 * @author ecommerce-platform
 * @since 1.0.0
 */
@Mapper
public interface OrderItemRepository extends BaseMapper<OrderItem> {

    /**
     * 根据订单ID查询订单明细列表
     * <p>
     * 最常用的查询方法，查询某个订单的所有商品明细
     * 使用索引idx_order_id
     * </p>
     *
     * @param orderId 订单ID
     * @return 订单明细列表
     */
    @Select("SELECT * FROM order_items WHERE order_id = #{orderId} ORDER BY item_id ASC")
    List<OrderItem> findByOrderId(@Param("orderId") Long orderId);

    /**
     * 根据订单号查询订单明细列表
     * <p>
     * 通过订单号查询，适用于只知道订单号的场景
     * 使用索引idx_order_number
     * </p>
     *
     * @param orderNumber 订单号
     * @return 订单明细列表
     */
    @Select("SELECT * FROM order_items WHERE order_number = #{orderNumber} ORDER BY item_id ASC")
    List<OrderItem> findByOrderNumber(@Param("orderNumber") String orderNumber);

    /**
     * 根据商品ID查询订单明细列表
     * <p>
     * 用于查询某个商品的销售记录
     * 使用索引idx_product_id
     * </p>
     *
     * @param productId 商品ID
     * @return 订单明细列表
     */
    @Select("SELECT * FROM order_items WHERE product_id = #{productId} ORDER BY create_time DESC")
    List<OrderItem> findByProductId(@Param("productId") Long productId);

    /**
     * 批量根据订单ID查询订单明细
     * <p>
     * 用于批量查询多个订单的明细，提高查询效率
     * </p>
     *
     * @param orderIds 订单ID列表
     * @return 订单明细列表
     */
    @Select("<script>" +
            "SELECT * FROM order_items " +
            "WHERE order_id IN " +
            "<foreach collection='orderIds' item='orderId' open='(' separator=',' close=')'>" +
            "#{orderId}" +
            "</foreach>" +
            "ORDER BY order_id, item_id" +
            "</script>")
    List<OrderItem> findByOrderIds(@Param("orderIds") List<Long> orderIds);

    /**
     * 统计订单的商品数量
     * <p>
     * 返回订单中包含多少个不同的商品（不是总数量）
     * </p>
     *
     * @param orderId 订单ID
     * @return 商品种类数量
     */
    @Select("SELECT COUNT(*) FROM order_items WHERE order_id = #{orderId}")
    int countByOrderId(@Param("orderId") Long orderId);

    /**
     * 统计订单的商品总数量
     * <p>
     * 返回订单中所有商品的数量之和
     * </p>
     *
     * @param orderId 订单ID
     * @return 商品总数量
     */
    @Select("SELECT IFNULL(SUM(quantity), 0) FROM order_items WHERE order_id = #{orderId}")
    int sumQuantityByOrderId(@Param("orderId") Long orderId);

    /**
     * 统计商品的销售数量
     * <p>
     * 用于统计某个商品的总销量
     * </p>
     *
     * @param productId 商品ID
     * @return 销售数量
     */
    @Select("SELECT IFNULL(SUM(quantity), 0) FROM order_items WHERE product_id = #{productId}")
    int sumQuantityByProductId(@Param("productId") Long productId);

    /**
     * 检查订单是否包含指定商品
     * <p>
     * 用于验证订单中是否有某个商品
     * </p>
     *
     * @param orderId   订单ID
     * @param productId 商品ID
     * @return true-包含，false-不包含
     */
    @Select("SELECT COUNT(*) > 0 FROM order_items WHERE order_id = #{orderId} AND product_id = #{productId}")
    boolean existsByOrderIdAndProductId(@Param("orderId") Long orderId, @Param("productId") Long productId);

    /**
     * 根据订单ID删除订单明细
     * <p>
     * 用于删除订单时级联删除订单明细
     * 注意：这是物理删除，不是逻辑删除
     * </p>
     *
     * @param orderId 订单ID
     * @return 删除的行数
     */
    @Select("DELETE FROM order_items WHERE order_id = #{orderId}")
    int deleteByOrderId(@Param("orderId") Long orderId);
}