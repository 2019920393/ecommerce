package com.ecommerce.order.domain.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 订单明细实体类
 * <p>
 * 对应数据库表：order_items
 * 存储订单中的商品信息（快照），包括商品名称、价格、数量等
 * </p>
 * 
 * <p>
 * 设计说明：
 * 1. 商品信息采用快照模式，下单时保存商品当时的信息
 * 2. 即使商品后续修改价格或下架，订单明细中的信息不变
 * 3. 这样可以保证订单的历史准确性和可追溯性
 * </p>
 *
 * @author ecommerce-platform
 * @since 1.0.0
 */
@Data
@TableName("order_items")
public class OrderItem implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 明细ID，主键，自增
     */
    @TableId(value = "item_id", type = IdType.AUTO)
    private Long itemId;

    /**
     * 订单ID
     * 关联orders表的order_id
     */
    @TableField("order_id")
    private Long orderId;

    /**
     * 订单号
     * 冗余字段，方便查询
     */
    @TableField("order_number")
    private String orderNumber;

    // ==================== 商品信息（快照） ====================

    /**
     * 商品ID
     * 关联商品表的product_id
     */
    @TableField("product_id")
    private Long productId;

    /**
     * 商品名称（快照）
     * 下单时的商品名称，最大50字符
     */
    @TableField("product_name")
    private String productName;

    /**
     * 商品图片URL（快照）
     * 下单时的商品主图
     */
    @TableField("product_image")
    private String productImage;

    /**
     * 商品规格（快照）
     * 例如：颜色:红色;尺寸:L
     * 可为空
     */
    @TableField("specification")
    private String specification;

    // ==================== 价格和数量 ====================

    /**
     * 单价（快照）
     * 下单时的商品单价
     */
    @TableField("unit_price")
    private BigDecimal unitPrice;

    /**
     * 购买数量
     * 必须大于0
     */
    @TableField("quantity")
    private Integer quantity;

    /**
     * 小计金额
     * 计算公式：subtotal = unit_price * quantity
     */
    @TableField("subtotal")
    private BigDecimal subtotal;

    // ==================== 时间信息 ====================

    /**
     * 创建时间
     * 自动填充
     */
    @TableField(value = "create_time", fill = FieldFill.INSERT)
    private LocalDateTime createTime;

    // ==================== 业务方法 ====================

    /**
     * 计算小计金额
     * 公式：小计 = 单价 × 数量
     *
     * @return 小计金额
     */
    public BigDecimal calculateSubtotal() {
        if (unitPrice == null || quantity == null) {
            return BigDecimal.ZERO;
        }
        return unitPrice.multiply(BigDecimal.valueOf(quantity));
    }

    /**
     * 验证数量是否有效
     * 数量必须大于0
     *
     * @return true-有效，false-无效
     */
    public boolean isQuantityValid() {
        return quantity != null && quantity > 0;
    }

    /**
     * 验证价格是否有效
     * 单价必须大于0
     *
     * @return true-有效，false-无效
     */
    public boolean isPriceValid() {
        return unitPrice != null && unitPrice.compareTo(BigDecimal.ZERO) > 0;
    }

    /**
     * 验证订单明细是否有效
     * 检查必填字段和业务规则
     *
     * @return true-有效，false-无效
     */
    public boolean isValid() {
        return orderId != null
                && orderNumber != null && !orderNumber.isEmpty()
                && productId != null
                && productName != null && !productName.isEmpty()
                && isQuantityValid()
                && isPriceValid();
    }

    /**
     * 构建商品显示名称
     * 格式：商品名称 [规格]
     * 例如：iPhone 15 Pro [颜色:深空黑;容量:256GB]
     *
     * @return 商品显示名称
     */
    public String getDisplayName() {
        if (specification == null || specification.isEmpty()) {
            return productName;
        }
        return productName + " [" + specification + "]";
    }

    /**
     * 设置小计金额
     * 根据单价和数量自动计算
     */
    public void setSubtotalFromPriceAndQuantity() {
        this.subtotal = calculateSubtotal();
    }
}