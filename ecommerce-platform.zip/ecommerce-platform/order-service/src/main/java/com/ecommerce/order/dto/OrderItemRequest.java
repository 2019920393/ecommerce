package com.ecommerce.order.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

/**
 * 订单明细请求DTO
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "订单明细请求")
public class OrderItemRequest {

    @Schema(description = "商品ID", example = "1001", required = true)
    @NotNull(message = "商品ID不能为空")
    private Long productId;

    @Schema(description = "商品名称", example = "iPhone 15 Pro", required = true)
    @NotNull(message = "商品名称不能为空")
    private String productName;

    @Schema(description = "商品图片URL", example = "https://example.com/image.jpg")
    private String productImage;

    @Schema(description = "商品规格", example = "黑色/256GB")
    private String specification;

    @Schema(description = "单价", example = "7999.00", required = true)
    @NotNull(message = "单价不能为空")
    private BigDecimal unitPrice;

    @Schema(description = "购买数量", example = "1", required = true)
    @NotNull(message = "购买数量不能为空")
    @Min(value = 1, message = "购买数量至少为1")
    private Integer quantity;
}
