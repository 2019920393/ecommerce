package com.ecommerce.order.config;

import com.baomidou.mybatisplus.extension.plugins.MybatisPlusInterceptor;
import com.baomidou.mybatisplus.extension.plugins.inner.OptimisticLockerInnerInterceptor;
import com.baomidou.mybatisplus.extension.plugins.inner.PaginationInnerInterceptor;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * MyBatis-Plus 配置类
 * 
 * <p>配置 MyBatis-Plus 的拦截器和插件</p>
 * 
 * <p>设计依据：</p>
 * <ul>
 *   <li>14.数据持久化设计文档.md - MyBatis-Plus配置</li>
 * </ul>
 * 
 * @author Kilo Code
 * @since 2025-11-21
 */
@Configuration
@MapperScan("com.ecommerce.order.repository")
public class MyBatisPlusConfig {

    /**
     * MyBatis-Plus 拦截器
     * 
     * <p>配置分页插件和乐观锁插件</p>
     * 
     * @return MybatisPlusInterceptor
     */
    @Bean
    public MybatisPlusInterceptor mybatisPlusInterceptor() {
        MybatisPlusInterceptor interceptor = new MybatisPlusInterceptor();
        
        // 分页插件
        interceptor.addInnerInterceptor(new PaginationInnerInterceptor());
        
        // 乐观锁插件
        interceptor.addInnerInterceptor(new OptimisticLockerInnerInterceptor());
        
        return interceptor;
    }
}
