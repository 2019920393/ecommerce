package com.ecommerce.order.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ecommerce.common.constant.Constants;
import com.ecommerce.common.enums.OrderStatus;
import com.ecommerce.common.exception.*;
import com.ecommerce.common.util.OrderNoGenerator;
import com.ecommerce.order.domain.entity.Order;
import com.ecommerce.order.domain.entity.OrderItem;
import com.ecommerce.order.repository.OrderItemRepository;
import com.ecommerce.order.repository.OrderRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

/**
 * 订单服务
 * 
 * <p>职责：处理订单业务逻辑的控制类</p>
 * 
 * <p>核心功能：</p>
 * <ul>
 *   <li>创建订单：校验库存、生成订单号、预扣库存</li>
 *   <li>订单查询：按订单号、用户ID、状态查询</li>
 *   <li>订单状态管理：更新状态、取消订单</li>
 *   <li>超时处理：定时检查并自动取消超时订单</li>
 * </ul>
 * 
 * <p>设计依据：</p>
 * <ul>
 *   <li>6.2.1类的属性和操作定义.md - OrderService定义</li>
 *   <li>12.类的精化设计文档.md - 业务逻辑层设计</li>
 *   <li>6.4UC9&UC10动态建模设计文档.md - 顺序图</li>
 * </ul>
 * 
 * @author Kilo Code
 * @since 2025-11-21
 */
@Slf4j
@Service
public class OrderService {

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private OrderItemRepository orderItemRepository;

    @Autowired
    private InventoryService inventoryService;

    /**
     * 创建订单
     * 
     * <p>业务流程（参考UC9顺序图）：</p>
     * <ol>
     *   <li>校验库存是否充足</li>
     *   <li>生成订单号</li>
     *   <li>创建订单对象</li>
     *   <li>创建订单明细</li>
     *   <li>计算订单总金额</li>
     *   <li>预扣库存（乐观锁）</li>
     *   <li>保存订单和订单明细</li>
     * </ol>
     * 
     * @param userId 用户ID
     * @param orderItems 订单明细列表（包含商品信息和数量）
     * @param recipientName 收货人姓名
     * @param recipientPhone 收货人电话
     * @param shippingAddress 完整收货地址
     * @param province 省
     * @param city 市
     * @param district 区
     * @param detailAddress 详细地址
     * @param remark 订单备注
     * @return 创建的订单
     * @throws InsufficientStockException 库存不足异常
     * @throws StockLockFailedException 库存锁定失败异常
     */
    @Transactional(rollbackFor = Exception.class)
    public Order createOrder(Long userId, List<OrderItem> orderItems,
                            String recipientName, String recipientPhone,
                            String shippingAddress, String province, String city,
                            String district, String detailAddress, String remark) {
        log.info("开始创建订单, userId={}, itemCount={}", userId, orderItems.size());

        // 1. 校验库存
        Map<Long, Boolean> stockCheckResult = inventoryService.batchCheckStock(orderItems);
        for (Map.Entry<Long, Boolean> entry : stockCheckResult.entrySet()) {
            if (!entry.getValue()) {
                Long productId = entry.getKey();
                log.error("商品库存不足, productId={}", productId);
                throw new InsufficientStockException("商品ID " + productId + " 库存不足");
            }
        }

        // 2. 生成订单号
        String orderNumber = OrderNoGenerator.generate();
        log.info("生成订单号: {}", orderNumber);

        // 3. 创建订单对象
        Order order = new Order();
        order.setOrderNumber(orderNumber);
        order.setUserId(userId);
        
        // 设置收货信息
        order.setRecipientName(recipientName);
        order.setRecipientPhone(recipientPhone);
        order.setShippingAddress(shippingAddress);
        order.setProvince(province);
        order.setCity(city);
        order.setDistrict(district);
        order.setDetailAddress(detailAddress);
        
        // 设置订单状态
        order.setStatus(OrderStatus.PENDING_PAYMENT.name());
        
        // 设置超时时间（30分钟）
        order.setExpireTime(LocalDateTime.now().plusMinutes(Constants.ORDER_TIMEOUT_MINUTES));
        
        // 设置备注
        order.setRemark(remark);

        // 4. 计算订单金额
        BigDecimal productAmount = BigDecimal.ZERO;
        for (OrderItem item : orderItems) {
            item.setOrderNumber(orderNumber);
            item.setSubtotalFromPriceAndQuantity(); // 计算小计
            productAmount = productAmount.add(item.getSubtotal());
        }
        
        order.setProductAmount(productAmount);
        order.setShippingFee(BigDecimal.ZERO); // 暂时免运费
        order.setDiscount(BigDecimal.ZERO); // 暂无优惠
        order.setTotalAmount(productAmount); // 总金额 = 商品总价 + 运费 - 优惠

        // 5. 预扣库存（乐观锁）
        boolean lockSuccess = inventoryService.lockStock(orderNumber, orderItems);
        if (!lockSuccess) {
            log.error("库存锁定失败, orderNumber={}", orderNumber);
            throw new StockLockFailedException("库存锁定失败，请稍后重试");
        }

        try {
            // 6. 保存订单
            orderRepository.insert(order);
            log.info("订单保存成功, orderId={}, orderNumber={}", order.getOrderId(), orderNumber);

            // 7. 保存订单明细
            for (OrderItem item : orderItems) {
                item.setOrderId(order.getOrderId());
                orderItemRepository.insert(item);
            }
            log.info("订单明细保存成功, itemCount={}", orderItems.size());

            // 设置订单明细到订单对象
            order.setItems(orderItems);

            return order;
        } catch (Exception e) {
            // 保存失败，释放库存
            log.error("订单保存失败，释放库存, orderNumber={}", orderNumber, e);
            inventoryService.releaseStock(orderNumber, orderItems);
            throw new BusinessException("订单创建失败: " + e.getMessage());
        }
    }

    /**
     * 校验订单
     * 
     * <p>校验内容：</p>
     * <ul>
     *   <li>用户ID是否有效</li>
     *   <li>购物车项是否为空</li>
     *   <li>收货地址是否完整</li>
     *   <li>库存是否充足</li>
     * </ul>
     * 
     * @param userId 用户ID
     * @param orderItems 订单明细列表
     * @param recipientName 收货人姓名
     * @param recipientPhone 收货人电话
     * @return 校验是否通过
     */
    public boolean validateOrder(Long userId, List<OrderItem> orderItems,
                                 String recipientName, String recipientPhone) {
        // 校验用户ID
        if (userId == null || userId <= 0) {
            log.error("用户ID无效, userId={}", userId);
            return false;
        }

        // 校验订单明细
        if (orderItems == null || orderItems.isEmpty()) {
            log.error("订单明细为空");
            return false;
        }

        // 校验收货信息
        if (recipientName == null || recipientName.trim().isEmpty()) {
            log.error("收货人姓名为空");
            return false;
        }
        if (recipientPhone == null || recipientPhone.trim().isEmpty()) {
            log.error("收货人电话为空");
            return false;
        }

        // 校验订单明细数据
        for (OrderItem item : orderItems) {
            if (!item.isValid()) {
                log.error("订单明细数据无效, item={}", item);
                return false;
            }
        }

        // 校验库存
        Map<Long, Boolean> stockCheckResult = inventoryService.batchCheckStock(orderItems);
        for (Boolean stockAvailable : stockCheckResult.values()) {
            if (!stockAvailable) {
                log.error("库存不足");
                return false;
            }
        }

        return true;
    }

    /**
     * 更新订单状态
     * 
     * <p>状态转换规则（参考Order状态图）：</p>
     * <ul>
     *   <li>PENDING_PAYMENT → PENDING_SHIPMENT（支付成功）</li>
     *   <li>PENDING_PAYMENT → CANCELLED（取消订单）</li>
     *   <li>PENDING_SHIPMENT → PENDING_RECEIPT（发货）</li>
     *   <li>PENDING_RECEIPT → COMPLETED（确认收货）</li>
     * </ul>
     * 
     * @param orderNumber 订单号
     * @param newStatus 新状态
     * @throws OrderNotFoundException 订单不存在异常
     * @throws OrderStatusException 订单状态异常
     */
    @Transactional(rollbackFor = Exception.class)
    public void updateOrderStatus(String orderNumber, OrderStatus newStatus) {
        log.info("更新订单状态, orderNumber={}, newStatus={}", orderNumber, newStatus);

        Order order = orderRepository.findByOrderNumber(orderNumber);
        if (order == null) {
            log.error("订单不存在, orderNumber={}", orderNumber);
            throw new OrderNotFoundException("订单不存在: " + orderNumber);
        }

        // 校验状态转换是否合法
        OrderStatus currentStatus = OrderStatus.valueOf(order.getStatus());
        if (!canTransitionTo(currentStatus, newStatus)) {
            log.error("订单状态转换不合法, currentStatus={}, newStatus={}", currentStatus, newStatus);
            throw new OrderStatusException("订单状态不能从 " + currentStatus + " 转换到 " + newStatus);
        }

        // 更新状态
        order.setStatus(newStatus.name());

        // 根据新状态设置相应的时间
        if (newStatus == OrderStatus.PENDING_SHIPMENT) {
            order.setPayTime(LocalDateTime.now());
        } else if (newStatus == OrderStatus.CANCELLED) {
            order.setCancelTime(LocalDateTime.now());
        }

        orderRepository.updateById(order);
        log.info("订单状态更新成功, orderNumber={}, newStatus={}", orderNumber, newStatus);
    }

    /**
     * 取消订单
     * 
     * <p>取消流程：</p>
     * <ol>
     *   <li>校验订单是否可以取消</li>
     *   <li>更新订单状态为CANCELLED</li>
     *   <li>释放预扣库存</li>
     * </ol>
     * 
     * @param orderNumber 订单号
     * @throws OrderNotFoundException 订单不存在异常
     * @throws OrderStatusException 订单状态异常（已支付不能取消）
     */
    @Transactional(rollbackFor = Exception.class)
    public void cancelOrder(String orderNumber) {
        log.info("取消订单, orderNumber={}", orderNumber);

        Order order = orderRepository.findByOrderNumber(orderNumber);
        if (order == null) {
            log.error("订单不存在, orderNumber={}", orderNumber);
            throw new OrderNotFoundException("订单不存在: " + orderNumber);
        }

        // 校验是否可以取消
        if (!order.canCancel()) {
            log.error("订单不能取消, orderNumber={}, status={}", orderNumber, order.getStatus());
            throw new OrderStatusException("订单状态为 " + order.getStatus() + "，不能取消");
        }

        // 查询订单明细
        List<OrderItem> items = orderItemRepository.findByOrderNumber(orderNumber);

        // 更新订单状态
        order.setStatus(OrderStatus.CANCELLED.name());
        order.setCancelTime(LocalDateTime.now());
        orderRepository.updateById(order);

        // 释放库存
        inventoryService.releaseStock(orderNumber, items);

        log.info("订单取消成功, orderNumber={}", orderNumber);
    }

    /**
     * 查询用户订单列表（分页）
     * 
     * @param userId 用户ID
     * @param status 订单状态（可选）
     * @param pageNum 页码
     * @param pageSize 每页大小
     * @return 订单分页列表
     */
    public Page<Order> queryUserOrders(Long userId, String status, int pageNum, int pageSize) {
        log.info("查询用户订单列表, userId={}, status={}, pageNum={}, pageSize={}", 
                 userId, status, pageNum, pageSize);

        Page<Order> page = new Page<>(pageNum, pageSize);

        // 使用统一的方法，status可以为null
        return orderRepository.findByUserIdWithPage(page, userId, status);
    }

    /**
     * 获取订单详情
     * 
     * @param orderNumber 订单号
     * @return 订单详情（包含订单明细）
     * @throws OrderNotFoundException 订单不存在异常
     */
    public Order getOrderDetail(String orderNumber) {
        log.info("获取订单详情, orderNumber={}", orderNumber);

        Order order = orderRepository.findByOrderNumber(orderNumber);
        if (order == null) {
            log.error("订单不存在, orderNumber={}", orderNumber);
            throw new OrderNotFoundException("订单不存在: " + orderNumber);
        }

        // 查询订单明细
        List<OrderItem> items = orderItemRepository.findByOrderNumber(orderNumber);
        order.setItems(items);

        return order;
    }

    /**
     * 检查超时订单（定时任务）
     * 
     * <p>定时扫描待支付订单，自动取消超时订单</p>
     * <p>超时时间：30分钟</p>
     */
    @Transactional(rollbackFor = Exception.class)
    public void checkTimeout() {
        log.info("开始检查超时订单");

        List<Order> expiredOrders = orderRepository.findExpiredOrders();
        log.info("发现超时订单数量: {}", expiredOrders.size());

        for (Order order : expiredOrders) {
            try {
                autoCancel(order.getOrderNumber());
            } catch (Exception e) {
                log.error("自动取消订单失败, orderNumber={}", order.getOrderNumber(), e);
            }
        }

        log.info("超时订单检查完成");
    }

    /**
     * 自动取消超时订单
     * 
     * @param orderNumber 订单号
     */
    @Transactional(rollbackFor = Exception.class)
    public void autoCancel(String orderNumber) {
        log.info("自动取消超时订单, orderNumber={}", orderNumber);

        Order order = orderRepository.findByOrderNumber(orderNumber);
        if (order == null) {
            log.warn("订单不存在, orderNumber={}", orderNumber);
            return;
        }

        // 只取消待支付状态的订单
        if (!OrderStatus.PENDING_PAYMENT.name().equals(order.getStatus())) {
            log.warn("订单状态不是待支付，跳过, orderNumber={}, status={}", orderNumber, order.getStatus());
            return;
        }

        // 查询订单明细
        List<OrderItem> items = orderItemRepository.findByOrderNumber(orderNumber);

        // 更新订单状态
        order.setStatus(OrderStatus.CANCELLED.name());
        order.setCancelTime(LocalDateTime.now());
        order.setRemark("订单超时自动取消");
        orderRepository.updateById(order);

        // 释放库存
        inventoryService.releaseStock(orderNumber, items);

        log.info("超时订单自动取消成功, orderNumber={}", orderNumber);
    }

    /**
     * 判断订单状态是否可以转换
     * 
     * @param currentStatus 当前状态
     * @param newStatus 新状态
     * @return 是否可以转换
     */
    private boolean canTransitionTo(OrderStatus currentStatus, OrderStatus newStatus) {
        // 状态转换规则（参考Order状态图）
        switch (currentStatus) {
            case PENDING_PAYMENT:
                // 待支付 → 待发货（支付成功）或 已取消
                return newStatus == OrderStatus.PENDING_SHIPMENT || newStatus == OrderStatus.CANCELLED;
            case PENDING_SHIPMENT:
                // 待发货 → 已发货（发货）或 已取消（特殊情况）
                return newStatus == OrderStatus.SHIPPED || newStatus == OrderStatus.CANCELLED;
            case SHIPPED:
                // 已发货 → 已完成（确认收货）
                return newStatus == OrderStatus.COMPLETED;
            case COMPLETED:
            case CANCELLED:
                // 终止状态，不能转换
                return false;
            default:
                return false;
        }
    }
}