package com.ecommerce.order.repository;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ecommerce.order.domain.entity.Inventory;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

/**
 * 库存数据访问接口
 * <p>
 * 继承MyBatis-Plus的BaseMapper接口，提供基本的CRUD操作
 * 库存操作需要使用乐观锁，防止并发扣减时的超卖问题
 * </p>
 * 
 * <p>
 * BaseMapper提供的方法：
 * - insert(Inventory inventory) - 插入库存
 * - selectById(Long id) - 根据ID查询
 * - updateById(Inventory inventory) - 根据ID更新（支持乐观锁）
 * - deleteById(Long id) - 根据ID删除
 * - selectList(Wrapper) - 条件查询列表
 * </p>
 * 
 * <p>
 * 乐观锁使用说明：
 * 1. 实体类的version字段使用@Version注解
 * 2. 更新时MyBatis-Plus会自动在WHERE条件中加上version
 * 3. 更新成功后version会自动+1
 * 4. 如果version不匹配，更新失败，返回0
 * </p>
 *
 * @author ecommerce-platform
 * @since 1.0.0
 */
@Mapper
public interface InventoryRepository extends BaseMapper<Inventory> {

    /**
     * 根据商品ID查询库存
     * <p>
     * 最常用的查询方法，使用唯一索引uk_product_id
     * </p>
     *
     * @param productId 商品ID
     * @return 库存对象，不存在返回null
     */
    @Select("SELECT * FROM inventory WHERE product_id = #{productId}")
    Inventory findByProductId(@Param("productId") Long productId);

    /**
     * 批量根据商品ID查询库存
     * <p>
     * 用于批量查询多个商品的库存，提高查询效率
     * 创建订单时需要批量检查库存
     * </p>
     *
     * @param productIds 商品ID列表
     * @return 库存列表
     */
    @Select("<script>" +
            "SELECT * FROM inventory " +
            "WHERE product_id IN " +
            "<foreach collection='productIds' item='productId' open='(' separator=',' close=')'>" +
            "#{productId}" +
            "</foreach>" +
            "</script>")
    List<Inventory> findByProductIds(@Param("productIds") List<Long> productIds);

    /**
     * 使用乐观锁更新库存
     * <p>
     * 核心方法，用于库存的锁定、扣减、释放操作
     * WHERE条件中包含version，确保并发安全
     * </p>
     * 
     * <p>
     * 使用场景：
     * 1. 锁定库存：available_stock减少，locked_stock增加
     * 2. 扣减库存：locked_stock减少，total_stock减少
     * 3. 释放库存：locked_stock减少，available_stock增加
     * </p>
     *
     * @param inventory 库存对象（必须包含version）
     * @return 影响的行数（1-成功，0-失败，版本冲突）
     */
    @Update("UPDATE inventory SET " +
            "total_stock = #{totalStock}, " +
            "available_stock = #{availableStock}, " +
            "locked_stock = #{lockedStock}, " +
            "version = version + 1, " +
            "update_time = NOW() " +
            "WHERE product_id = #{productId} " +
            "AND version = #{version}")
    int updateWithOptimisticLock(Inventory inventory);

    /**
     * 锁定库存（预扣库存）
     * <p>
     * 创建订单时调用，使用乐观锁
     * available_stock减少，locked_stock增加
     * </p>
     *
     * @param productId 商品ID
     * @param quantity  锁定数量
     * @param version   当前版本号
     * @return 影响的行数（1-成功，0-失败）
     */
    @Update("UPDATE inventory SET " +
            "available_stock = available_stock - #{quantity}, " +
            "locked_stock = locked_stock + #{quantity}, " +
            "version = version + 1, " +
            "update_time = NOW() " +
            "WHERE product_id = #{productId} " +
            "AND version = #{version} " +
            "AND available_stock >= #{quantity}")
    int lockStock(@Param("productId") Long productId, @Param("quantity") Integer quantity, @Param("version") Integer version);

    /**
     * 扣减库存（实际扣减）
     * <p>
     * 支付成功时调用，使用乐观锁
     * locked_stock减少，total_stock减少
     * </p>
     *
     * @param productId 商品ID
     * @param quantity  扣减数量
     * @param version   当前版本号
     * @return 影响的行数（1-成功，0-失败）
     */
    @Update("UPDATE inventory SET " +
            "locked_stock = locked_stock - #{quantity}, " +
            "total_stock = total_stock - #{quantity}, " +
            "version = version + 1, " +
            "update_time = NOW() " +
            "WHERE product_id = #{productId} " +
            "AND version = #{version} " +
            "AND locked_stock >= #{quantity}")
    int deductStock(@Param("productId") Long productId, @Param("quantity") Integer quantity, @Param("version") Integer version);

    /**
     * 释放库存
     * <p>
     * 订单取消或超时时调用，使用乐观锁
     * locked_stock减少，available_stock增加
     * </p>
     *
     * @param productId 商品ID
     * @param quantity  释放数量
     * @param version   当前版本号
     * @return 影响的行数（1-成功，0-失败）
     */
    @Update("UPDATE inventory SET " +
            "locked_stock = locked_stock - #{quantity}, " +
            "available_stock = available_stock + #{quantity}, " +
            "version = version + 1, " +
            "update_time = NOW() " +
            "WHERE product_id = #{productId} " +
            "AND version = #{version} " +
            "AND locked_stock >= #{quantity}")
    int releaseStock(@Param("productId") Long productId, @Param("quantity") Integer quantity, @Param("version") Integer version);

    /**
     * 增加库存
     * <p>
     * 商品入库时调用
     * total_stock和available_stock同时增加
     * </p>
     *
     * @param productId 商品ID
     * @param quantity  增加数量
     * @return 影响的行数
     */
    @Update("UPDATE inventory SET " +
            "total_stock = total_stock + #{quantity}, " +
            "available_stock = available_stock + #{quantity}, " +
            "update_time = NOW() " +
            "WHERE product_id = #{productId}")
    int addStock(@Param("productId") Long productId, @Param("quantity") Integer quantity);

    /**
     * 查询库存不足的商品
     * <p>
     * 用于库存预警，查询可用库存低于指定阈值的商品
     * </p>
     *
     * @param threshold 库存阈值
     * @return 库存不足的商品列表
     */
    @Select("SELECT * FROM inventory WHERE available_stock <= #{threshold} ORDER BY available_stock ASC")
    List<Inventory> findLowStockProducts(@Param("threshold") Integer threshold);

    /**
     * 查询缺货商品
     * <p>
     * 查询可用库存为0的商品
     * </p>
     *
     * @return 缺货商品列表
     */
    @Select("SELECT * FROM inventory WHERE available_stock = 0 ORDER BY product_id")
    List<Inventory> findOutOfStockProducts();

    /**
     * 查询有锁定库存的商品
     * <p>
     * 用于监控和统计，查询有未完成订单的商品
     * </p>
     *
     * @return 有锁定库存的商品列表
     */
    @Select("SELECT * FROM inventory WHERE locked_stock > 0 ORDER BY locked_stock DESC")
    List<Inventory> findProductsWithLockedStock();

    /**
     * 统计总库存数量
     * <p>
     * 统计所有商品的总库存之和
     * </p>
     *
     * @return 总库存数量
     */
    @Select("SELECT IFNULL(SUM(total_stock), 0) FROM inventory")
    long sumTotalStock();

    /**
     * 统计可用库存数量
     * <p>
     * 统计所有商品的可用库存之和
     * </p>
     *
     * @return 可用库存数量
     */
    @Select("SELECT IFNULL(SUM(available_stock), 0) FROM inventory")
    long sumAvailableStock();

    /**
     * 统计锁定库存数量
     * <p>
     * 统计所有商品的锁定库存之和
     * </p>
     *
     * @return 锁定库存数量
     */
    @Select("SELECT IFNULL(SUM(locked_stock), 0) FROM inventory")
    long sumLockedStock();

    /**
     * 检查商品库存是否存在
     * <p>
     * 用于验证商品是否已初始化库存
     * </p>
     *
     * @param productId 商品ID
     * @return true-存在，false-不存在
     */
    @Select("SELECT COUNT(*) > 0 FROM inventory WHERE product_id = #{productId}")
    boolean existsByProductId(@Param("productId") Long productId);

    /**
     * 检查库存是否充足
     * <p>
     * 快速检查库存是否满足需求，不返回库存对象
     * </p>
     *
     * @param productId 商品ID
     * @param quantity  需要的数量
     * @return true-库存充足，false-库存不足
     */
    @Select("SELECT COUNT(*) > 0 FROM inventory WHERE product_id = #{productId} AND available_stock >= #{quantity}")
    boolean isStockSufficient(@Param("productId") Long productId, @Param("quantity") Integer quantity);
}