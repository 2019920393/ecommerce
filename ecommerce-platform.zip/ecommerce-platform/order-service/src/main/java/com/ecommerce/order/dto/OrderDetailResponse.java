package com.ecommerce.order.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

/**
 * 订单详情响应DTO
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "订单详情响应")
public class OrderDetailResponse {

    @Schema(description = "订单号", example = "ORD20251130000001")
    private String orderNumber;

    @Schema(description = "用户ID", example = "1001")
    private Long userId;

    @Schema(description = "订单总金额", example = "7999.00")
    private BigDecimal totalAmount;

    @Schema(description = "商品总价", example = "7999.00")
    private BigDecimal productAmount;

    @Schema(description = "运费", example = "0.00")
    private BigDecimal shippingFee;

    @Schema(description = "优惠金额", example = "0.00")
    private BigDecimal discount;

    @Schema(description = "订单状态", example = "PENDING_PAYMENT")
    private String status;

    @Schema(description = "订单状态描述", example = "待支付")
    private String statusDescription;

    @Schema(description = "创建时间", example = "2025-11-30 12:00:00")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private LocalDateTime createTime;

    @Schema(description = "支付时间", example = "2025-11-30 12:05:00")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private LocalDateTime payTime;

    @Schema(description = "过期时间", example = "2025-11-30 12:30:00")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private LocalDateTime expireTime;

    @Schema(description = "取消时间", example = "2025-11-30 12:10:00")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private LocalDateTime cancelTime;

    @Schema(description = "订单备注", example = "请尽快发货")
    private String remark;

    @Schema(description = "收货地址信息")
    private ShippingAddressDTO shippingAddress;

    @Schema(description = "订单明细列表")
    private List<OrderItemDTO> items;

    @Schema(description = "是否已支付", example = "false")
    private Boolean isPaid;

    @Schema(description = "是否已过期", example = "false")
    private Boolean isExpired;

    @Schema(description = "是否可以取消", example = "true")
    private Boolean canCancel;
}