package com.ecommerce.order.dto;

import com.ecommerce.common.constant.Constants;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * 创建订单请求DTO
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "创建订单请求")
public class CreateOrderRequest {

    @Schema(description = "用户ID", example = "1001", required = true)
    @NotNull(message = "用户ID不能为空")
    private Long userId;

    @Schema(description = "订单明细列表", required = true)
    @NotEmpty(message = "订单明细不能为空")
    @Valid
    private List<OrderItemRequest> items;

    @Schema(description = "收货人姓名", example = "张三", required = true)
    @NotNull(message = "收货人姓名不能为空")
    private String recipientName;

    @Schema(description = "收货人电话", example = "13800138000", required = true)
    @NotNull(message = "收货人电话不能为空")
    private String recipientPhone;

    @Schema(description = "省", example = "广东省")
    private String province;

    @Schema(description = "市", example = "深圳市")
    private String city;

    @Schema(description = "区", example = "南山区")
    private String district;

    @Schema(description = "详细地址", example = "科技园南路88号")
    private String detailAddress;

    @Schema(description = "订单备注", example = "请尽快发货")
    @Size(max = Constants.ORDER_REMARK_MAX_LENGTH, message = "订单备注最长" + Constants.ORDER_REMARK_MAX_LENGTH + "字符")
    private String remark;
}