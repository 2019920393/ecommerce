package com.ecommerce.common.exception;

/**
 * 库存锁定失败异常
 * 
 * <p>当库存锁定操作失败时抛出此异常，通常是由于乐观锁冲突或并发问题导致。</p>
 * 
 * <p>此异常会触发订单创建的回滚操作。</p>
 * 
 * @author 系统架构团队
 * @since 1.0.0
 */
public class StockLockFailedException extends BusinessException {
    
    /**
     * 默认错误码：5001
     */
    private static final Integer DEFAULT_CODE = 5001;
    
    /**
     * 构造函数 - 仅包含错误消息
     * 
     * @param message 错误消息
     */
    public StockLockFailedException(String message) {
        super(DEFAULT_CODE, message);
    }
    
    /**
     * 构造函数 - 包含错误消息和失败的商品信息
     * 
     * @param message 错误消息
     * @param failedProducts 锁定失败的商品信息
     */
    public StockLockFailedException(String message, Object failedProducts) {
        super(DEFAULT_CODE, message, failedProducts);
    }
    
    /**
     * 构造函数 - 包含错误消息和原始异常
     * 
     * @param message 错误消息
     * @param cause 原始异常
     */
    public StockLockFailedException(String message, Throwable cause) {
        super(DEFAULT_CODE, message, cause);
    }
}