package com.ecommerce.common.util;

import com.ecommerce.common.constant.Constants;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * 订单号生成器
 * <p>
 * 订单号格式：ORD + yyyyMMdd + 6位序列号
 * 例如：ORD20240115000001
 * </p>
 * 
 * <p>
 * 设计说明：
 * 1. 使用AtomicInteger保证线程安全的序列号生成
 * 2. 每天序列号从1开始重新计数
 * 3. 序列号最大值为999999（6位），超过后从1重新开始
 * 4. 使用synchronized确保日期切换时的线程安全
 * </p>
 *
 * @author ecommerce-platform
 * @since 1.0.0
 */
public class OrderNoGenerator {

    /**
     * 日期格式化器：yyyyMMdd
     */
    private static final DateTimeFormatter DATE_FORMATTER = 
        DateTimeFormatter.ofPattern(Constants.ORDER_NO_DATE_FORMAT);

    /**
     * 当前日期（yyyyMMdd格式）
     */
    private static volatile String currentDate = "";

    /**
     * 序列号计数器（线程安全）
     */
    private static final AtomicInteger sequence = new AtomicInteger(0);

    /**
     * 序列号最大值（6位数字）
     */
    private static final int MAX_SEQUENCE = 999999;

    /**
     * 私有构造函数，防止实例化
     */
    private OrderNoGenerator() {
        throw new UnsupportedOperationException("Utility class cannot be instantiated");
    }

    /**
     * 生成订单号
     * <p>
     * 格式：ORD + yyyyMMdd + 6位序列号（含随机因子）
     * 例如：ORD20241130000001
     * </p>
     *
     * @return 订单号
     */
    public static String generate() {
        // 获取当前日期
        String today = LocalDateTime.now().format(DATE_FORMATTER);
        
        // 获取序列号（加入时间因子避免重启后重复）
        int timeFactor = (int) (System.currentTimeMillis() % 100000);
        int seq = getNextSequence(today);
        int finalSeq = (timeFactor + seq) % 1000000;
        if (finalSeq == 0) finalSeq = 1;
        
        // 格式化序列号为6位（不足补0）
        String seqStr = String.format("%06d", finalSeq);
        
        // 拼接订单号：前缀 + 日期 + 序列号
        return Constants.ORDER_NO_PREFIX + today + seqStr;
    }

    /**
     * 获取下一个序列号
     * <p>
     * 如果日期发生变化，序列号重置为1
     * 如果序列号超过最大值，从1重新开始
     * </p>
     *
     * @param today 当前日期（yyyyMMdd格式）
     * @return 序列号
     */
    private static synchronized int getNextSequence(String today) {
        // 检查日期是否发生变化
        if (!today.equals(currentDate)) {
            // 日期变化，重置序列号
            currentDate = today;
            sequence.set(0);
        }
        
        // 获取并递增序列号
        int seq = sequence.incrementAndGet();
        
        // 如果序列号超过最大值，重置为1
        if (seq > MAX_SEQUENCE) {
            sequence.set(1);
            seq = 1;
        }
        
        return seq;
    }

    /**
     * 重置序列号（仅用于测试）
     * <p>
     * 注意：此方法仅用于测试环境，生产环境不应调用
     * </p>
     */
    public static synchronized void reset() {
        currentDate = "";
        sequence.set(0);
    }

    /**
     * 获取当前序列号（仅用于测试和监控）
     *
     * @return 当前序列号
     */
    public static int getCurrentSequence() {
        return sequence.get();
    }

    /**
     * 获取当前日期（仅用于测试和监控）
     *
     * @return 当前日期（yyyyMMdd格式）
     */
    public static String getCurrentDate() {
        return currentDate;
    }

    /**
     * 解析订单号中的日期部分
     * <p>
     * 从订单号中提取日期信息
     * 例如：ORD20240115000001 -> 20240115
     * </p>
     *
     * @param orderNo 订单号
     * @return 日期字符串（yyyyMMdd格式），如果订单号格式不正确返回null
     */
    public static String parseDate(String orderNo) {
        if (orderNo == null || orderNo.length() < Constants.ORDER_NO_PREFIX.length() + 8) {
            return null;
        }
        
        try {
            // 提取日期部分（跳过前缀）
            int startIndex = Constants.ORDER_NO_PREFIX.length();
            return orderNo.substring(startIndex, startIndex + 8);
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * 解析订单号中的序列号部分
     * <p>
     * 从订单号中提取序列号信息
     * 例如：ORD20240115000001 -> 1
     * </p>
     *
     * @param orderNo 订单号
     * @return 序列号，如果订单号格式不正确返回-1
     */
    public static int parseSequence(String orderNo) {
        if (orderNo == null || 
            orderNo.length() != Constants.ORDER_NO_PREFIX.length() + 8 + Constants.ORDER_NO_SEQUENCE_LENGTH) {
            return -1;
        }
        
        try {
            // 提取序列号部分
            int startIndex = Constants.ORDER_NO_PREFIX.length() + 8;
            String seqStr = orderNo.substring(startIndex);
            return Integer.parseInt(seqStr);
        } catch (Exception e) {
            return -1;
        }
    }

    /**
     * 验证订单号格式是否正确
     * <p>
     * 检查订单号是否符合格式要求：
     * 1. 以ORDER_NO_PREFIX开头
     * 2. 长度正确
     * 3. 日期部分为8位数字
     * 4. 序列号部分为6位数字
     * </p>
     *
     * @param orderNo 订单号
     * @return true-格式正确，false-格式错误
     */
    public static boolean validate(String orderNo) {
        if (orderNo == null) {
            return false;
        }
        
        // 检查长度
        int expectedLength = Constants.ORDER_NO_PREFIX.length() + 8 + Constants.ORDER_NO_SEQUENCE_LENGTH;
        if (orderNo.length() != expectedLength) {
            return false;
        }
        
        // 检查前缀
        if (!orderNo.startsWith(Constants.ORDER_NO_PREFIX)) {
            return false;
        }
        
        // 检查日期部分是否为数字
        String dateStr = parseDate(orderNo);
        if (dateStr == null || !dateStr.matches("\\d{8}")) {
            return false;
        }
        
        // 检查序列号部分是否为数字
        int seq = parseSequence(orderNo);
        return seq > 0 && seq <= MAX_SEQUENCE;
    }
}