package com.ecommerce.common.exception;

/**
 * 业务异常基类
 * 
 * <p>所有业务异常都应该继承此类，用于统一处理业务层的异常情况。
 * 业务异常通常表示可预期的错误，如库存不足、订单不存在等。</p>
 * 
 * <p>异常信息会被全局异常处理器捕获，并转换为统一的响应格式返回给客户端。</p>
 * 
 * @author 系统架构团队
 * @since 1.0.0
 */
public class BusinessException extends RuntimeException {
    
    /**
     * 错误码
     * 用于标识具体的业务错误类型
     */
    private Integer code;
    
    /**
     * 错误消息
     * 用于描述错误的详细信息
     */
    private String message;
    
    /**
     * 附加数据
     * 用于携带额外的错误信息，如库存不足时的商品列表
     */
    private Object data;
    
    /**
     * 构造函数 - 仅包含错误消息
     * 
     * @param message 错误消息
     */
    public BusinessException(String message) {
        super(message);
        this.code = 400;
        this.message = message;
    }
    
    /**
     * 构造函数 - 包含错误码和错误消息
     * 
     * @param code 错误码
     * @param message 错误消息
     */
    public BusinessException(Integer code, String message) {
        super(message);
        this.code = code;
        this.message = message;
    }
    
    /**
     * 构造函数 - 包含错误码、错误消息和附加数据
     * 
     * @param code 错误码
     * @param message 错误消息
     * @param data 附加数据
     */
    public BusinessException(Integer code, String message, Object data) {
        super(message);
        this.code = code;
        this.message = message;
        this.data = data;
    }
    
    /**
     * 构造函数 - 包含错误消息和原始异常
     * 
     * @param message 错误消息
     * @param cause 原始异常
     */
    public BusinessException(String message, Throwable cause) {
        super(message, cause);
        this.code = 400;
        this.message = message;
    }
    
    /**
     * 构造函数 - 包含错误码、错误消息和原始异常
     * 
     * @param code 错误码
     * @param message 错误消息
     * @param cause 原始异常
     */
    public BusinessException(Integer code, String message, Throwable cause) {
        super(message, cause);
        this.code = code;
        this.message = message;
    }
    
    /**
     * 获取错误码
     * 
     * @return 错误码
     */
    public Integer getCode() {
        return code;
    }
    
    /**
     * 设置错误码
     * 
     * @param code 错误码
     */
    public void setCode(Integer code) {
        this.code = code;
    }
    
    /**
     * 获取错误消息
     * 
     * @return 错误消息
     */
    @Override
    public String getMessage() {
        return message;
    }
    
    /**
     * 设置错误消息
     * 
     * @param message 错误消息
     */
    public void setMessage(String message) {
        this.message = message;
    }
    
    /**
     * 获取附加数据
     * 
     * @return 附加数据
     */
    public Object getData() {
        return data;
    }
    
    /**
     * 设置附加数据
     * 
     * @param data 附加数据
     */
    public void setData(Object data) {
        this.data = data;
    }
    
    /**
     * 重写toString方法，提供更详细的异常信息
     * 
     * @return 异常信息字符串
     */
    @Override
    public String toString() {
        return "BusinessException{" +
                "code=" + code +
                ", message='" + message + '\'' +
                ", data=" + data +
                '}';
    }
}