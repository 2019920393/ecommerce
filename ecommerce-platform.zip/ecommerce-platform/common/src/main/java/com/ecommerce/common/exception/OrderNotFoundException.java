package com.ecommerce.common.exception;

/**
 * 订单不存在异常
 * 
 * <p>当根据订单号查询订单时，如果订单不存在则抛出此异常。</p>
 * 
 * @author 系统架构团队
 * @since 1.0.0
 */
public class OrderNotFoundException extends BusinessException {
    
    /**
     * 默认错误码：404
     */
    private static final Integer DEFAULT_CODE = 404;
    
    /**
     * 构造函数 - 仅包含错误消息
     * 
     * @param message 错误消息
     */
    public OrderNotFoundException(String message) {
        super(DEFAULT_CODE, message);
    }
    
    /**
     * 构造函数 - 包含订单号信息
     * 
     * @param orderNumber 订单号
     */
    public OrderNotFoundException(String message, String orderNumber) {
        super(DEFAULT_CODE, message, orderNumber);
    }
    
    /**
     * 构造函数 - 包含错误消息和原始异常
     * 
     * @param message 错误消息
     * @param cause 原始异常
     */
    public OrderNotFoundException(String message, Throwable cause) {
        super(DEFAULT_CODE, message, cause);
    }
}