package com.ecommerce.common.exception;

/**
 * 订单状态异常
 * 
 * <p>当订单状态不允许执行某个操作时抛出此异常。</p>
 * 
 * <p>例如：已支付的订单不能再次支付，已取消的订单不能支付等。</p>
 * 
 * @author 系统架构团队
 * @since 1.0.0
 */
public class OrderStatusException extends BusinessException {
    
    /**
     * 默认错误码：4002
     */
    private static final Integer DEFAULT_CODE = 4002;
    
    /**
     * 构造函数 - 仅包含错误消息
     * 
     * @param message 错误消息
     */
    public OrderStatusException(String message) {
        super(DEFAULT_CODE, message);
    }
    
    /**
     * 构造函数 - 包含订单状态信息
     * 
     * @param message 错误消息
     * @param orderStatus 当前订单状态
     */
    public OrderStatusException(String message, Object orderStatus) {
        super(DEFAULT_CODE, message, orderStatus);
    }
    
    /**
     * 构造函数 - 包含错误消息和原始异常
     * 
     * @param message 错误消息
     * @param cause 原始异常
     */
    public OrderStatusException(String message, Throwable cause) {
        super(DEFAULT_CODE, message, cause);
    }
}