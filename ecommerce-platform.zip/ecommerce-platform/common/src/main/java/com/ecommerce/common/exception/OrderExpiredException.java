package com.ecommerce.common.exception;

/**
 * 订单已过期异常
 * 
 * <p>当订单超过支付时间限制（30分钟）后仍未支付时抛出此异常。</p>
 * 
 * <p>过期的订单不能再进行支付操作。</p>
 * 
 * @author 系统架构团队
 * @since 1.0.0
 */
public class OrderExpiredException extends BusinessException {
    
    /**
     * 默认错误码：4004
     */
    private static final Integer DEFAULT_CODE = 4004;
    
    /**
     * 构造函数 - 仅包含错误消息
     * 
     * @param message 错误消息
     */
    public OrderExpiredException(String message) {
        super(DEFAULT_CODE, message);
    }
    
    /**
     * 构造函数 - 包含订单过期时间信息
     * 
     * @param message 错误消息
     * @param expireInfo 过期时间信息
     */
    public OrderExpiredException(String message, Object expireInfo) {
        super(DEFAULT_CODE, message, expireInfo);
    }
    
    /**
     * 构造函数 - 包含错误消息和原始异常
     * 
     * @param message 错误消息
     * @param cause 原始异常
     */
    public OrderExpiredException(String message, Throwable cause) {
        super(DEFAULT_CODE, message, cause);
    }
}