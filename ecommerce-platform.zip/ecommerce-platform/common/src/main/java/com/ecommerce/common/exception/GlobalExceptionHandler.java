package com.ecommerce.common.exception;

import com.ecommerce.common.result.Result;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.validation.BindException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.HashMap;
import java.util.Map;

/**
 * 全局异常处理器
 * 
 * <p>统一处理系统中的各种异常，将异常转换为统一的响应格式返回给客户端。</p>
 * 
 * <p>使用@RestControllerAdvice注解，自动应用于所有@RestController。</p>
 * 
 * @author 系统架构团队
 * @since 1.0.0
 */
@RestControllerAdvice
public class GlobalExceptionHandler {
    
    private static final Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);
    
    /**
     * 处理业务异常
     * 
     * <p>捕获所有BusinessException及其子类异常，返回业务错误信息。</p>
     * 
     * @param e 业务异常
     * @return 统一响应结果
     */
    @ExceptionHandler(BusinessException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public Result<Object> handleBusinessException(BusinessException e) {
        log.warn("业务异常: code={}, message={}, data={}", e.getCode(), e.getMessage(), e.getData());
        return Result.error(e.getCode(), e.getMessage(), e.getData());
    }
    
    /**
     * 处理参数验证异常（@Valid注解）
     * 
     * <p>捕获@RequestBody参数验证失败的异常，返回详细的字段错误信息。</p>
     * 
     * @param e 方法参数验证异常
     * @return 统一响应结果，包含字段错误详情
     */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public Result<Object> handleMethodArgumentNotValidException(MethodArgumentNotValidException e) {
        log.warn("参数验证失败: {}", e.getMessage());
        
        Map<String, String> errors = new HashMap<>();
        e.getBindingResult().getAllErrors().forEach(error -> {
            String fieldName = ((FieldError) error).getField();
            String errorMessage = error.getDefaultMessage();
            errors.put(fieldName, errorMessage);
        });
        
        return Result.error(400, "参数验证失败", errors);
    }
    
    /**
     * 处理参数绑定异常
     * 
     * <p>捕获表单参数绑定失败的异常，返回详细的字段错误信息。</p>
     * 
     * @param e 绑定异常
     * @return 统一响应结果，包含字段错误详情
     */
    @ExceptionHandler(BindException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public Result<Object> handleBindException(BindException e) {
        log.warn("参数绑定失败: {}", e.getMessage());
        
        Map<String, String> errors = new HashMap<>();
        e.getBindingResult().getAllErrors().forEach(error -> {
            String fieldName = ((FieldError) error).getField();
            String errorMessage = error.getDefaultMessage();
            errors.put(fieldName, errorMessage);
        });
        
        return Result.error(400, "参数绑定失败", errors);
    }
    
    /**
     * 处理非法参数异常
     * 
     * <p>捕获IllegalArgumentException异常，通常由业务逻辑中的参数校验抛出。</p>
     * 
     * @param e 非法参数异常
     * @return 统一响应结果
     */
    @ExceptionHandler(IllegalArgumentException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public Result<Object> handleIllegalArgumentException(IllegalArgumentException e) {
        log.warn("非法参数: {}", e.getMessage());
        return Result.error(400, e.getMessage());
    }
    
    /**
     * 处理空指针异常
     * 
     * <p>捕获NullPointerException异常，记录详细的堆栈信息。</p>
     * 
     * @param e 空指针异常
     * @return 统一响应结果
     */
    @ExceptionHandler(NullPointerException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public Result<Object> handleNullPointerException(NullPointerException e) {
        log.error("空指针异常", e);
        return Result.error(500, "系统内部错误：空指针异常");
    }
    
    /**
     * 处理运行时异常
     * 
     * <p>捕获RuntimeException异常，记录详细的堆栈信息。</p>
     * 
     * @param e 运行时异常
     * @return 统一响应结果
     */
    @ExceptionHandler(RuntimeException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public Result<Object> handleRuntimeException(RuntimeException e) {
        log.error("运行时异常", e);
        return Result.error(500, "系统内部错误：" + e.getMessage());
    }
    
    /**
     * 处理所有未捕获的异常
     * 
     * <p>作为最后的兜底处理，捕获所有未被其他处理器捕获的异常。</p>
     * 
     * @param e 异常
     * @return 统一响应结果
     */
    @ExceptionHandler(Exception.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public Result<Object> handleException(Exception e) {
        log.error("未知异常", e);
        return Result.error(500, "系统内部错误，请联系管理员");
    }
}