package com.ecommerce.common.exception;

/**
 * 支付网关异常
 * 
 * <p>当调用第三方支付网关（支付宝、微信支付等）失败时抛出此异常。</p>
 * 
 * <p>异常信息通常包含第三方返回的错误码和错误消息。</p>
 * 
 * @author 系统架构团队
 * @since 1.0.0
 */
public class PaymentGatewayException extends BusinessException {
    
    /**
     * 默认错误码：5002
     */
    private static final Integer DEFAULT_CODE = 5002;
    
    /**
     * 构造函数 - 仅包含错误消息
     * 
     * @param message 错误消息
     */
    public PaymentGatewayException(String message) {
        super(DEFAULT_CODE, message);
    }
    
    /**
     * 构造函数 - 包含第三方错误信息
     * 
     * @param message 错误消息
     * @param gatewayError 第三方错误信息
     */
    public PaymentGatewayException(String message, Object gatewayError) {
        super(DEFAULT_CODE, message, gatewayError);
    }
    
    /**
     * 构造函数 - 包含错误消息和原始异常
     * 
     * @param message 错误消息
     * @param cause 原始异常
     */
    public PaymentGatewayException(String message, Throwable cause) {
        super(DEFAULT_CODE, message, cause);
    }
}