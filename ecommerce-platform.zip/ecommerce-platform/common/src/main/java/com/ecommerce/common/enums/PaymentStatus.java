package com.ecommerce.common.enums;

/**
 * 支付状态枚举
 * 
 * <p>定义支付订单的所有可能状态。</p>
 * 
 * <p>状态流转：
 * PENDING（待支付）→ SUCCESS（支付成功）
 * PENDING（待支付）→ FAILED（支付失败）
 * </p>
 * 
 * @author 系统架构团队
 * @since 1.0.0
 */
public enum PaymentStatus {
    
    /**
     * 待支付
     * 支付订单已创建，等待用户完成支付
     */
    PENDING("PENDING", "待支付"),
    
    /**
     * 支付成功
     * 用户已完成支付，第三方支付网关返回成功
     */
    SUCCESS("SUCCESS", "支付成功"),
    
    /**
     * 支付失败
     * 支付失败（余额不足、网络超时、用户取消等）
     */
    FAILED("FAILED", "支付失败");
    
    /**
     * 状态码
     */
    private final String code;
    
    /**
     * 状态描述
     */
    private final String description;
    
    /**
     * 构造函数
     * 
     * @param code 状态码
     * @param description 状态描述
     */
    PaymentStatus(String code, String description) {
        this.code = code;
        this.description = description;
    }
    
    /**
     * 获取状态码
     * 
     * @return 状态码
     */
    public String getCode() {
        return code;
    }
    
    /**
     * 获取状态描述
     * 
     * @return 状态描述
     */
    public String getDescription() {
        return description;
    }
    
    /**
     * 根据状态码获取枚举
     * 
     * @param code 状态码
     * @return 支付状态枚举，如果不存在返回null
     */
    public static PaymentStatus fromCode(String code) {
        for (PaymentStatus status : PaymentStatus.values()) {
            if (status.getCode().equals(code)) {
                return status;
            }
        }
        return null;
    }
    
    /**
     * 判断是否为最终状态
     * 支付成功和支付失败都是最终状态，不可再变更
     * 
     * @return 是否为最终状态
     */
    public boolean isFinalStatus() {
        return this == SUCCESS || this == FAILED;
    }
    
    /**
     * 判断是否支付成功
     * 
     * @return 是否支付成功
     */
    public boolean isSuccess() {
        return this == SUCCESS;
    }
    
    /**
     * 判断是否支付失败
     * 
     * @return 是否支付失败
     */
    public boolean isFailed() {
        return this == FAILED;
    }
}